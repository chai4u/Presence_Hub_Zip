import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './SwapRequest.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';

const SHIFT_OPTIONS = [
  { id: 1, name: 'Morning Shift' },
  { id: 2, name: 'Afternoon Shift' },
  { id: 3, name: 'Night Shift' }
];

// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});

// Add interceptor to automatically add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

const SwapRequest = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [colleagues, setColleagues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    targetEmployeeId: '',
    requesterShiftId: '',
    targetShiftId: '',
    swapDate: '',
    reason: ''
  });

  useEffect(() => {
    const fetchColleagues = async () => {
      try {
        const managerId = localStorage.getItem('managerId');
        const currentUserId = localStorage.getItem('userId');
        
        if (!managerId || !currentUserId) {
          toast.error('User information not found. Please login again.');
          navigate('/login');
          return;
        }

        const response = await api.get(`/api/v1/auth/user/manager/${managerId}`);
        if (response.data && Array.isArray(response.data)) {
          // Filter out the current user from the colleagues list
          const filteredColleagues = response.data.filter(
            employee => employee.id.toString() !== currentUserId
          );
          setColleagues(filteredColleagues);
        } else {
          toast.error('Invalid response format from server');
        }
      } catch (error) {
        console.error('Error fetching colleagues:', error);
        toast.error('Failed to fetch colleagues list');
      } finally {
        setLoading(false);
      }
    };

    fetchColleagues();
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const userId = localStorage.getItem('userId');
      const managerId = localStorage.getItem('managerId');
     
      if (!userId || !managerId) {
        toast.error('User ID or Manager ID not found. Please login again.');
        navigate('/login');
        return;
      }
 
      const payload = {
        requesterEmployeeId: parseInt(userId),
        targetEmployeeId: parseInt(formData.targetEmployeeId),
        requesterShiftId: parseInt(formData.requesterShiftId),
        targetShiftId: parseInt(formData.targetShiftId),
        managerId: parseInt(managerId),
        swapDate: formData.swapDate,
        reason: formData.reason
      };

      // Show swap request details in toast
      toast((t) => (
        <div>
          <p><strong>Submitting Swap Request:</strong></p>
          <p>Target Employee ID: {formData.targetEmployeeId}</p>
          <p>Your Shift ID: {formData.requesterShiftId}</p>
          <p>Target Shift ID: {formData.targetShiftId}</p>
          <p>Swap Date: {formData.swapDate}</p>
          <p>Reason: {formData.reason}</p>
        </div>
      ), {
        duration: 4000,
        style: {
          padding: '16px',
          borderRadius: '8px',
          background: '#f0f9ff',
          color: '#333'
        }
      });
 
      const response = await api.post('/api/v1/shift/employee/swap/request', payload);
      toast.success('Swap request submitted successfully!');
      navigate('/employee/shift');
    } catch (error) {
      const message = error.response?.data?.message || error.message || 'Failed to submit swap request';
      toast.error(message);
      console.error('Error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
 
  return (
    <div className="swap-request-container">
      <Toaster position="top-right" />
      <div className="swap-header">
        <button className="back-button" onClick={() => navigate('/employee/shift')}>
          <FontAwesomeIcon icon={faArrowLeft} />
          <span>Back</span>
        </button>
        <h2 className="swap-title">Request Shift Swap</h2>
      </div>

      <form className="swap-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="targetEmployeeId">Target Employee</label>
          <select
            id="targetEmployeeId"
            name="targetEmployeeId"
            className="form-input"
            value={formData.targetEmployeeId}
            onChange={handleChange}
            required
            disabled={loading}
          >
            <option value="">Select colleague</option>
            {colleagues.map(colleague => (
              <option key={colleague.id} value={colleague.id}>
                {colleague.name} (ID: {colleague.id})
              </option>
            ))}
          </select>
          {loading && <span className="loading-text">Loading colleagues...</span>}
        </div>

        <div className="form-group">
          <label htmlFor="requesterShiftId">Your Shift</label>
          <select
            id="requesterShiftId"
            name="requesterShiftId"
            className="form-input"
            value={formData.requesterShiftId}
            onChange={handleChange}
            required
          >
            <option value="">Select your shift</option>
            {SHIFT_OPTIONS.map(shift => (
              <option key={shift.id} value={shift.id}>
                {shift.name}
              </option>
            ))}
          </select>
        </div>
 
        <div className="form-group">
          <label htmlFor="targetShiftId">Target Shift</label>
          <select
            id="targetShiftId"
            name="targetShiftId"
            className="form-input"
            value={formData.targetShiftId}
            onChange={handleChange}
            required
          >
            <option value="">Select target shift</option>
            {SHIFT_OPTIONS.map(shift => (
              <option key={shift.id} value={shift.id}>
                {shift.name}
              </option>
            ))}
          </select>
        </div>
 
        <div className="form-group">
          <label htmlFor="swapDate">Swap Date</label>
          <input
            type="date"
            id="swapDate"
            name="swapDate"
            className="form-input"
            value={formData.swapDate}
            onChange={handleChange}
            required
            min={new Date().toISOString().split('T')[0]}
          />
        </div>
 
        <div className="form-group">
          <label htmlFor="reason">Reason</label>
          <textarea
            id="reason"
            name="reason"
            className="form-input"
            value={formData.reason}
            onChange={handleChange}
            required
            placeholder="Enter reason for swap request"
            rows="4"
          />
        </div>
 
        <div className="form-buttons">
          <button type="button" className="cancel-btn" onClick={() => navigate('/employee/shift')}>
            Cancel
          </button>
          <button type="submit" className="submit-btn" disabled={isSubmitting}>
            {isSubmitting ? 'Submitting...' : 'Submit Request'}
          </button>
        </div>
      </form>
    </div>
  );
};
 
export default SwapRequest;