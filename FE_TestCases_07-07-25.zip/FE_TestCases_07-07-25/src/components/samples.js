import React from 'react'
import Navigation from './Homepage/Navigation'
import Home from './Homepage/Home'

import { ThemeProvider } from './Homepage/Themecontext';


const Samples = () => {
  return (
    <div>

        <ThemeProvider> 
        <Navigation/>
        <Home/>
    </ThemeProvider>
      
    </div>
  )
}

export default Samples