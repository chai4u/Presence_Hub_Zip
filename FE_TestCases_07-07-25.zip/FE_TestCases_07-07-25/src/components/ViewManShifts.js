import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './ViewManShifts.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faPen, faTrash } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
 
// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});
 
// Add interceptor to automatically add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});
 
const ViewManShifts = () => {
  const navigate = useNavigate();
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState(null);
 
  useEffect(() => {
    fetchAssignments();
  }, []);
 
  const fetchAssignments = async () => {
    try {
      const managerId = localStorage.getItem('managerId');
      console.log('Manager ID from localStorage:', managerId);
     
      if (!managerId) {
        toast.error('Manager ID not found. Please login again.');
        navigate('/login');
        return;
      }
 
      console.log('Fetching assignments for manager:', managerId);
      const response = await api.get(`/api/v1/shift/manager/assignments/${managerId}`);
      console.log('API Response:', response.data);
     
      if (response.data) {
        setAssignments(response.data);
      }
      setLoading(false);
    } catch (error) {
      console.error('Full error object:', error);
      console.error('Response data:', error.response?.data);
      console.error('Response status:', error.response?.status);
      const message = error.response?.data?.message || error.message || 'Failed to fetch shift assignments';
      toast.error(message);
      setLoading(false);
    }
  };
 
  const handleEdit = (assignment) => {
    // Store assignment data in localStorage for the form
    localStorage.setItem('editingAssignment', JSON.stringify({
      id: assignment.assignmentId,
      employeeId: assignment.userId,
      shiftId: getShiftId(assignment.shiftType.shiftName),
      date: assignment.assignDate,
    }));
    navigate('/manager/shift_assign');
  };
 
  const getShiftId = (shiftName) => {
    switch(shiftName.toLowerCase()) {
      case 'morning': return 1;
      case 'afternoon': return 2;
      case 'night': return 3;
      default: return 1;
    }
  };
 
  const handleDelete = async () => {
    if (!selectedAssignment) return;
   
    try {
      await api.delete(`/api/v1/shift/manager/assignment/delete/${selectedAssignment.assignmentId}`);
      toast.success('Shift assignment deleted successfully');
      setAssignments(assignments.filter(a => a.assignmentId !== selectedAssignment.assignmentId));
    } catch (error) {
      console.error('Delete error:', error);
      toast.error(error.response?.data || 'Failed to delete shift assignment');
    } finally {
      setShowDeleteModal(false);
      setSelectedAssignment(null);
    }
  };
 
  const DeleteConfirmationModal = () => (
    <div className="modal-overlay">
      <div className="confirmation-modal">
        <h3 className="modal-title">Delete Shift Assignment</h3>
        <p className="modal-message">
          Are you sure you want to delete this shift assignment?
        </p>
        <div className="modal-buttons">
          <button className="modal-button cancel-button" onClick={() => {
            setShowDeleteModal(false);
            setSelectedAssignment(null);
          }}>
            Cancel
          </button>
          <button className="modal-button confirm-button" onClick={handleDelete}>
            Delete
          </button>
        </div>
      </div>
    </div>
  );
 
  if (loading) {
    return (
      <div className="view-man-shifts-container">
        <div className="loading">Loading...</div>
      </div>
    );
  }
 
  return (
    <div className="view-man-shifts-container">
      <Toaster position="top-right" />
     
      <div className="shifts-header">
        <button className="back-button" onClick={() => navigate('/manager/shift_assign')}>
          <FontAwesomeIcon icon={faArrowLeft} />
          <span>Back</span>
        </button>
        <h2 className="shifts-title">Employee Shift Assignments</h2>
      </div>
 
      <div className="table-wrapper">
        <table className="assignments-table">
          <thead>
            <tr>
              <th>Assignment ID</th>
              <th>Employee ID</th>
              <th>Shift Name</th>
              <th>Start Time</th>
              <th>End Time</th>
              <th>Assignment Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {assignments.length > 0 ? (
              assignments.map((assignment) => (
                <tr key={assignment.assignmentId}>
                  <td>{assignment.assignmentId}</td>
                  <td>{assignment.userId}</td>
                  <td>{assignment.shiftType.shiftName}</td>
                  <td>{assignment.shiftType.startTime}</td>
                  <td>{assignment.shiftType.endTime}</td>
                  <td>{new Date(assignment.assignDate).toLocaleDateString()}</td>
                  <td>
                    <div className="action-icons">
                      <button
                        className="action-icon edit-icon"
                        onClick={() => handleEdit(assignment)}
                        title="Edit shift"
                      >
                        <FontAwesomeIcon icon={faPen} />
                      </button>
                      <button
                        className="action-icon delete-icon"
                        onClick={() => {
                          setSelectedAssignment(assignment);
                          setShowDeleteModal(true);
                        }}
                        title="Delete shift"
                      >
                        <FontAwesomeIcon icon={faTrash} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" className="no-assignments">
                  No shift assignments found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
 
      {showDeleteModal && <DeleteConfirmationModal />}
    </div>
  );
};
 
export default ViewManShifts;
 