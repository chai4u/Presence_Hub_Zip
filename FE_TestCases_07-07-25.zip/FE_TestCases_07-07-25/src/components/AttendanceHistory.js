import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Attendance.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faClock } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import DateTimeHeader from './DateTimeHeader';

// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});

// Add interceptor to automatically add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

const AttendanceHistory = () => {
  const navigate = useNavigate();
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const userRole = localStorage.getItem('userRole');
  const basePath = userRole === 'manager' ? '/manager' : '/employee';

  useEffect(() => {
    const fetchAttendanceHistory = async () => {
      try {
        const employeeId = localStorage.getItem('userId');
        const response = await api.get(`/api/v1/attendance/employee/history/${employeeId}`);
        
        // Sort records by date in descending order (newest first)
        const sortedRecords = response.data.sort((a, b) => 
          new Date(b.date) - new Date(a.date)
        );
        
        setAttendanceRecords(sortedRecords);
      } catch (error) {
        console.error('Error fetching attendance history:', error);
        toast.error('Failed to fetch attendance history');
      } finally {
        setLoading(false);
      }
    };

    fetchAttendanceHistory();
  }, []);

  const calculateWorkHours = (clockIn, clockOut) => {
    if (!clockIn || !clockOut) return 'N/A';
    
    const start = new Date(clockIn);
    const end = new Date(clockOut);
    const diffMs = end - start;
    const diffHrs = diffMs / (1000 * 60 * 60);
    
    // Format hours and minutes
    const hours = Math.floor(diffHrs);
    const minutes = Math.round((diffHrs - hours) * 60);
    
    return `${hours}h ${minutes}m`;
  };

  const formatDateTime = (dateTime) => {
    if (!dateTime) return 'N/A';
    return new Date(dateTime).toLocaleTimeString();
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString();
  };

  return (
    <div className="attendance-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
      
      <div className="attendance-header">
        <button 
          className="back-button" 
          onClick={() => navigate(`${basePath}/attendance`)}
        >
          <FontAwesomeIcon icon={faArrowLeft} />
          <span>Back</span>
        </button>
        <h2 className="attendance-title">Attendance History</h2>
      </div>

      <div className="table-wrapper">
        <table className="attendance-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Clock In</th>
              <th>Clock Out</th>
              <th>Work Hours</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="5" className="loading-cell">Loading attendance records...</td>
              </tr>
            ) : attendanceRecords.length === 0 ? (
              <tr>
                <td colSpan="5" className="no-records">No attendance records found</td>
              </tr>
            ) : (
              attendanceRecords.map((record, index) => (
                <tr key={index}>
                  <td>{formatDate(record.date)}</td>
                  <td>{formatDateTime(record.clockIn)}</td>
                  <td>{formatDateTime(record.clockOut)}</td>
                  <td>{calculateWorkHours(record.clockIn, record.clockOut)}</td>
                  <td>
                    <span className={`status-badge ${record.isPresent ? 'present' : 'absent'}`}>
                      {record.isPresent ? 'Present' : 'Absent'}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AttendanceHistory;