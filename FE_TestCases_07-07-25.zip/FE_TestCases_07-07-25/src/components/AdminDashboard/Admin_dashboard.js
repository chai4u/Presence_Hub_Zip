// src/components/Dashboard/EmployeeDashboard.js
import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from '../Header';
import Sidebar from './Admin_Sidebar';
import '../EmployeeDashboard/Dashboard.css';

const Admin_dashboard = () => {
  return (
    <div className="dashboard-container">
      <Header />
      <Sidebar />
      <div className="content">
        <Outlet />
      </div>
    </div>
  );
};

export default Admin_dashboard;
