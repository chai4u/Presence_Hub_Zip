// src/components/Dashboard/Sidebar.js
import React from 'react';
import { Link } from 'react-router-dom';
import '../EmployeeDashboard/Dashboard.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faClipboardList,
  faChartBar
} from '@fortawesome/free-solid-svg-icons';

const Sidebar = () => {
  return (
    <div className="sidebar">
      <h3 className="sidebar-title">Admin</h3>
      <div className="sidebar-links">
        <Link to="/admin/Leave_req_man" className="sidebar-link">
          <FontAwesomeIcon icon={faClipboardList} className="sidebar-icon" />
          <span>Leave Requests</span>
        </Link>
        <Link to="/admin/Reports_man" className="sidebar-link">
          <FontAwesomeIcon icon={faChartBar} className="sidebar-icon" />
          <span>Employee Reports</span>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
