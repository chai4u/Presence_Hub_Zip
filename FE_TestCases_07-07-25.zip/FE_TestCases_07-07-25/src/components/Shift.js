import React from 'react';
import './Shift.css';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarWeek, faExchangeAlt, faBell } from '@fortawesome/free-solid-svg-icons';
import DateTimeHeader from './DateTimeHeader';

const Shift = () => {
  const navigate = useNavigate();

  return (
    <div className="shift-container">
      <DateTimeHeader />
      <h2 className="shift-title">Shift Management</h2>
      <div className="shift-buttons-container">
        <button className="shift-button view-shifts" onClick={() => navigate('/employee/viewshifts')}>
          <FontAwesomeIcon icon={faCalendarWeek} />
          <span>View Shifts</span>
        </button>
        <button className="shift-button request-swap" onClick={() => navigate('/employee/swaprequest')}>
          <FontAwesomeIcon icon={faExchangeAlt} />
          <span>Request Swap</span>
        </button>
        <button className="shift-button received-requests" onClick={() => navigate('/employee/shiftrequests')}>
          <FontAwesomeIcon icon={faBell} />
          <span>Received Requests</span>
        </button>
      </div>
    </div>
  );
};

export default Shift;
