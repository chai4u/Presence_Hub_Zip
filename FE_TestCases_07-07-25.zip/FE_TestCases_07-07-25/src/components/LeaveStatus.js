import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import './Leave.css';
import DateTimeHeader from './DateTimeHeader';

const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});

// Add interceptor for auth token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

const LeaveStatus = () => {
  const navigate = useNavigate();
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const userRole = localStorage.getItem('userRole');
  const basePath = userRole === 'manager' ? '/manager' : '/employee';

  useEffect(() => {
    const fetchLeaveRequests = async () => {
      try {
        const userId = localStorage.getItem('userId');
        const response = await api.get(`/api/v1/leave/employee/leave/${userId}`);
        // Sort the leave requests by start date in descending order (newest first)
        const sortedRequests = response.data.sort((a, b) => {
          return new Date(b.startDate) - new Date(a.startDate);
        });
        setLeaveRequests(sortedRequests);
      } catch (err) {
        toast.error('Failed to fetch leave requests');
      } finally {
        setLoading(false);
      }
    };

    fetchLeaveRequests();
  }, []);

  return (
    <div className="leave-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
      <h2 className="leave-title">Leave Status</h2>
      
      <div className="table-wrapper">
        <table className="requests-table">
          <thead>
            <tr>
              <th>Leave Type</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Reason</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="5" className="loading">Loading...</td>
              </tr>
            ) : leaveRequests.length === 0 ? (
              <tr>
                <td colSpan="5" className="no-requests">No leave requests found</td>
              </tr>
            ) : (
              leaveRequests.map((request) => (
                <tr key={request.leaveId}>
                  <td>{request.leaveType.name}</td>
                  <td>{new Date(request.startDate).toLocaleDateString()}</td>
                  <td>{new Date(request.endDate).toLocaleDateString()}</td>
                  <td>{request.reason}</td>
                  <td>
                    <span className={`status-badge ${request.status.toLowerCase()}`}>
                      {request.status}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      
      <button 
        className="back-btn" 
        onClick={() => navigate(`${basePath}/leave`)}
      >
        Back to Leave Dashboard
      </button>
    </div>
  );
};

export default LeaveStatus;