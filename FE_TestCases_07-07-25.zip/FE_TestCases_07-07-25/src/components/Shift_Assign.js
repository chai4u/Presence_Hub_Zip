import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Shift_Assign.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faUserClock, faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
 
// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});
 
// Add interceptor to automatically add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});
 
const Shift_Assign = () => {
  const navigate = useNavigate();
  const [empId, setEmpId] = useState('');
  const [shift, setShift] = useState('');
  const [date, setDate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editingAssignmentId, setEditingAssignmentId] = useState(null);
  const [currentShiftId, setCurrentShiftId] = useState(null);
 
  // All available shifts
  const shifts = [
    { id: "1", name: "Morning" },
    { id: "2", name: "Afternoon" },
    { id: "3", name: "Night" }
  ];
 
  useEffect(() => {
    const editingData = localStorage.getItem('editingAssignment');
    if (editingData) {
      const data = JSON.parse(editingData);
      setEmpId(data.employeeId.toString());
      setDate(data.date);
      setEditingAssignmentId(data.id);
      setCurrentShiftId(data.shiftId.toString()); // Store current shift ID
      setIsEditing(true);
      setShift(''); // Clear shift selection
      localStorage.removeItem('editingAssignment');
    }
 
    const fetchEmployees = async () => {
      try {
        const managerId = localStorage.getItem('userId');
        if (!managerId) {
          toast.error('Manager ID not found. Please login again.');
          return;
        }
 
        const response = await api.get(`/api/v1/auth/user/manager/${managerId}`);
        if (response.data && Array.isArray(response.data)) {
          setEmployees(response.data);
        } else {
          toast.error('Invalid response format from server');
        }
      } catch (error) {
        console.error('Error fetching employees:', error);
        toast.error('Failed to fetch employees list');
      } finally {
        setLoading(false);
      }
    };
 
    fetchEmployees();
  }, []);
 
  // Filter available shifts based on editing state
  const availableShifts = shifts.filter(s => !isEditing || s.id !== currentShiftId);
 
  const handleViewAssignments = () => {
    navigate('/manager/viewmanshifts');
  };
 
  const getShiftName = (shiftId) => {
    switch(shiftId) {
      case 1: return 'Morning';
      case 2: return 'Afternoon';
      case 3: return 'Night';
      default: return '';
    }
  };
 
  const handleAssign = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
 
    try {
      const managerId = localStorage.getItem('managerId');
      if (!managerId) {
        toast.error('Manager ID not found. Please login again.');
        return;
      }
 
      const shiftId = parseInt(shift);
      const payload = {
        employeeId: parseInt(empId),
        shiftId: shiftId,
        shiftName: getShiftName(shiftId),
        managerId: parseInt(managerId),
        assignDate: date
      };
 
      if (isEditing) {
        // Use PUT endpoint for editing
        await api.put(`/api/v1/shift/manager/assignment/edit/${editingAssignmentId}`, payload);
        toast.success('Shift assignment updated successfully!');
      } else {
        // Use POST endpoint for new assignment
        await api.post('/api/v1/shift/manager/shift/assign', payload);
        toast.success('Shift assigned successfully!');
      }
     
      // Clear form
      setEmpId('');
      setShift('');
      setDate('');
      setIsEditing(false);
      setEditingAssignmentId(null);
     
      // Navigate to view assignments
      navigate('/manager/viewmanshifts');
    } catch (error) {
      console.error('Full error:', error);
      console.error('Error response:', error.response?.data);
 
      switch (error.response?.status) {
        case 400:
          // Handle validation errors
          toast.error('Invalid request. Please check your input.');
          break;
        case 404:
          // Handle resource not found
          toast.error('Employee or shift type not found.');
          break;
        case 409:
          // Handle shift conflicts
          toast.error(error.response?.data || 'Shift conflict detected.');
          break;
        default:
          toast.error(error.response?.data || 'Failed to assign shift');
      }
    } finally {
      setIsSubmitting(false);
    }
  };
 
  const handleBack = () => {
    setIsEditing(false);
    setEditingAssignmentId(null);
    setEmpId('');
    setShift('');
    setDate('');
    navigate('/manager/viewmanshifts');
  };
 
  return (
    <div className="shift-assign-container">
      <Toaster position="top-right" />
      <h2 className="shift-assign-title">
        {isEditing ? 'Edit Shift Assignment' : 'Shift Assignment'}
      </h2>
     
      {isEditing ? (
        <button className="view-assignments-btn" onClick={handleBack}>
          <FontAwesomeIcon icon={faArrowLeft} />
          <span>Back to Assignments</span>
        </button>
      ) : (
        <button className="view-assignments-btn" onClick={handleViewAssignments}>
          <FontAwesomeIcon icon={faEye} />
          <span>View Assignments</span>
        </button>
      )}
 
      <form className="assignment-form" onSubmit={handleAssign}>
        <div className="form-group">
          <select
            className="form-input"
            value={empId}
            onChange={(e) => setEmpId(e.target.value)}
            required
            disabled={loading || isEditing}
          >
            <option value="">Select Employee</option>
            {employees.map(employee => (
              <option key={employee.id} value={employee.id}>
                {employee.name} (ID: {employee.id})
              </option>
            ))}
          </select>
          {loading && <span className="loading-text">Loading employees...</span>}
        </div>
 
        <div className="form-group">
          <select
            className="form-input"
            value={shift}
            onChange={(e) => setShift(e.target.value)}
            required
          >
            <option value="">Select Shift</option>
            {availableShifts.map(shift => (
              <option key={shift.id} value={shift.id}>
                {shift.name}
              </option>
            ))}
          </select>
        </div>
 
        <div className="form-group">
          <input
            type="date"
            className="form-input"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
            min={new Date().toISOString().split('T')[0]}
            disabled={isEditing}
          />
        </div>
 
        <button
          type="submit"
          className="assign-btn"
          disabled={isSubmitting}
        >
          <FontAwesomeIcon icon={faUserClock} />
          <span>
            {isSubmitting ? 'Processing...' : isEditing ? 'Update Shift' : 'Assign Shift'}
          </span>
        </button>
      </form>
    </div>
  );
};
 
export default Shift_Assign;

