import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Leave.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarPlus, faClipboardCheck, faCalendarDay } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import DateTimeHeader from './DateTimeHeader';

// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});

// Add interceptor to automatically add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

// Add response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      if (error.response.status === 403 || error.response.status === 401) {
        toast.error('Access denied. Please login again.');
      }
    }
    return Promise.reject(error);
  }
);

const Leave = () => {
  const navigate = useNavigate();
  const userRole = localStorage.getItem('userRole');
  const basePath = userRole === 'manager' ? '/manager' : '/employee';

  return (
    <div className="leave-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
      <h2 className="leave-title">Leave Management</h2>
      <div className="leave-buttons-container">
        <button className="leave-button apply-leave" onClick={() => navigate(`${basePath}/apply-leave`)}>
          <FontAwesomeIcon icon={faCalendarPlus} />
          <span>Apply Leave</span>
        </button>
        <button className="leave-button view-status" onClick={() => navigate(`${basePath}/leave-status`)}>
          <FontAwesomeIcon icon={faClipboardCheck} />
          <span>View Status</span>
        </button>
        <button className="leave-button leave-balance" onClick={() => navigate(`${basePath}/leave-balance`)}>
          <FontAwesomeIcon icon={faCalendarDay} />
          <span>Leave Balance</span>
        </button>
      </div>
    </div>
  );
};

export default Leave;
