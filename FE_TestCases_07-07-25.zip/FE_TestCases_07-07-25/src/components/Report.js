import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Report.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarAlt, faChartLine } from '@fortawesome/free-solid-svg-icons';
import toast, { Toaster } from 'react-hot-toast';
import DateTimeHeader from './DateTimeHeader';

const Report = () => {
  const navigate = useNavigate();
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const userRole = localStorage.getItem('userRole');
  const basePath = userRole === 'manager' ? '/manager' : '/employee';

  const handleViewReport = () => {
    if (!fromDate || !toDate) {
      toast.error('Please select both start and end dates');
      return;
    }

    if (new Date(fromDate) > new Date(toDate)) {
      toast.error('Start date cannot be after end date');
      return;
    }

    navigate(`${basePath}/view-report`, {
      state: {
        startDate: fromDate,
        endDate: toDate
      }
    });
  };

  return (
    <div className="report-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
      <h2 className="report-title">Attendance Report</h2>
      <div className="date-selection-container">
        <div className="date-column">
          <div className="date-input-group">
            <FontAwesomeIcon icon={faCalendarAlt} className="calendar-icon" />
            <input
              type="date"
              className="date-input"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              placeholder="From Date"
            />
            <label>From Date</label>
          </div>
        </div>
        <div className="date-column">
          <div className="date-input-group">
            <FontAwesomeIcon icon={faCalendarAlt} className="calendar-icon" />
            <input
              type="date"
              className="date-input"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              placeholder="To Date"
            />
            <label>To Date</label>
          </div>
        </div>
      </div>
      <button className="view-report-btn" onClick={handleViewReport}>
        <FontAwesomeIcon icon={faChartLine} />
        <span>View Report</span>
      </button>
    </div>
  );
};

export default Report;
