import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './ViewManagerReports.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faDownload, faUser, faCalendarCheck, faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import DateTimeHeader from './DateTimeHeader';

const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

const ViewManagerReports = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const userRole = localStorage.getItem('userRole'); // Add this line
  const { startDate, endDate, reports } = location.state || {};

  const handleDownloadPDF = async () => {
    try {
      const managerId = localStorage.getItem('userId');
      const response = await api.get(`/api/v1/reports/manager/pdf/${managerId}`, {
        params: {
          startDate: startDate,
          endDate: endDate
        },
        responseType: 'blob'
      });

      // Create a blob from the PDF bytes
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      
      // Create a temporary link and trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = `manager_attendance_report_${managerId}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast.success('Report downloaded successfully!');
    } catch (error) {
      console.error('Error downloading PDF:', error);
      toast.error('Failed to download report');
    }
  };

  if (!reports) {
    return (
      <div className="view-report-container">
        <DateTimeHeader />
        <div className="report-header">
          <button className="back-button" onClick={() => navigate(`/${userRole}/Reports_man`)}>
            <FontAwesomeIcon icon={faArrowLeft} />
            <span>Back</span>
          </button>
          <h2 className="report-title">No Reports Available</h2>
        </div>
      </div>
    );
  }

  return (
    <div className="view-manager-reports-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
      
      <div className="report-header">
        <button className="back-button" onClick={() => navigate(`/${userRole}/Reports_man`)}>
          <FontAwesomeIcon icon={faArrowLeft} />
          <span>Back</span>
        </button>
        <h2 className="report-title">Employee Reports</h2>
        <button className="download-btn" onClick={handleDownloadPDF}>
          <FontAwesomeIcon icon={faDownload} />
          <span>Download PDF</span>
        </button>
      </div>

      <div className="report-summary">
        <div className="summary-header">
          <h3>Report Overview</h3>
          <div className="date-range">
            <span>{new Date(startDate).toLocaleDateString()}</span>
            <span className="date-separator">to</span>
            <span>{new Date(endDate).toLocaleDateString()}</span>
          </div>
        </div>
        <div className="summary-stats">
          <div className="stat-item">
            <span className="stat-label">Total Employees:</span>
            <span className="stat-value">{reports.length}</span>
          </div>
        </div>
      </div>

      <div className="reports-grid">
        {reports.map((report) => (
          <div key={report.employeeId} className="report-card">
            <div className="card-header">
              <FontAwesomeIcon icon={faUser} className="employee-icon" />
              <div className="employee-info">
                <h3>{report.employeeName}</h3>
                <span className="employee-id">ID: {report.employeeId}</span>
              </div>
            </div>
            <div className="card-body">
              <div className="attendance-stat">
                <div className="stat-group">
                  <FontAwesomeIcon icon={faCalendarCheck} className="stat-icon present" />
                  <div className="stat-details">
                    <span className="stat-label">Total Attendance</span>
                    <span className="stat-value">{report.totalAttendance} days</span>
                  </div>
                </div>
                <div className="stat-group">
                  <FontAwesomeIcon icon={faTimesCircle} className="stat-icon absent" />
                  <div className="stat-details">
                    <span className="stat-label">Absenteeism</span>
                    <span className="stat-value">{report.absenteeism} days</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ViewManagerReports;