import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import './ViewShifts.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faRotateRight } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
 
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});
 
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});
 
const ViewShifts = () => {
  const navigate = useNavigate();
  const [shifts, setShifts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
 
  const fetchShifts = useCallback(async () => {
    try {
      const userId = localStorage.getItem('userId');
      const response = await api.get(`/api/v1/shift/employee/assignments/${userId}`);
      setShifts(response.data);
    } catch (error) {
      toast.error('Failed to fetch shift assignments');
      console.error('Error:', error);
    }
  }, []);
 
  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchShifts();
    setRefreshing(false);
    toast.success('Shifts updated successfully');
  };
 
  useEffect(() => {
    fetchShifts().finally(() => setLoading(false));
  }, [fetchShifts]);
 
  if (loading) {
    return (
      <div className="view-shifts-container">
        <div className="loading-spinner">Loading...</div>
      </div>
    );
  }
 
  return (
    <div className="view-shifts-container">
      <Toaster position="top-right" />
     
      <div className="shifts-header">
        <button className="back-button" onClick={() => navigate('/employee/shift')}>
          <FontAwesomeIcon icon={faArrowLeft} />
          <span>Back</span>
        </button>
        <h2 className="shifts-title">My Shift Assignments</h2>
        <button
          className="refresh-button"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <FontAwesomeIcon icon={faRotateRight} spin={refreshing} />
          <span>{refreshing ? 'Refreshing...' : 'Refresh'}</span>
        </button>
      </div>
 
      <div className="table-wrapper">
        <table className="shifts-table">
          <thead>
            <tr>
              <th>Assignment ID</th>
              <th>Shift Name</th>
              <th>Start Time</th>
              <th>End Time</th>
              <th>Assignment Date</th>
            </tr>
          </thead>
          <tbody>
            {shifts && shifts.length > 0 ? (
              shifts.map((shift) => (
                <tr key={shift.assignmentId}>
                  <td>{shift.assignmentId}</td>
                  <td>{shift.shiftType.shiftName}</td>
                  <td>{shift.shiftType.startTime}</td>
                  <td>{shift.shiftType.endTime}</td>
                  <td>{new Date(shift.assignDate).toLocaleDateString()}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="no-shifts">No shift assignments found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
 
export default ViewShifts;