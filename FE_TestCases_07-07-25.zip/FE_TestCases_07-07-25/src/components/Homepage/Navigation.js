import React, { useContext } from 'react';
import { ThemeContext } from './Themecontext';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';
import { FaSun, FaMoon } from 'react-icons/fa';
import './nav.css';

function Navigation() {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const isDark = theme === 'dark';

  return (
    <Navbar expand="lg" style={{ backgroundColor: isDark ? "#074173" : "#ffffff" }}>
      <Container>
        <Navbar.Brand
          href="#"
          style={{
            color: isDark ? "#ffffff" : "#074173",
            fontFamily: "Brush Script MT",
            fontWeight: "bolder",
            fontSize: "30px"
          }}
        >
          <span>Presence</span><span>Hub</span>
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav className="ms-auto d-flex align-items-center gap-3" navbarScroll>
            <button
              onClick={toggleTheme}
              className="theme-toggle-icon"
              aria-label={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              style={{
                background: 'none',
                border: 'none',
                color: isDark ? '#ffffff' : '#074173',
                cursor: 'pointer',
                fontSize: '1.5rem',
                padding: '0.5rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              {isDark ? <FaSun /> : <FaMoon />}
            </button>
            <div className="nav-buttons">
              <Link to="/" className="nav-button-shiny"><span>Home</span></Link>
              <Link to="/login" className="nav-button-shiny"><span>Login</span></Link>
              <Link to="/signup" className="nav-button-shiny"><span>Sign Up</span></Link>
            </div>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Navigation;
