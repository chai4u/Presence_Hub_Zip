import React, { useState, useEffect, useContext } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import TrueFocus from './TrueFocus';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Home.css';
import { ThemeContext } from './Themecontext';

const TypewriterEffect = ({ text }) => {
  const [displayText, setDisplayText] = useState('');

  useEffect(() => {
    let currentIndex = 0;
    const intervalId = setInterval(() => {
      if (currentIndex <= text.length) {
        setDisplayText(text.slice(0, currentIndex));
        currentIndex++;
      } else {
        clearInterval(intervalId);
      }
    }, 150);

    return () => clearInterval(intervalId);
  }, [text]);

  return (
    <motion.h2
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      initial={{ opacity: 0 }}
      className="title"
      style={{ color: "white" }}
    >
      {displayText}
    </motion.h2>
  );
};

const Home = () => {
  const { theme } = useContext(ThemeContext); // Access theme
  const navigate = useNavigate();

  const handleGetStarted = (e) => {
    e.preventDefault();
    navigate('/signup');
  };

  return (
    <div>
      <div>
        <div
          className="static-slider9 position-relative"
          style={{
            backgroundColor: theme === 'dark' ? "black" : "#f5f5f5",
            minHeight: "100vh",
            color: theme === 'dark' ? "white" : "#333"
          }}
        >
          <div className="container">
            <div className="row align-items-center">
              {/* Text Section */}
              <div className="col-md-6">
                <TrueFocus
                  sentence="Presence Hub"
                  manualMode={false}
                  blurAmount={5}
                  borderColor="blue"
                  animationDuration={2}
                  pauseBetweenAnimations={1}
                />
                <br /><br />
                <TypewriterEffect text="The Smarter Way to manage your Workforce..." />
                <form className="form-inline mt-3" onSubmit={handleGetStarted}>
                  <button type="submit" className="btn btn-md btn-success-gradiant text-white border-0 mb-2 nav-button-shiny">
                    <span>Get Started</span>
                  </button>
                </form>
              </div>

              {/* Image Section */}
              <div className="col-md-6 d-flex justify-content-center align-items-center">
                <div
                  style={{
                    backgroundImage: `url('/assets/skill.png')`,
                    backgroundSize: "cover",
                    backgroundRepeat: "no-repeat",
                    backgroundPosition: "center",
                    width: "100%",
                    height: "70vh",
                    borderRadius: "20px",
                    boxShadow: "inset 0 0 30px rgba(74, 151, 244, 0.3), 0 0 40px rgba(74, 151, 244, 0.4)",
                    backdropFilter: "blur(4px)",
                    overflow: "hidden",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
