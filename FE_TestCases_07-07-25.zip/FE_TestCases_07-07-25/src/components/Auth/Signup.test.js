import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Signup from './Signup';
import '@testing-library/jest-dom';

// Mock useNavigate
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));

// Mock axios
jest.mock('axios', () => ({
  post: jest.fn()
}));

describe('Signup Component', () => {
  const renderSignup = () => {
    render(
      <BrowserRouter>
        <Signup />
      </BrowserRouter>
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  // Basic rendering tests
  test('renders signup form fields', () => {
    renderSignup();
    expect(screen.getByPlaceholderText('Full Name')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Email')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Password')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Phone Number (10 digits)')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Employee Code (4-6 characters)')).toBeInTheDocument();
  });

  // Role selection tests
  test('shows manager ID field when employee role is selected', () => {
    renderSignup();
    const roleSelect = screen.getByRole('combobox');
    fireEvent.change(roleSelect, { target: { value: 'employee' } });
    expect(screen.getByPlaceholderText('Manager ID')).toBeInTheDocument();
  });

  test('hides manager ID field when manager role is selected', () => {
    renderSignup();
    const roleSelect = screen.getByRole('combobox');
    fireEvent.change(roleSelect, { target: { value: 'manager' } });
    expect(screen.queryByPlaceholderText('Manager ID')).not.toBeInTheDocument();
  });

  // New test cases using more specific selectors
  test('validates input fields presence', () => {
    renderSignup();
    const submitButton = screen.getByRole('button', { type: 'submit' });
    expect(submitButton).toBeInTheDocument();
    expect(screen.getByRole('combobox')).toHaveAttribute('required');
    expect(screen.getByPlaceholderText('Full Name')).toHaveAttribute('required');
    expect(screen.getByPlaceholderText('Email')).toHaveAttribute('required');
    expect(screen.getByPlaceholderText('Password')).toHaveAttribute('required');
  });

  test('validates phone number pattern', () => {
    renderSignup();
    const phoneInput = screen.getByPlaceholderText('Phone Number (10 digits)');
    expect(phoneInput).toHaveAttribute('pattern', '[0-9]{10}');
  });

  test('validates password title attribute', () => {
    renderSignup();
    const passwordInput = screen.getByPlaceholderText('Password');
    expect(passwordInput).toHaveAttribute(
      'title',
      'Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character'
    );
  });

  test('validates role select options', () => {
    renderSignup();
    const roleSelect = screen.getByRole('combobox');
    const options = screen.getAllByRole('option');
    expect(options).toHaveLength(3); // Default, Employee, Manager
    expect(options[0]).toHaveValue('');
    expect(options[1]).toHaveValue('employee');
    expect(options[2]).toHaveValue('manager');
  });
});