import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Signup.css';
import axios from 'axios';
 
const Signup = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: '',           // Changed from name to fullName
    email: '',
    password: '',
    phone: '',
    employeeCode: '',
    role: '',
    managerId: null        // Changed to null initially, will be converted to number
  });
  const [error, setError] = useState('');
  const [showManagerId, setShowManagerId] = useState(false);
 
  // Password validation regex from backend
  const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/;
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => {
      const newData = { ...prevData, [name]: value };
     
      // Handle managerId based on role
      if (name === 'role') {
        if (value === 'manager') {
          newData.managerId = 1;  // Set as number for managers
          setShowManagerId(false);
        } else if (value === 'employee') {
          newData.managerId = null;  // Reset for employees
          setShowManagerId(true);
        }
      }
     
      // Convert managerId to number when it's input
      if (name === 'managerId' && value) {
        newData.managerId = parseInt(value, 10);
      }
     
      return newData;
    });
  };
 
  const validateForm = () => {
    if (!formData.fullName || formData.fullName.length < 2 || formData.fullName.length > 25) {
      setError('Name must be between 2 and 25 characters');
      return false;
    }
   
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
 
    if (
      !formData.email ||
      formData.email.length < 5 ||
      formData.email.length > 50 ||
      !emailRegex.test(formData.email)
    ) {
      setError('Please enter a valid email address between 5 and 50 characters.');
      return false;
    }
   
   
    if (!formData.phone || formData.phone.length !== 10) {
      setError('Phone number must be exactly 10 characters');
      return false;
    }
   
    if (!formData.employeeCode || formData.employeeCode.length < 4 || formData.employeeCode.length > 6) {
      setError('Employee code must be between 4 and 6 characters');
      return false;
    }
   
    if (!formData.password || formData.password.length < 8 || formData.password.length > 25) {
      setError('Password must be between 8 and 25 characters');
      return false;
    }
   
    if (!passwordRegex.test(formData.password)) {
      setError('Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character');
      return false;
    }
   
    if (formData.role === 'employee' && (!formData.managerId || formData.managerId < 1)) {
      setError('Please enter a valid manager ID');
      return false;
    }
   
    return true;
  };
 
  const handleRegister = async (e) => {
    e.preventDefault();
   
    if (!validateForm()) {
      return;
    }
   
    try {
      const response = await axios.post('http://localhost:8088/api/v1/auth/register/user', formData);
      if (response.data === "User Registered Successfully") {
        navigate('/login');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'User Already Exists.');
    }
  };
 
  return (
    <div className="registration-page">
      <div className="form-container">
        <form className="p-4" onSubmit={handleRegister}>
          <h2 className="text-center mb-4 text-white">Register</h2>
          {error && <div className="alert alert-danger">{error}</div>}
          <div className="mb-3">
            <input
              type="text"
              name="fullName"
              className="form-control"
              style={{ width: "300px" }}
              placeholder="Full Name"
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <input
              type="email"
              name="email"
              className="form-control"
              placeholder="Email"
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <input
              type="password"
              name="password"
              className="form-control"
              placeholder="Password"
              onChange={handleChange}
              required
              title="Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character"
            />
          </div>
          <div className="mb-3">
            <input
              type="tel"
              name="phone"
              className="form-control"
              placeholder="Phone Number (10 digits)"
              onChange={handleChange}
              pattern="[0-9]{10}"
              required
            />
          </div>
          <div className="mb-3">
            <input
              type="text"
              name="employeeCode"
              className="form-control"
              placeholder="Employee Code (4-6 characters)"
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <select
              name="role"
              className="form-select"
              onChange={handleChange}
              required
            >
              <option value="">Select Role</option>
              <option value="employee">Employee</option>
              <option value="manager">Manager</option>
            </select>
          </div>
          {showManagerId && (
            <div className="mb-3">
              <input
                type="number"
                name="managerId"
                className="form-control"
                placeholder="Manager ID"
                onChange={handleChange}
                min="1"
                value={formData.managerId || ''}
                required={formData.role === 'employee'}
              />
            </div>
          )}
          <button type="submit" className="btn btn-primary w-100 nav-button-shiny">
            <span>Register</span>
          </button>
        </form>
      </div>
    </div>
  );
};
 
export default Signup;