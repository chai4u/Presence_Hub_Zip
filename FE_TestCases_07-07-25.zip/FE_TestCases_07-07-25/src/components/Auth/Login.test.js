import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Login from './Login';
import '@testing-library/jest-dom';

// Mock useNavigate
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));

// Mock axios
jest.mock('axios', () => ({
  post: jest.fn()
}));

describe('Login Component', () => {
  const renderLogin = () => {
    render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  // Basic rendering test
  test('renders login form fields', () => {
    renderLogin();
    expect(screen.getByPlaceholderText('Email')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Password')).toBeInTheDocument();
    expect(screen.getByRole('button', { type: 'submit' })).toBeInTheDocument();
  });

  // Input field tests
  test('validates required attributes on form fields', () => {
    renderLogin();
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');

    expect(emailInput).toHaveAttribute('required');
    expect(passwordInput).toHaveAttribute('required');
    expect(emailInput).toHaveAttribute('type', 'email');
    expect(passwordInput).toHaveAttribute('type', 'password');
  });

  // Input change tests
  test('updates input values on change', () => {
    renderLogin();
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });

    expect(emailInput.value).toBe('test@example.com');
    expect(passwordInput.value).toBe('password123');
  });

  // Form elements test
  test('renders form with correct structure', () => {
    renderLogin();
    const form = screen.getByRole('form');
    const loginHeader = screen.getByRole('heading', { name: /login/i });
    
    expect(form).toBeInTheDocument();
    expect(loginHeader).toBeInTheDocument();
  });

  // Button text test
  test('submit button contains correct text', () => {
    renderLogin();
    const submitButton = screen.getByRole('button', { type: 'submit' });
    expect(submitButton.textContent).toBe('Login');
  });

  // Error state test
  test('initially renders without error message', () => {
    renderLogin();
    const errorMessages = screen.queryByRole('alert');
    expect(errorMessages).not.toBeInTheDocument();
  });

  // Class names test
  test('form elements have correct CSS classes', () => {
    renderLogin();
    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');
    const submitButton = screen.getByRole('button', { type: 'submit' });

    expect(emailInput).toHaveClass('form-control');
    expect(passwordInput).toHaveClass('form-control');
    expect(submitButton).toHaveClass('btn', 'btn-primary', 'w-100', 'nav-button-shiny');
  });

  // Form container test
  test('renders with correct container classes', () => {
    renderLogin();
    expect(screen.getByRole('form')).toHaveClass('p-4');
    expect(screen.getByRole('form').parentElement).toHaveClass('form-container');
  });

  // Image test
  test('renders logo image', () => {
    renderLogin();
    const logoImage = screen.getByAltText('Logo');
    expect(logoImage).toBeInTheDocument();
    expect(logoImage).toHaveAttribute('src', '/assets/logo.png');
  });
});