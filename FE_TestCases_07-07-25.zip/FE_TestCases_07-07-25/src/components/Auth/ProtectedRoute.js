import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';

const ProtectedRoute = ({ allowedRole }) => {
  const userRole = localStorage.getItem('userRole');
  const isAuthenticated = localStorage.getItem('authToken');

  if (!isAuthenticated) {
    // Not logged in, redirect to login page
    return <Navigate to="/login" />;
  }

  if (userRole !== allowedRole) {
    // Not authorized, redirect to appropriate dashboard or login
    if (userRole === 'employee') {
      return <Navigate to="/employee" />;
    } else if (userRole === 'manager') {
      return <Navigate to="/manager" />;
    } else if (userRole === 'admin') {
      return <Navigate to="/admin" />;
    } else {
      return <Navigate to="/login" />;
    }
  }

  // Authorized, render child elements
  return <Outlet />;
};

export default ProtectedRoute;