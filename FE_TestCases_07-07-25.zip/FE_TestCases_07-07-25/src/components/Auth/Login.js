import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Login.css';
import axios from 'axios';
 
const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
 
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8088/api/v1/auth/login/user', {
        email,
        password,
      });
 
      const { fullName, email: userEmail, token, id, role, managerId, managerName } = response.data;
 
      // Store token and user info
      localStorage.setItem('authToken', token);
      localStorage.setItem('userEmail', userEmail);
      localStorage.setItem('userFullName', fullName);
      localStorage.setItem('userId', id);
     
      // If user is a manager, their ID is their managerId
      // if (role === 'manager') {
      //   localStorage.setItem('managerId', id);
      // } else if (role === 'employee' && managerId) {
      //   // For employees, set their assigned manager's ID and name
      //   localStorage.setItem('managerId', managerId);
      //   localStorage.setItem('managerName', managerName);
      // }
      if (role === 'manager') {
        localStorage.setItem('managerId', id); // Store manager's own ID
        localStorage.setItem('managerName', fullName);
      } else if (role === 'employee' && managerId) {
        localStorage.setItem('managerId', managerId);
        localStorage.setItem('managerName', managerName);
      }else if (role === 'admin') {
        localStorage.setItem('managerId', '1'); // Set managerId to 1 for admin
        localStorage.setItem('managerName', 'Admin'); // Optional: Set a default manager name
      }
     
      localStorage.setItem('userRole', role);
 
      // Navigate based on role
      if (role === 'admin') {
        navigate('/admin');
      } else if (role === 'manager') {
        navigate('/manager');
      } else {
        navigate('/employee');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed.');
    }
  };
 
  return (
    <div className="login-page">
      <img src="/assets/logo.png" alt="Logo" />
      <div className="form-container">
        <form className="p-4" onSubmit={handleLogin} role="form">
          <h2 className="text-center mb-4 text-white">Login</h2>
          {error && <div className="alert alert-danger">{error}</div>}
          <div className="mb-3">
            <input
              type="email"
              className="form-control"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="mb-3">
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary w-100 nav-button-shiny">
            <span>Login</span>
          </button>
        </form>
      </div>
    </div>
  );
};
 
export default Login;
