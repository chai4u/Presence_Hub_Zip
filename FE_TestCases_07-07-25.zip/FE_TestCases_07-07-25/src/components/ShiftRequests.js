import React, { useState } from 'react';
import './ShiftRequests.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck, faTimes, faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});

// Add interceptor to automatically add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

const ShiftRequests = () => {
  const navigate = useNavigate();
  const [sentRequests, setSentRequests] = useState([]);
  const [receivedRequests, setReceivedRequests] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('received'); // 'sent' or 'received'

  const fetchReceivedRequests = async () => {
    try {
      setLoading(true);
      const userId = localStorage.getItem('userId');
      const response = await api.get(`/api/v1/shift/employee/swap/requests/target/${userId}`);
      setReceivedRequests(response.data || []);
    } catch (error) {
      toast.error('Failed to fetch received requests');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSentRequests = async () => {
    try {
      setLoading(true);
      const userId = localStorage.getItem('userId');
      const response = await api.get(`/api/v1/shift/employee/swap/requests/requester/${userId}`);
      setSentRequests(response.data || []);
    } catch (error) {
      toast.error('Failed to fetch sent requests');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = async (tab) => {
    setActiveTab(tab);
    if (tab === 'received' && receivedRequests.length === 0) {
      await fetchReceivedRequests();
    } else if (tab === 'sent' && sentRequests.length === 0) {
      await fetchSentRequests();
    }
  };

  const handleApprove = async (id) => {
    try {
      await api.put(`/api/v1/shift/employee/swap/approve/${id}`);
      toast.success('Swap request approved successfully');
      await fetchReceivedRequests();
    } catch (error) {
      toast.error('Failed to approve swap request');
      console.error('Error:', error);
    }
  };

  const handleReject = async (id) => {
    try {
      await api.put(`/api/v1/shift/employee/swap/reject/${id}`);
      toast.success('Swap request rejected successfully');
      await fetchReceivedRequests();
    } catch (error) {
      toast.error('Failed to reject swap request');
      console.error('Error:', error);
    }
  };

  const formatShiftTime = (shift) => {
    if (!shift) return 'N/A';
    return `${shift.shiftName} (${shift.startTime} - ${shift.endTime})`;
  };

  const renderShiftInfo = (request, isRequester) => {
    const shift = isRequester ? request.requesterShift : request.targetShift;
    return formatShiftTime(shift);
  };

  if (loading) {
    return (
      <div className="shift-requests-container">
        <div className="loading">Loading...</div>
      </div>
    );
  }

  const currentRequests = activeTab === 'sent' ? sentRequests : receivedRequests;

  return (
    <div className="shift-requests-container">
      <Toaster position="top-right" />
      
      <div className="shift-header">
        <h2 className="shift-requests-title">Shift Swap Requests</h2>
      </div>

      <div className="requests-tabs">
        <button 
          className={`tab-btn ${activeTab === 'received' ? 'active' : ''}`}
          onClick={() => handleTabChange('received')}
        >
          Received Requests
        </button>
        <button 
          className={`tab-btn ${activeTab === 'sent' ? 'active' : ''}`}
          onClick={() => handleTabChange('sent')}
        >
          Sent Requests
        </button>
      </div>

      <div className="table-wrapper">
        <table className="requests-table">
          <thead>
            <tr>
              <th>Request ID</th>
              <th>{activeTab === 'sent' ? 'Target Employee ID' : 'Requester ID'}</th>
              <th>Your Shift</th>
              <th>Other Shift</th>
              <th>Swap Date</th>
              <th>Reason</th>
              <th>Status</th>
              {activeTab === 'received' && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {currentRequests.length > 0 ? (
              currentRequests.map((request) => (
                <tr key={request.id}>
                  <td>{request.id}</td>
                  <td>{activeTab === 'sent' ? request.targetEmployeeId : request.requesterEmployeeId}</td>
                  <td>{activeTab === 'sent' 
                    ? renderShiftInfo(request, true)
                    : renderShiftInfo(request, false)
                  }</td>
                  <td>{activeTab === 'sent'
                    ? renderShiftInfo(request, false)
                    : renderShiftInfo(request, true)
                  }</td>
                  <td>{new Date(request.swapDate).toLocaleDateString()}</td>
                  <td>{request.reason}</td>
                  <td>
                    <span className={`status-badge ${request.status?.toLowerCase() || 'pending'}`}>
                      {request.status || 'Pending'}
                    </span>
                  </td>
                  {activeTab === 'received' && (
                    <td className="actions">
                      {(!request.status || request.status === 'PENDING') && (
                        <>
                          <button
                            className="action-btn accept"
                            onClick={() => handleApprove(request.id)}
                          >
                            <FontAwesomeIcon icon={faCheck} />
                            <span>Accept</span>
                          </button>
                          <button
                            className="action-btn reject"
                            onClick={() => handleReject(request.id)}
                          >
                            <FontAwesomeIcon icon={faTimes} />
                            <span>Reject</span>
                          </button>
                        </>
                      )}
                    </td>
                  )}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={activeTab === 'received' ? 8 : 7} className="no-requests">
                  No {activeTab} requests found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <button 
        className="back-btn" 
        onClick={() => navigate('/employee/shift')}
      >
        Back to Dashboard
      </button>
    </div>
  );
};

export default ShiftRequests;