// src/components/Dashboard/Sidebar.js
import React from 'react';
import { Link } from 'react-router-dom';
import './Dashboard.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faUserClock,
  faCalendarAlt,
  faClock,
  faChartBar
} from '@fortawesome/free-solid-svg-icons';

const Sidebar = () => {
  return (
    <div className="sidebar">
      <h3 className="sidebar-title">Employee</h3>
      <div className="sidebar-links">
        <Link to="/employee/attendance" className="sidebar-link">
          <FontAwesomeIcon icon={faUserClock} className="sidebar-icon" />
          <span>Attendance</span>
        </Link>
        <Link to="/employee/leave" className="sidebar-link">
          <FontAwesomeIcon icon={faCalendarAlt} className="sidebar-icon" />
          <span>Leave</span>
        </Link>
        <Link to="/employee/shift" className="sidebar-link">
          <FontAwesomeIcon icon={faClock} className="sidebar-icon" />
          <span>Shift</span>
        </Link>
        <Link to="/employee/report" className="sidebar-link">
          <FontAwesomeIcon icon={faChartBar} className="sidebar-icon" />
          <span>Report</span>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
