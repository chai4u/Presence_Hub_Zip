// src/components/Dashboard/EmployeeDashboard.js
import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Header from '../Header';
import Sidebar from './Employee_Sidebar';
import './Dashboard.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faUserGroup,
  faChartLine,
  faLightbulb,
  faScaleBalanced,
  faHandHoldingHeart
} from '@fortawesome/free-solid-svg-icons';

const Employee_dashboard = () => {
  const employeeName = localStorage.getItem('userFullName');
  const location = useLocation();
  const isMainDashboard = location.pathname === '/employee';

  const coreValues = [
    { text: "Work as one", icon: faUserGroup },
    { text: "Raise the bar", icon: faChartLine },
    { text: "Dare to innovate", icon: faLightbulb },
    { text: "Do the right thing", icon: faScaleBalanced },
    { text: "Own it", icon: faHandHoldingHeart }
  ];

  return (
    <div className="dashboard-container">
      <Header />
      <Sidebar />
      <div className="content">
        {isMainDashboard && (
          <>
            <div className="welcome-message">
              Welcome, {employeeName}! 👋
            </div>
            <div className="dashboard-main-content">
              <div className="core-values-section">
                <div className="core-values-container">
                  {coreValues.map((value, index) => (
                    <div key={index} className="core-value-text">
                      <FontAwesomeIcon icon={value.icon} className="value-icon" />
                      <span>{value.text}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="dashboard-image">
                <img src="/assets/image7.jpg" alt="Dashboard illustration" />
              </div>
            </div>
          </>
        )}
        <Outlet />
      </div>
    </div>
  );
};

export default Employee_dashboard;
