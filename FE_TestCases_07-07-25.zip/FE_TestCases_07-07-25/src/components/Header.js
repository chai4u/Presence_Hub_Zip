// src/components/Dashboard/Header.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './EmployeeDashboard/Dashboard.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faBell } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
 
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});
 
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
 
const Header = () => {
  const navigate = useNavigate();
  const [showProfile, setShowProfile] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
 
  const userDetails = {
    fullName: localStorage.getItem('userFullName'),
    email: localStorage.getItem('userEmail'),
    role: localStorage.getItem('userRole'),
    id: localStorage.getItem('userId'),
    managerName: localStorage.getItem('managerName')
  };
 
  const fetchNotifications = async () => {
    try {
      const userId = localStorage.getItem('userId');
      const userRole = localStorage.getItem('userRole');
      let allNotifications = [];
     
      if (userRole === 'manager') {
        const response = await api.get(`/api/v1/leave/manager/getAllRequests/${userId}`);
        const pendingRequests = response.data.filter(req => req.status === 'PENDING');
        const leaveNotifications = pendingRequests.map(req => ({
          id: `leave_${req.leaveId}`,
          message: `Leave request from Employee ID: ${req.userId}`,
          time: new Date(req.startDate).toLocaleDateString()
        }));
        allNotifications = [...allNotifications, ...leaveNotifications];
      }
 
      if (userRole === 'employee') {
        try {
          const response = await api.get(`/api/v1/shift/employee/swap/requests/target/${userId}`);
          if (response.data && Array.isArray(response.data)) {
            const pendingSwaps = response.data.filter(req => (!req.status || req.status === 'PENDING'));
            const swapNotifications = pendingSwaps.map(req => ({
              id: `swap_${req.id}`,
              message: `Shift swap request for ${req.targetShift?.shiftName || 'your shift'}`,
              details: `From Employee ${req.requesterEmployeeId}`,
              time: new Date(req.swapDate).toLocaleDateString()
            }));
            allNotifications = [...allNotifications, ...swapNotifications];
          }
        } catch (swapError) {
          console.error('Error fetching swap notifications:', swapError);
        }
      }
     
      setNotifications(allNotifications);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  };
 
  useEffect(() => {
    fetchNotifications();
    // Fetch notifications every 5 minutes
    const interval = setInterval(fetchNotifications, 300000);
    return () => clearInterval(interval);
  }, []);
 
  const handleLogout = () => {
    // Clear all localStorage items
    localStorage.removeItem('authToken');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userFullName');
    localStorage.removeItem('userId');
    localStorage.removeItem('managerId');
    localStorage.removeItem('userRole');
   
    // Navigate to home page
    navigate('/');
  };
 
  return (
    <div className="header">
      <div className="logo">
        <p style={{
            color: "#ffffff",
            fontFamily: "Brush Script MT",
            fontWeight: "bolder",
            fontSize: "35px",
            textShadow: "2px 2px 4px rgba(0, 0, 0, 0.5)",
            margin: "2",
          }}
        >
          <span>Presence</span><span>Hub</span> </p>
      </div>
      <div className="header-controls">
        <div className="notification-container">
          <div className="notification-icon" onClick={() => setShowNotifications(!showNotifications)}>
            <FontAwesomeIcon icon={faBell} />
            {notifications.length > 0 && (
              <span className="notification-badge">{notifications.length}</span>
            )}
          </div>
          {showNotifications && (
            <div className="notification-dropdown">
              <div className="notification-header">
                <h3>Notifications</h3>
              </div>
              <div className="notification-details">
                {notifications.length === 0 ? (
                  <div className="notification-item">
                    <div className="notification-row">
                      <label>Status:</label>
                      <span>No pending requests</span>
                    </div>
                  </div>
                ) : (
                  notifications.map(notification => (
                    <div key={notification.id} className="notification-item">
                      <div className="notification-row">
                        <label>Request:</label>
                        <span>{notification.message}</span>
                      </div>
                      {notification.details && (
                        <div className="notification-row">
                          <label>From:</label>
                          <span>{notification.details}</span>
                        </div>
                      )}
                      <div className="notification-row">
                        <label>Date:</label>
                        <span>{notification.time}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
        <div className="profile-container">
          <button
            className="profile-btn"
            onClick={() => setShowProfile(!showProfile)}
          >
            <FontAwesomeIcon icon={faUser} />
          </button>
          {showProfile && (
            <div className="profile-dropdown">
              <div className="profile-header">
                <h3>User Profile</h3>
              </div>
              <div className="profile-details">
                <div className="profile-item">
                  <label>Name:</label>
                  <span>{userDetails.fullName}</span>
                </div>
                <div className="profile-item">
                  <label>Email:</label>
                  <span>{userDetails.email}</span>
                </div>
                <div className="profile-item">
                  <label>Role:</label>
                  <span>{userDetails.role}</span>
                </div>
                <div className="profile-item">
                  <label>ID:</label>
                  <span>{userDetails.id}</span>
                </div>
                {userDetails.role === 'employee' && userDetails.managerName && (
                  <div className="profile-item">
                    <label>Manager Name:</label>
                    <span>{userDetails.managerName}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
        <button className="btn btn-outline-light" onClick={handleLogout}>
          Logout
        </button>
      </div>
    </div>
  );
};
 
export default Header;
 
 