import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './ViewReport.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faDownload } from '@fortawesome/free-solid-svg-icons';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import DateTimeHeader from './DateTimeHeader';
 
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);
 
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});
 
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});
 
const ViewEmployeeReport = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const userRole = localStorage.getItem('userRole'); // Add this line
  const { report } = location.state || {};
  const [attendanceData, setAttendanceData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [leaveBalance, setLeaveBalance] = useState(null);
 
  const calculateHours = (clockIn, clockOut) => {
    if (!clockIn || !clockOut) return 0;
    const start = new Date(clockIn);
    const end = new Date(clockOut);
    return (end - start) / (1000 * 60 * 60); // Convert milliseconds to hours
  };
 
  useEffect(() => {
    const fetchData = async () => {
      if (!report) return;
      try {
        const formattedStartDate = new Date(report.startDate).toISOString().split('T')[0];
        const formattedEndDate = new Date(report.endDate).toISOString().split('T')[0];
 
        // Make API calls in parallel for better performance
        const [attendanceResponse, leaveBalanceResponse] = await Promise.all([
          api.get(
            `/api/v1/attendance/employee/history/${report.employeeId}/${formattedStartDate}/${formattedEndDate}`
          ),
          api.get(`/api/v1/leave/employee/balance/${report.employeeId}`)
        ]);
 
        if (!Array.isArray(attendanceResponse.data)) {
          throw new Error('Attendance data is not in expected format');
        }
 
        // Process attendance data for the chart
        const processedData = attendanceResponse.data
          .filter(record => record.isPresent)
          .map(record => ({
            date: new Date(record.date).toISOString().split('T')[0],
            hours: calculateHours(record.clockIn, record.clockOut)
          }));
 
        setAttendanceData(processedData);
 
        // Process leave balance data
        if (Array.isArray(leaveBalanceResponse.data) && leaveBalanceResponse.data.length > 0) {
          const leaveData = Array.isArray(leaveBalanceResponse.data[0])
            ? leaveBalanceResponse.data[0]
            : leaveBalanceResponse.data;
 
          // Sort leaves to ensure Sick and Vacation are in the desired order
          const sortedLeaves = leaveData.sort((a, b) => {
            const order = { 'Sick': 1, 'Vacation': 2 };
            return order[a.leaveType.name] - order[b.leaveType.name];
          });
 
          // Filter to only show Sick and Vacation leaves and convert to object format
          const processedLeaveData = sortedLeaves
            .filter(leave => ['Sick', 'Vacation'].includes(leave.leaveType.name))
            .reduce((acc, leave) => {
              acc[`${leave.leaveType.name} Leave`] = leave.balance;
              return acc;
            }, {});
 
          console.log('Processed leave balance data:', processedLeaveData);
         
          if (Object.keys(processedLeaveData).length > 0) {
            setLeaveBalance(processedLeaveData);
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        toast.error('Failed to fetch report data');
      } finally {
        setLoading(false);
      }
    };
 
    fetchData();
  }, [report]);
 
  const chartData = {
    labels: attendanceData.map(day => new Date(day.date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    })),
    datasets: [
      {
        label: 'Working Hours',
        data: attendanceData.map(day => Number(day.hours.toFixed(2))),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };
 
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        title: {
          display: true,
          text: 'Date',
          color: 'white',
          font: {
            size: 14,
            weight: 'bold'
          }
        },
        ticks: {
          color: 'white',
          maxRotation: 45,
          minRotation: 45,
          autoSkip: false
        },
        grid: {
          color: 'rgba(255, 255, 255, 0.1)'
        }
      },
      y: {
        beginAtZero: true,
        max: 10,
        title: {
          display: true,
          text: 'Working Hours',
          color: 'white',
          font: {
            size: 14,
            weight: 'bold'
          }
        },
        ticks: {
          color: 'white',
          stepSize: 1,
          callback: (value) => `${value}h`
        },
        grid: {
          color: 'rgba(255, 255, 255, 0.1)'
        }
      }
    },
    plugins: {
      title: {
        display: true,
        text: 'Daily Working Hours',
        color: 'white',
        font: {
          size: 16,
          weight: 'bold'
        }
      },
      legend: {
        labels: {
          color: 'white',
          font: {
            size: 12
          }
        }
      },
      tooltip: {
        callbacks: {
          label: (context) => {
            const hours = context.parsed.y;
            const minutes = Math.round((hours % 1) * 60);
            return `${Math.floor(hours)}h ${minutes}m`;
          }
        }
      }
    }
  };
 
  // Add leave balance donut chart configuration
  const leaveBalanceData = {
    labels: leaveBalance ? Object.keys(leaveBalance) : [],
    datasets: [{
      data: leaveBalance ? Object.values(leaveBalance) : [],
      backgroundColor: [
        'rgba(255, 99, 132, 0.8)',  // Pink for Sick Leave
        'rgba(54, 162, 235, 0.8)',  // Blue for Vacation Leave
      ],
      borderColor: [
        'rgba(255, 99, 132, 1)',
        'rgba(54, 162, 235, 1)',
      ],
      borderWidth: 1,
    }],
  };
 
  const donutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '70%',
    plugins: {
      title: {
        display: true,
        text: 'Leave Balance',
        color: 'white',
        font: {
          size: 16,
          weight: 'bold'
        }
      },
      legend: {
        position: 'right',
        labels: {
          color: 'white',
          padding: 20,
          font: {
            size: 12
          },
          generateLabels: (chart) => {
            const data = chart.data;
            if (data.labels.length && data.datasets.length) {
              return data.labels.map((label, i) => ({
                text: `${label}: ${data.datasets[0].data[i]} days`,
                fillStyle: data.datasets[0].backgroundColor[i],
                strokeStyle: data.datasets[0].borderColor[i],
                lineWidth: 1,
                hidden: false,
                index: i
              }));
            }
            return [];
          }
        }
      },
      tooltip: {
        callbacks: {
          label: (context) => {
            return `${context.label}: ${context.raw} days`;
          }
        }
      }
    }
  };
 
  const handleDownloadPDF = async () => {
    try {
      const response = await api.get(`/api/v1/reports/employee/pdf/${report.employeeId}`, {
        responseType: 'blob'
      });
 
      // Create a blob from the PDF bytes
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
     
      // Create a temporary link and trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = `employee_attendance_report_${report.employeeId}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
 
      toast.success('Report downloaded successfully!');
    } catch (error) {
      console.error('Error downloading PDF:', error);
      toast.error('Failed to download report');
    }
  };
 
  if (loading) {
    return (
      <div className="view-report-container">
        <div className="loading-spinner">Loading...</div>
      </div>
    );
  }
 
  // Update the back button navigation in both places where it appears
  // First instance (in the loading check)
  if (!report) {
    return (
      <div className="view-report-container">
        <DateTimeHeader />
        <div className="report-header">
          <button
            className="back-button"
            onClick={() => navigate(`/${userRole}/Reports_man`)}
          >
            <FontAwesomeIcon icon={faArrowLeft} />
            <span>Back</span>
          </button>
          <h2 className="report-title">No Report Available</h2>
        </div>
      </div>
    );
  }
 
  // Second instance (in the main return)
  return (
    <div className="view-report-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
     
      <div className="report-header">
        <button
          className="back-button"
          onClick={() => navigate(`/${userRole}/Reports_man`)}
        >
          <FontAwesomeIcon icon={faArrowLeft} />
          <span>Back</span>
        </button>
        <h2 className="report-title">Employee Report</h2>
        <button className="download-btn" onClick={handleDownloadPDF}>
          <FontAwesomeIcon icon={faDownload} />
          <span>Download PDF</span>
        </button>
      </div>
 
      <div className="report-card">
        <div className="report-info-grid">
          <div className="info-item">
            <label>Employee Name</label>
            <span>{report.employeeName}</span>
          </div>
          <div className="info-item">
            <label>Employee ID</label>
            <span>{report.employeeId}</span>
          </div>
          <div className="info-item">
            <label>Start Date</label>
            <span>{new Date(report.startDate).toLocaleDateString()}</span>
          </div>
          <div className="info-item">
            <label>End Date</label>
            <span>{new Date(report.endDate).toLocaleDateString()}</span>
          </div>
          <div className="info-item highlight">
            <label>Total Attendance</label>
            <span>{report.totalAttendance} days</span>
          </div>
          <div className="info-item highlight">
            <label>Absenteeism</label>
            <span>{report.absenteeism} days</span>
          </div>
        </div>
      </div>
 
      <div className="chart-container">
        <Bar data={chartData} options={chartOptions} />
      </div>
 
      {leaveBalance && (
        <div className="chart-container" style={{ height: '400px', marginTop: '2rem' }}>
          <Doughnut data={leaveBalanceData} options={donutOptions} />
        </div>
      )}
    </div>
  );
};
 
export default ViewEmployeeReport;
 