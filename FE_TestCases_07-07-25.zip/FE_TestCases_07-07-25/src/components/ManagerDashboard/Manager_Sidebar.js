// src/components/Dashboard/Sidebar.js
import React from 'react';
import { Link } from 'react-router-dom';
import '../EmployeeDashboard/Dashboard.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faUserClock,
  faCalendarAlt,
  faChartBar,
  faUsersCog,
  faClipboardList,
  faFileAlt
} from '@fortawesome/free-solid-svg-icons';

const Sidebar = () => {
  return (
    <div className="sidebar">
      <h3 className="sidebar-title">Manager</h3>
      <div className="sidebar-links">
        <Link to="/manager/attendance" className="sidebar-link">
          <FontAwesomeIcon icon={faUserClock} className="sidebar-icon" />
          <span>Attendance</span>
        </Link>
        <Link to="/manager/leave" className="sidebar-link">
          <FontAwesomeIcon icon={faCalendarAlt} className="sidebar-icon" />
          <span>Leave</span>
        </Link>
        <Link to="/manager/report" className="sidebar-link">
          <FontAwesomeIcon icon={faChartBar} className="sidebar-icon" />
          <span>Report</span>
        </Link>
        <Link to="/manager/shift_assign" className="sidebar-link">
          <FontAwesomeIcon icon={faUsersCog} className="sidebar-icon" />
          <span>Assign Shift</span>
        </Link>
        <Link to="/manager/Leave_req_man" className="sidebar-link">
          <FontAwesomeIcon icon={faClipboardList} className="sidebar-icon" />
          <span>Leave Requests</span>
        </Link>
        <Link to="/manager/Reports_man" className="sidebar-link">
          <FontAwesomeIcon icon={faFileAlt} className="sidebar-icon" />
          <span>Employee Reports</span>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
