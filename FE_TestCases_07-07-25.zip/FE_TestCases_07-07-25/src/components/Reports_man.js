import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Reports_man.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFileAlt, faSearch, faCalendarAlt } from '@fortawesome/free-solid-svg-icons';
import DateTimeHeader from './DateTimeHeader';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
 
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});
 
// Add token interceptor
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});
 
const Reports_man = () => {
  const navigate = useNavigate();
  const userRole = localStorage.getItem('userRole');
  const [employeeId, setEmployeeId] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [loading, setLoading] = useState(false);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [loadingEmployees, setLoadingEmployees] = useState(true);
 
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const managerId = localStorage.getItem('managerId');
        if (!managerId) {
          toast.error('Manager ID not found. Please login again.');
          return;
        }
 
        const response = await api.get(`/api/v1/auth/user/manager/${managerId}`);
        if (response.data && Array.isArray(response.data)) {
          setEmployees(response.data);
        } else {
          toast.error('Invalid response format from server');
        }
      } catch (error) {
        console.error('Error fetching employees:', error);
        toast.error('Failed to fetch employees list');
      } finally {
        setLoadingEmployees(false);
      }
    };
 
    fetchEmployees();
  }, []);
 
  const handleViewAllReports = async () => {
    if (!startDate || !endDate) {
      toast.error('Please select both start and end dates');
      return;
    }

    if (new Date(startDate) > new Date(endDate)) {
      toast.error('Start date cannot be after end date');
      return;
    }

    setLoading(true);
    try {
      const managerId = localStorage.getItem('managerId');
      const response = await api.post(
        `/api/v1/reports/manager/generate/${managerId}`,
        null,
        {
          params: {
            startDate: startDate,
            endDate: endDate
          }
        }
      );
      
      if (response.data.length === 0) {
        toast.info('No reports found for the selected date range');
        return;
      }

      // Update navigation path based on role
      const basePath = userRole === 'admin' ? '/admin' : '/manager';
      navigate(`${basePath}/view-manager-reports`, {
        state: {
          startDate: startDate,
          endDate: endDate,
          reports: response.data
        }
      });
    } catch (error) {
      console.error('Error fetching reports:', error);
      toast.error('Failed to fetch reports');
    } finally {
      setLoading(false);
    }
  };
 
  const handleGenerateReport = async () => {
    if (!employeeId || !startDate || !endDate) {
      toast.error('Please fill in all fields');
      return;
    }
 
    if (new Date(startDate) > new Date(endDate)) {
      toast.error('Start date cannot be after end date');
      return;
    }
 
    setGeneratingReport(true);
    try {
      const response = await api.post('/api/v1/reports/employee/generate', {
        employeeId: parseInt(employeeId),
        startDate: startDate,
        endDate: endDate
      });
     
      // Update navigation path based on role
      const basePath = userRole === 'admin' ? '/admin' : '/manager';
      navigate(`${basePath}/view-employee-report`, {
        state: {
          report: response.data
        }
      });
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Failed to generate report');
    } finally {
      setGeneratingReport(false);
    }
  };
 
  return (
    <div className="reports-man-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
      <h2 className="reports-man-title">Reports Management</h2>
 
      <div className="date-selection-container">
        <div className="date-column">
          <div className="date-input-group">
            <FontAwesomeIcon icon={faCalendarAlt} className="calendar-icon" />
            <input
              type="date"
              className="date-input"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              placeholder="Start Date"
            />
            <label>Start Date</label>
          </div>
        </div>
        <div className="date-column">
          <div className="date-input-group">
            <FontAwesomeIcon icon={faCalendarAlt} className="calendar-icon" />
            <input
              type="date"
              className="date-input"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              placeholder="End Date"
            />
            <label>End Date</label>
          </div>
        </div>
      </div>
 
      <button
        className="view-all-reports-btn"
        onClick={handleViewAllReports}
        disabled={loading || !startDate || !endDate}
      >
        <FontAwesomeIcon icon={faFileAlt} />
        <span>{loading ? 'Loading...' : 'View All Reports'}</span>
      </button>
 
      <div className="generate-report-section">
        <div className="employee-input-group">
          <select
            className="employee-select"
            value={employeeId}
            onChange={(e) => setEmployeeId(e.target.value)}
            disabled={loadingEmployees}
          >
            <option value="">Select Employee</option>
            {employees.map(employee => (
              <option key={employee.id} value={employee.id}>
                {employee.name} (ID: {employee.id})
              </option>
            ))}
          </select>
          {loadingEmployees && <span className="loading-text">Loading employees...</span>}
        </div>
 
        <button
          className="generate-report-btn"
          onClick={handleGenerateReport}
          disabled={generatingReport || !employeeId || !startDate || !endDate}
        >
          <FontAwesomeIcon icon={faSearch} />
          <span>{generatingReport ? 'Generating...' : 'Generate Report'}</span>
        </button>
      </div>
    </div>
  );
};
 
export default Reports_man;
