import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import './Leave.css';
import DateTimeHeader from './DateTimeHeader';

// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

const LeaveBalance = () => {
  const navigate = useNavigate();
  const [balances, setBalances] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const userRole = localStorage.getItem('userRole');
  const basePath = userRole === 'manager' ? '/manager' : '/employee';

  useEffect(() => {
    const fetchLeaveBalances = async () => {
      try {
        const employeeId = localStorage.getItem('userId');
        const response = await api.get(`/api/v1/leave/employee/balance/${employeeId}`);
        if (Array.isArray(response.data) && response.data.length > 0) {
          const leaveData = Array.isArray(response.data[0]) ? response.data[0] : response.data;
          // Sort leaves to ensure Sick and Vacation are in the desired order
          const sortedLeaves = leaveData.sort((a, b) => {
            const order = { 'Sick': 1, 'Vacation': 2 };
            return order[a.leaveType.name] - order[b.leaveType.name];
          });
          // Filter to only show Sick and Vacation leaves
          const filteredLeaves = sortedLeaves.filter(leave => 
            ['Sick', 'Vacation'].includes(leave.leaveType.name)
          );
          setBalances(filteredLeaves);
        } else {
          setBalances([]);
        }
      } catch (err) {
        setError('Failed to fetch leave balances');
        console.error('Error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchLeaveBalances();
  }, []);

  if (loading) return <div className="loading">Loading...</div>;
  if (error) return <div className="error">{error}</div>;
  if (!Array.isArray(balances) || balances.length === 0) {
    return <div className="no-balance">No leave balance data available</div>;
  }

  return (
    <div className="leave-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
      <h2 className="leave-title">Leave Balance</h2>
      <div className="balance-cards">
        {balances.map((balance) => (
          <div key={balance.id} className="balance-card">
            <h3>{balance.leaveType.name} Leave</h3>
            <div className="balance-info">
              <span className="balance-days">{balance.balance}</span>
              <span className="days-label">days remaining</span>
            </div>
          </div>
        ))}
      </div>
      <button className="back-btn" onClick={() => navigate(`${basePath}/leave`)}>
        Back to Leave Dashboard
      </button>
    </div>
  );
};

export default LeaveBalance;