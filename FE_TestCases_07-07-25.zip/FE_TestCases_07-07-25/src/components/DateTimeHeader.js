import React, { useState } from 'react';
import './DateTimeHeader.css';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarAlt } from '@fortawesome/free-solid-svg-icons';

const DateTimeHeader = () => {
  const [showCalendar, setShowCalendar] = useState(false);
  const currentDate = new Date(); // Will remain static
  
  const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const formattedDate = currentDate.toLocaleDateString('en-US', dateOptions);
  
  const calendarDate = currentDate.getDate();
  const calendarMonth = currentDate.toLocaleString('default', { month: 'short' });

  const handleCalendarClick = () => {
    setShowCalendar(!showCalendar);
  };

  return (
    <div className="datetime-header">
      <div className="current-date">
        {formattedDate}
      </div>
      <div className="calendar-container">
        <button className="calendar-widget" onClick={handleCalendarClick}>
          <div className="calendar-icon">
            <FontAwesomeIcon icon={faCalendarAlt} className="calendar-fa-icon" />
            <div className="calendar-mini">
              <span className="calendar-month">{calendarMonth}</span>
              <span className="calendar-day">{calendarDate}</span>
            </div>
          </div>
        </button>
        {showCalendar && (
          <div className="calendar-popup">
            <Calendar
              value={currentDate}
              className="custom-calendar"
              tileDisabled={() => true} // Makes calendar read-only
              onClickDay={(value, event) => event.preventDefault()} // Prevents date selection
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default DateTimeHeader;