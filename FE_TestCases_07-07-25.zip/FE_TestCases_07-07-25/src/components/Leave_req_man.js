import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Leave_req_man.css';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import DateTimeHeader from './DateTimeHeader';
 
// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});
 
// Add interceptor to automatically add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});
 
const Leave_req_man = () => {
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [loading, setLoading] = useState(true);
 
  const fetchLeaveRequests = async () => {
    try {
      const managerId = localStorage.getItem('userId');
      const response = await api.get(`/api/v1/leave/manager/getAllRequests/${managerId}`);
      setLeaveRequests(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching leave requests:', error);
      toast.error('Failed to fetch leave requests');
      setLoading(false);
    }
  };
 
  useEffect(() => {
    fetchLeaveRequests();
  }, []);
 
  const handleAction = async (leaveId, action) => {
    try {
      if (action === 'accepted') {
        await api.put(`/api/v1/leave/manager/approve/${leaveId}`);
        toast.success('Leave request approved successfully');
      } else if (action === 'rejected') {
        await api.put(`/api/v1/leave/manager/reject/${leaveId}`);
        toast.success('Leave request rejected successfully');
      }
     
      // Refresh the leave requests after action
      fetchLeaveRequests();
    } catch (error) {
      console.error('Error updating leave request:', error);
      const errorMessage = error.response?.data?.message || 'Failed to update leave request';
      toast.error(errorMessage);
    }
  };
 
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };
 
  if (loading) {
    return <div className="loading">Loading...</div>;
  }
 
  return (
    <div className="leave-requests-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
      <h2 className="leave-requests-title">Leave Requests</h2>
     
      <div className="table-wrapper">
        <table className="requests-table">
          <thead>
            <tr>
              <th>Employee ID</th>
              <th>Leave Type</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {leaveRequests.length === 0 ? (
              <tr>
                <td colSpan="7" className="no-requests">No leave requests found</td>
              </tr>
            ) : (
              leaveRequests.map((request) => (
                <tr key={request.leaveId}>
                  <td>{request.userId}</td>
                  <td>{request.leaveType.name}</td>
                  <td>{formatDate(request.startDate)}</td>
                  <td>{formatDate(request.endDate)}</td>
                  <td>{request.reason}</td>
                  <td>
                    <span className={`status-badge ${request.status.toLowerCase()}`}>
                      {request.status}
                    </span>
                  </td>
                  <td className="actions">
                    {request.status === 'PENDING' && (
                      <>
                        <button
                          className="action-btn accept"
                          onClick={() => handleAction(request.leaveId, 'accepted')}
                        >
                          Accept
                        </button>
                        <button
                          className="action-btn reject"
                          onClick={() => handleAction(request.leaveId, 'rejected')}
                        >
                          Reject
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
 
export default Leave_req_man;
