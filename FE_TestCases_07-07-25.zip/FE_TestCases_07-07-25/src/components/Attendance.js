import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Attendance.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignInAlt, faSignOutAlt, faClock, faHistory } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import DateTimeHeader from './DateTimeHeader';

// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088/api/v1/attendance',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});

// Add interceptor to automatically add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

const Attendance = () => {
  const navigate = useNavigate();
  const [isClockingIn, setIsClockingIn] = useState(false);
  const [isClockingOut, setIsClockingOut] = useState(false);
  const [clockInTime, setClockInTime] = useState(null);
  const [clockOutTime, setClockOutTime] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch today's attendance when component mounts
  useEffect(() => {
    const fetchTodayAttendance = async () => {
      try {
        const employeeId = localStorage.getItem('userId');
        const response = await api.get(`/employee/today/${employeeId}`);
        
        if (response.data) {
          setClockInTime(response.data.clockIn);
          setClockOutTime(response.data.clockOut);
        }
      } catch (error) {
        // If no attendance found for today, that's okay
        if (error.response?.status !== 404) {
          console.error('Error fetching today\'s attendance:', error);
        }
      } finally {
        setLoading(false);
      }
    };

    fetchTodayAttendance();
  }, []);

  const formatTime = (timestamp) => {
    if (!timestamp) return null;
    return new Date(timestamp).toLocaleTimeString();
  };

  const handleClockIn = async () => {
    setIsClockingIn(true);
    try {
      const employeeId = localStorage.getItem('userId');
      
      if (!localStorage.getItem('authToken')) {
        throw new Error('No authentication token found. Please login again.');
      }

      const response = await api.post(`/employee/clock-in/${employeeId}`);
      setClockInTime(response.data.clockIn);
      toast.success('Successfully clocked in!');
    } catch (error) {
      const message = error.response?.data?.message || error.message || 'Error clocking in';
      toast.error(message);
    } finally {
      setIsClockingIn(false);
    }
  };

  const handleClockOut = async () => {
    setIsClockingOut(true);
    try {
      const employeeId = localStorage.getItem('userId');
      
      if (!localStorage.getItem('authToken')) {
        throw new Error('No authentication token found. Please login again.');
      }

      const response = await api.post(`/employee/clock-out/${employeeId}`);
      setClockOutTime(response.data.clockOut);
      toast.success('Successfully clocked out!');
    } catch (error) {
      const message = error.response?.data?.message || error.message || 'Error clocking out';
      toast.error(message);
    } finally {
      setIsClockingOut(false);
    }
  };
  const userRole = localStorage.getItem('userRole');
  const basePath = userRole === 'manager' ? '/manager' : '/employee';
  return (
    <div className="attendance-container">
      <DateTimeHeader />
      <Toaster position="top-right" />
      <div className="attendance-header">
        <h2 className="attendance-title">Attendance Management</h2>
      </div>

      {loading ? (
        <div className="loading-spinner">Loading attendance status...</div>
      ) : (
        <>
          <div className="clock-section">
            <div className="clock-buttons-container">
              <button 
                className="clock-button clock-in"
                onClick={handleClockIn}
                disabled={isClockingIn || clockInTime}
              >
                <FontAwesomeIcon icon={faSignInAlt} />
                <span>{isClockingIn ? 'Clocking in...' : 'Clock In'}</span>
              </button>
              <button 
                className="clock-button clock-out"
                onClick={handleClockOut}
                disabled={isClockingOut || !clockInTime || clockOutTime}
              >
                <FontAwesomeIcon icon={faSignOutAlt} />
                <span>{isClockingOut ? 'Clocking out...' : 'Clock Out'}</span>
              </button>
            </div>
          </div>

          <div className="attendance-times">
            <div className="time-display">
              <FontAwesomeIcon icon={faClock} className="clock-icon" />
              <div className="time-info">
                <div className="time-row">
                  <span className="time-label">Clock In:</span>
                  <span className="time-value">
                    {clockInTime ? formatTime(clockInTime) : 'Yet to Clock In'}
                  </span>
                </div>
                <div className="time-row">
                  <span className="time-label">Clock Out:</span>
                  <span className="time-value">
                    {clockOutTime ? formatTime(clockOutTime) : 'Yet to Clock Out'}
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <button 
            className="history-button"
            onClick={() => navigate(`${basePath}/attendance-history`)}
          >
            <FontAwesomeIcon icon={faHistory} />
            <span>View History</span>
          </button>
        </>
      )}
    </div>
  );
};

export default Attendance;
