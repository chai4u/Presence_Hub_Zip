import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import './Leave.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';

// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8088',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true
});

// Add interceptor to automatically add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

// Add response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      if (error.response.status === 403 || error.response.status === 401) {
        toast.error('Access denied. Please login again.');
      }
    }
    return Promise.reject(error);
  }
);

const ApplyLeave = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    leaveTypeId: '',
    startDate: '',
    endDate: '',
    reason: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const calculateLeaveDays = (startDate, endDate) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end - start);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; // Include both start and end dates
  };

  const checkLeaveBalance = async (leaveTypeId, requiredDays) => {
    try {
      const employeeId = localStorage.getItem('userId');
      const response = await api.get(`/api/v1/leave/employee/balance/${employeeId}`);
      
      if (Array.isArray(response.data) && response.data.length > 0) {
        const leaveData = Array.isArray(response.data[0]) ? response.data[0] : response.data;
        const leaveBalance = leaveData.find(leave => leave.leaveType.id === parseInt(leaveTypeId));
        
        if (leaveBalance) {
          return {
            hasBalance: leaveBalance.balance >= requiredDays,
            balance: leaveBalance.balance,
            required: requiredDays
          };
        }
      }
      return { hasBalance: false, balance: 0, required: requiredDays };
    } catch (error) {
      console.error('Error checking leave balance:', error);
      throw new Error('Failed to check leave balance');
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const userId = localStorage.getItem('userId');
      const managerId = localStorage.getItem('managerId');
      const userRole = localStorage.getItem('userRole');
      const basePath = userRole === 'manager' ? '/manager' : '/employee';

      if (!userId) {
        toast.error('User ID not found. Please login again.');
        navigate('/login');
        return;
      }

      // For managers, ensure managerId is set to 1 (Admin's ID)
      const effectiveManagerId = userRole === 'manager' ? '1' : managerId;

      // Calculate number of leave days
      const requiredDays = calculateLeaveDays(formData.startDate, formData.endDate);

      // Check leave balance
      const balanceCheck = await checkLeaveBalance(formData.leaveTypeId, requiredDays);
      
      if (!balanceCheck.hasBalance) {
        toast.error(`Insufficient leave balance. You have ${balanceCheck.balance} days available but requested ${balanceCheck.required} days.`);
        setIsSubmitting(false);
        return;
      }

      const payload = {
        userId: parseInt(userId),
        managerId: parseInt(effectiveManagerId),
        leaveTypeId: parseInt(formData.leaveTypeId),
        startDate: formData.startDate,
        endDate: formData.endDate,
        reason: formData.reason
      };

      // Show leave request details in a toast
      // toast((t) => (
      //   <div>
      //     <p><strong>Submitting Leave Request:</strong></p>
      //     <p>Leave Type: {formData.leaveTypeId === '1' ? 'Sick Leave' : 'Vacation Leave'}</p>
      //     <p>From: {formData.startDate}</p>
      //     <p>To: {formData.endDate}</p>
      //     <p>Reason: {formData.reason}</p>
      //   </div>
      // ), {
      //   duration: 4000,
      //   style: {
      //     padding: '16px',
      //     borderRadius: '8px',
      //     background: '#f0f9ff',
      //     color: '#333'
      //   }
      // });

      const response = await api.post('/api/v1/leave/employee/leave-request', payload);
      
      toast.success('Leave application submitted successfully!');
      navigate(`${basePath}/leave`);
    } catch (error) {
      console.error('Leave request error:', error.response?.data || error.message);
      const message = error.response?.data?.message || error.message || 'Error submitting leave request';
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="apply-leave-container">
      <Toaster position="top-right" />
      <div className="leave-header">
        <button className="back-button" onClick={() => {
          const userRole = localStorage.getItem('userRole');
          const basePath = userRole === 'manager' ? '/manager' : '/employee';
          navigate(`${basePath}/leave`);
        }}>
          <FontAwesomeIcon icon={faArrowLeft} />
          <span>Back</span>
        </button>
        <h2 className="leave-title">Apply for Leave</h2>
      </div>
      <form className="leave-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="leaveTypeId">Leave Type</label>
          <select
            id="leaveTypeId"
            name="leaveTypeId"
            className="form-input"
            value={formData.leaveTypeId}
            onChange={handleChange}
            required
          >
            <option value="">Select Leave Type</option>
            <option value="1">Sick Leave</option>
            <option value="2">Vacation Leave</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="startDate">Start Date</label>
          <input
            type="date"
            id="startDate"
            name="startDate"
            className="form-input"
            value={formData.startDate}
            onChange={handleChange}
            required
            min={new Date().toISOString().split('T')[0]}
          />
        </div>
        <div className="form-group">
          <label htmlFor="endDate">End Date</label>
          <input
            type="date"
            id="endDate"
            name="endDate"
            className="form-input"
            value={formData.endDate}
            onChange={handleChange}
            required
            min={formData.startDate || new Date().toISOString().split('T')[0]}
          />
        </div>
        <div className="form-group">
          <label htmlFor="reason">Reason</label>
          <textarea
            id="reason"
            name="reason"
            className="form-input"
            value={formData.reason}
            onChange={handleChange}
            rows="4"
            required
          />
        </div>
        <div className="form-buttons">
          <button 
            type="button" 
            className="cancel-btn" 
            onClick={() => {
              const userRole = localStorage.getItem('userRole');
              const basePath = userRole === 'manager' ? '/manager' : '/employee';
              navigate(`${basePath}/leave`);
            }}
          >
            Cancel
          </button>
          <button type="submit" className="submit-btn" disabled={isSubmitting}>
            {isSubmitting ? 'Submitting...' : 'Submit Request'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ApplyLeave;