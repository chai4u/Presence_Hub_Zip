import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Samples from './components/samples'; 
import Login from './components/Auth/Login';
import Signup from './components/Auth/Signup';
import ApplyLeave from './components/ApplyLeave';
import LeaveStatus from './components/LeaveStatus';
import LeaveBalance from './components/LeaveBalance';
import ProtectedRoute from './components/Auth/ProtectedRoute';

import Manager_dashboard from './components/ManagerDashboard/Manager_dashboard';
import Attendance from './components/Attendance';
import Leave from './components/Leave';
import Shift from './components/Shift';
import Report from './components/Report';
import Shift_Assign from './components/Shift_Assign';
import Leave_req_man from './components/Leave_req_man';
import Reports_man from './components/Reports_man';
import ViewManagerReports from './components/ViewManagerReports';
import ViewEmployeeReport from './components/ViewEmployeeReport';
import Employee_dashboard from './components/EmployeeDashboard/Employee_dashboard';
import Admin_dashboard from './components/AdminDashboard/Admin_dashboard';
import ViewReport from './components/ViewReport';
import ViewManShifts from './components/ViewManShifts';
import ViewShifts from './components/ViewShifts';
import SwapRequest from './components/SwapRequest';
import ShiftRequests from './components/ShiftRequests';
import AttendanceHistory from './components/AttendanceHistory';

function App() {
  return (
    <Router>
      <Routes>
        {/* Home Page */}
        <Route path="/" element={<Samples />} />

        {/* Auth Pages */}
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* Employee Dashboard */}
        <Route element={<ProtectedRoute allowedRole="employee" />}>
        <Route path="/employee" element={<Employee_dashboard />}>
          <Route path="attendance" element={<Attendance />} />
          <Route path="attendance-history" element={<AttendanceHistory />} />
          <Route path="leave" element={<Leave />} />
          <Route path="shift" element={<Shift />} />
          <Route path="report" element={<Report />} />
          <Route path="viewshifts" element={<ViewShifts />} />
          <Route path="swaprequest" element={<SwapRequest />} />
          <Route path="shiftrequests" element={<ShiftRequests />} />
          <Route path="view-report" element={<ViewReport />} />
          <Route path="apply-leave" element={<ApplyLeave />} />
          <Route path="leave-status" element={<LeaveStatus />} />
          <Route path="leave-balance" element={<LeaveBalance />} />
        </Route>
        </Route>
        
        {/* Manager Dashboard */}
        <Route element={<ProtectedRoute allowedRole="manager" />}>
        <Route path="/manager" element={<Manager_dashboard />}>
          <Route path="attendance" element={<Attendance />} />
          <Route path="attendance-history" element={<AttendanceHistory />} />
          <Route path="leave" element={<Leave />} />
          <Route path="report" element={<Report />} />
          <Route path="shift_assign" element={<Shift_Assign />} />
          <Route path="viewmanshifts" element={<ViewManShifts />} />
          <Route path="Leave_req_man" element={<Leave_req_man/>} />
          <Route path="Reports_man" element={<Reports_man/>} />
          <Route path="view-manager-reports" element={<ViewManagerReports />} />
          <Route path="view-employee-report" element={<ViewEmployeeReport />} />
          <Route path="apply-leave" element={<ApplyLeave />} />
          <Route path="leave-status" element={<LeaveStatus />} />
          <Route path="leave-balance" element={<LeaveBalance />} />
          <Route path="view-report" element={<ViewReport />} />
        </Route>
        </Route>

        {/* Admin Dashboard */}
        <Route element={<ProtectedRoute allowedRole="admin" />}>
        <Route path="/admin" element={<Admin_dashboard />}>
          <Route path="Leave_req_man" element={<Leave_req_man/>} />
          <Route path="Reports_man" element={<Reports_man/>} />
          <Route path="view-manager-reports" element={<ViewManagerReports />} />
          <Route path="view-employee-report" element={<ViewEmployeeReport />} />
        </Route>
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
