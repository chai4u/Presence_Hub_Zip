package com.cts.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cts.entity.ShiftAssignment;
import com.cts.entity.ShiftType;

public interface ShiftAssignmentRepository extends JpaRepository<ShiftAssignment, Long> {

    Optional<ShiftAssignment> findByUserIdAndShiftTypeAndAssignDate(Long userId, ShiftType shiftType, LocalDate assignDate);

    Optional<ShiftAssignment> findByUserIdAndAssignDate(Long userId, LocalDate assignDate);

    List<ShiftAssignment> findByUserId(Long userId);
    
    List<ShiftAssignment> findByUserIdIn(List<Long> userIds);//new method
}
 