package com.cts.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data

public class SwapRequestDTO {

    @NotNull(message = "Requester Employee ID cannot be null")
    private Long requesterEmployeeId;

    @NotNull(message = "Target Employee ID cannot be null")
    private Long targetEmployeeId;

    @NotNull(message = "Requester Shift ID cannot be null")
    private Long requesterShiftId;

    @NotNull(message = "Target Shift ID cannot be null")
    private Long targetShiftId;

    private Long managerId;

    @NotNull(message = "Swap Date cannot be null")
    @FutureOrPresent(message = "Swap Date must be today or in the future")
    private LocalDate swapDate;

    @NotNull(message = "Reason cannot be null")
    @Size(min = 5, max = 255, message = "Reason must be between 5 and 255 characters")
    private String reason;
}