package com.cts.seeddata;
 
import java.time.LocalTime;
import java.util.List;
 
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.cts.entity.ShiftType;

import com.cts.repository.ShiftTypeRepository;
 
@Configuration
public class SeedData {
 
    @Bean
    CommandLineRunner loadData( ShiftTypeRepository typeRepo) {
        return args -> {
            if (typeRepo.count() == 0) {
 
               
                List<ShiftType> shifts = List.of(
                        new ShiftType(null, "Morning", LocalTime.of(6, 0), LocalTime.of(14, 0)),
                        new ShiftType(null, "Afternoon", LocalTime.of(14, 0), LocalTime.of(22, 0)),
                        new ShiftType(null, "Night", LocalTime.of(22, 0), LocalTime.of(6, 0))
                );
                typeRepo.saveAll(shifts);
                System.out.println("Seeding initial ShiftType data.");
            }
        };
    }
}