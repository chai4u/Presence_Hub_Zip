package com.cts.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "leave-management")
public interface LeaveManagementClient {

    @GetMapping("/api/v1/leave/leave/status/{userId}/{date}")
    Boolean isLeaveApproved(
        @PathVariable("userId") Long userId,
        @PathVariable("date") String date 
    );
}
