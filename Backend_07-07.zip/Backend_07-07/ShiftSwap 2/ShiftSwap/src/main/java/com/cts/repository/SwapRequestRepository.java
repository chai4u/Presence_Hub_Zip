package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.entity.ShiftType;
import com.cts.entity.SwapRequest;
import com.cts.enums.SwapStatus;

public interface SwapRequestRepository extends JpaRepository<SwapRequest, Long> {
	
	boolean existsByRequesterShiftAndTargetShiftAndStatus(
	        ShiftType requesterShift,
	        ShiftType targetShift,
	        SwapStatus status);
    List<SwapRequest> findByManagerId(Long managerId);
    
    List<SwapRequest> findByRequesterEmployeeId(Long requesterId);

    List<SwapRequest> findByTargetEmployeeId(Long targetId);
}
