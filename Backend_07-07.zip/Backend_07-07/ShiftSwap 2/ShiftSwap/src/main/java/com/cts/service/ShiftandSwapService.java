package com.cts.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cts.client.LeaveManagementClient;
import com.cts.client.UserAuthClient;
import com.cts.dto.ShiftAssignmentRequestDTO;
import com.cts.dto.SwapRequestDTO;
import com.cts.dto.UserDataDto;
import com.cts.entity.ShiftAssignment;
import com.cts.entity.ShiftType;
import com.cts.entity.SwapRequest;
import com.cts.enums.SwapStatus;
import com.cts.exception.InvalidSwapRequestException;
import com.cts.exception.ResourceNotFoundException;
import com.cts.exception.ShiftConflictException;
import com.cts.repository.ShiftAssignmentRepository;
import com.cts.repository.ShiftTypeRepository;
import com.cts.repository.SwapRequestRepository;

import jakarta.transaction.Transactional; // Using Jakarta EE Transactional
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class ShiftandSwapService {

    private final ShiftTypeRepository shiftTypeRepo;
    private final SwapRequestRepository swapRequestRepo;
    private final ShiftAssignmentRepository shiftAssignmentRepo;
    private final LeaveManagementClient leaveManagementClient;
    private final UserAuthClient userAuthClient;

    public String assignShiftToEmployee(ShiftAssignmentRequestDTO dto) {
        UserDataDto employee = userAuthClient.getUserById(dto.getEmployeeId());
        if (employee == null) { // Added check for employee not found
            throw new ResourceNotFoundException("Employee not found with ID: " + dto.getEmployeeId());
        }

        ShiftType shiftType = shiftTypeRepo.findByShiftName(dto.getShiftName())
                .orElseThrow(() -> new ResourceNotFoundException("Shift Type not found with name: " + dto.getShiftName()));

        Optional<ShiftAssignment> existingAssignment = shiftAssignmentRepo.findByUserIdAndAssignDate(dto.getEmployeeId(), dto.getAssignDate());
        if (existingAssignment.isPresent()) {
            throw new ShiftConflictException("Employee already has a shift assigned for " + dto.getAssignDate());
        }

        LocalDate previousDate = dto.getAssignDate().minusDays(1);

        ShiftType nightShiftType = shiftTypeRepo.findByShiftName("Night")
            .orElseThrow(() -> new ResourceNotFoundException("Essential Shift Type 'Night' not found in repository. Please check seed data."));
        Optional<ShiftAssignment> previousNightShift = shiftAssignmentRepo.findByUserIdAndShiftTypeAndAssignDate(
                dto.getEmployeeId(), nightShiftType, previousDate);

        if (previousNightShift.isPresent() && shiftType.getShiftName().equalsIgnoreCase("Morning")) {
            throw new ShiftConflictException("Cannot assign morning shift on " + dto.getAssignDate() +
                    " due to previous night shift on " + previousDate);
        }

        LocalDate nextDate = dto.getAssignDate().plusDays(1);

        ShiftType morningShiftType = shiftTypeRepo.findByShiftName("Morning")
            .orElseThrow(() -> new ResourceNotFoundException("Essential Shift Type 'Morning' not found in repository. Please check seed data."));
        Optional<ShiftAssignment> nextMorningShift = shiftAssignmentRepo.findByUserIdAndShiftTypeAndAssignDate(
                dto.getEmployeeId(), morningShiftType, nextDate); 

        if (shiftType.getShiftName().equalsIgnoreCase("Night") && nextMorningShift.isPresent()) {
            throw new ShiftConflictException("Cannot assign night shift on " + dto.getAssignDate() +
                    " as the employee has a morning shift on " + nextDate);
        }

        String assignDateStr = dto.getAssignDate().toString(); // Format:YYYY-MM-dd
        if (Boolean.TRUE.equals(leaveManagementClient.isLeaveApproved(dto.getEmployeeId(), assignDateStr))) {
            throw new ShiftConflictException("Cannot assign shift on " + dto.getAssignDate() +
                    " as the employee has approved leave.");
        }

        ShiftAssignment newAssignment = new ShiftAssignment();
        newAssignment.setUserId(dto.getEmployeeId());
        newAssignment.setShiftType(shiftType); 
        newAssignment.setAssignDate(dto.getAssignDate());

        shiftAssignmentRepo.save(newAssignment);
        return "Shift assigned successfully to " + employee.getName() + " for " + dto.getAssignDate() + ".";
    }

    public String requestSwap(SwapRequestDTO dto) {
        UserDataDto requesterData = userAuthClient.getUserById(dto.getRequesterEmployeeId());
        if (requesterData == null) {
            throw new ResourceNotFoundException("Requester Employee not found with ID: " + dto.getRequesterEmployeeId());
        }
      
        UserDataDto targetData = userAuthClient.getUserById(dto.getTargetEmployeeId());
        if (targetData == null) {
            throw new ResourceNotFoundException("Target Employee not found with ID: " + dto.getTargetEmployeeId());
        }
      
        UserDataDto managerData = userAuthClient.getUserById(dto.getManagerId());
        if (managerData == null) {
            throw new ResourceNotFoundException("Manager not found with ID: " + dto.getManagerId());
        }
      
        if (!requesterData.getManager().equals(managerData.getName()) || !targetData.getManager().equals(managerData.getName())) {
            throw new InvalidSwapRequestException("Both employees must be under the same manager: " + managerData.getName());
        }
      
        Optional<ShiftType> requesterShiftOpt = shiftTypeRepo.findById(dto.getRequesterShiftId());
        if (requesterShiftOpt.isEmpty()) {
            throw new ShiftConflictException("Requester Shift not found with ID: " + dto.getRequesterShiftId());
        }
        ShiftType requesterShift = requesterShiftOpt.get();
      
        Optional<ShiftType> targetShiftOpt = shiftTypeRepo.findById(dto.getTargetShiftId());
        if (targetShiftOpt.isEmpty()) {
            throw new ShiftConflictException("Target Shift not found with ID: " + dto.getTargetShiftId());
        }
        ShiftType targetShift = targetShiftOpt.get();
      
        if (dto.getRequesterShiftId().equals(dto.getTargetShiftId())) {
            throw new ShiftConflictException("Swap request invalid: Requester and Target shifts are the same.");
        }
      
        // Validate shift assignments for requester and target employees
        Optional<ShiftAssignment> requesterAssignmentOpt = shiftAssignmentRepo.findByUserIdAndShiftTypeAndAssignDate(
                dto.getRequesterEmployeeId(), requesterShift, dto.getSwapDate());
        if (requesterAssignmentOpt.isEmpty()) {
            throw new ShiftConflictException("Requester does not have a shift assigned for the given date.");
        }
      
        Optional<ShiftAssignment> targetAssignmentOpt = shiftAssignmentRepo.findByUserIdAndShiftTypeAndAssignDate(
                dto.getTargetEmployeeId(), targetShift, dto.getSwapDate());
        if (targetAssignmentOpt.isEmpty()) {
            throw new ShiftConflictException("Target does not have a shift assigned for the given date.");
        }
      
        // Create and save the swap request
        SwapRequest request = new SwapRequest();
        request.setRequesterEmployeeId(dto.getRequesterEmployeeId());
        request.setTargetEmployeeId(dto.getTargetEmployeeId());
        request.setRequesterShift(requesterShift);
        request.setTargetShift(targetShift);
        request.setSwapDate(dto.getSwapDate());
        request.setReason(dto.getReason());
        request.setStatus(SwapStatus.PENDING);
        request.setManagerId(managerData.getId().longValue());
      
        SwapRequest savedRequest = swapRequestRepo.save(request);
        return "Swap request submitted successfully with ID: " + savedRequest.getId();
    }

    @Transactional // Add @Transactional for atomic operations
    public String approveSwap(Long requestId) {
        SwapRequest req = swapRequestRepo.findById(requestId)
                .orElseThrow(() -> new RuntimeException("Swap Request not found with ID: " + requestId));
    
        String swapDateStr = req.getSwapDate().toString(); // Format:YYYY-MM-dd
    
        if (Boolean.TRUE.equals(leaveManagementClient.isLeaveApproved(req.getRequesterEmployeeId(), swapDateStr))) {
            throw new ShiftConflictException("Requester employee has approved leave on " + req.getSwapDate());
        }
    
        if (Boolean.TRUE.equals(leaveManagementClient.isLeaveApproved(req.getTargetEmployeeId(), swapDateStr))) {
            throw new ShiftConflictException("Target employee has approved leave on " + req.getSwapDate());
        }
    
        // --- Start of new logic to update shifts ---
    
        // 1. Find the current shift assignments for both employees
        ShiftAssignment requesterAssignment = shiftAssignmentRepo
                .findByUserIdAndAssignDate(req.getRequesterEmployeeId(), req.getSwapDate())
                .orElseThrow(() -> new ResourceNotFoundException("Requester's shift assignment not found for the swap date."));
    
        ShiftAssignment targetAssignment = shiftAssignmentRepo
                .findByUserIdAndAssignDate(req.getTargetEmployeeId(), req.getSwapDate())
                .orElseThrow(() -> new ResourceNotFoundException("Target's shift assignment not found for the swap date."));
        
        // 2. Swap the shift types
        requesterAssignment.setShiftType(req.getTargetShift());
        targetAssignment.setShiftType(req.getRequesterShift());
    
        // 3. Save the updated assignments
        shiftAssignmentRepo.save(requesterAssignment);
        shiftAssignmentRepo.save(targetAssignment);
    
        log.info("Successfully swapped shifts for user {} and {} on {}.",
                req.getRequesterEmployeeId(), req.getTargetEmployeeId(), req.getSwapDate());
    
        // --- End of new logic ---
    
        // Update the swap request status
        req.setStatus(SwapStatus.APPROVED);
        swapRequestRepo.save(req);
    
        return "Swap approved and shifts updated successfully.";
    }

    @Transactional
    public String rejectSwap(Long requestId) {
        SwapRequest req = swapRequestRepo.findById(requestId)
                .orElseThrow(() -> new RuntimeException("Swap Request not found with ID: " + requestId));

        req.setStatus(SwapStatus.REJECTED);
        swapRequestRepo.save(req);
        return "Swap rejected.";
    }

    public List<SwapRequest> listSwapsByManagerId(Long managerId) {
        return swapRequestRepo.findByManagerId(managerId);
    }
    
    public List<ShiftAssignment> getShiftAssignmentsByManagerId(Long managerId) {
        List<UserDataDto> employees = userAuthClient.getUsersByManagerId(managerId);
        if (employees.isEmpty()) {
            throw new ResourceNotFoundException("No employees found under manager ID: " + managerId);
        }

        List<Long> employeeIds = employees.stream()
                .map(UserDataDto::getId)
                .map(Long::valueOf) // Convert Integer to Long if necessary
                .toList();
        return shiftAssignmentRepo.findByUserIdIn(employeeIds);
    }    
    
    public List<ShiftAssignment> getShiftAssignmentsByUserId(Long userId) {
        return shiftAssignmentRepo.findByUserId(userId);
    }
    
    public List<SwapRequest> getSwapRequestsByRequester(Long requesterId) {
        List<SwapRequest> requests = swapRequestRepo.findByRequesterEmployeeId(requesterId);
        if (requests.isEmpty()) {
            throw new ResourceNotFoundException("No swap requests found for requester ID: " + requesterId);
        }
        return requests;
    }

    public List<SwapRequest> getSwapRequestsByTarget(Long targetId) {
        List<SwapRequest> requests = swapRequestRepo.findByTargetEmployeeId(targetId);
        if (requests.isEmpty()) {
            throw new ResourceNotFoundException("No swap requests found for target ID: " + targetId);
        }
        return requests;
    }


    @Transactional
    public String editShiftAssignment(Long assignmentId, ShiftAssignmentRequestDTO dto) { // managerId removed
        // 1. Find the existing shift assignment
        ShiftAssignment existingAssignment = shiftAssignmentRepo.findById(assignmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Shift assignment not found with ID: " + assignmentId));

        // 2. Find the new shift type
        ShiftType newShiftType = shiftTypeRepo.findByShiftName(dto.getShiftName())
                .orElseThrow(() -> new ResourceNotFoundException("New Shift Type not found with name: " + dto.getShiftName()));

        Long employeeId = existingAssignment.getUserId();
        LocalDate assignDate = existingAssignment.getAssignDate();

        // 3. Perform conflict checks with the new shift type
        // Check for previous night shift conflict
        LocalDate previousDate = assignDate.minusDays(1);
        ShiftType nightShiftType = shiftTypeRepo.findByShiftName("Night")
            .orElseThrow(() -> new ResourceNotFoundException("Essential Shift Type 'Night' not found in repository. Please check seed data."));
        Optional<ShiftAssignment> previousNightShift = shiftAssignmentRepo.findByUserIdAndShiftTypeAndAssignDate(
                employeeId, nightShiftType, previousDate);

        if (previousNightShift.isPresent() && newShiftType.getShiftName().equalsIgnoreCase("Morning")) {
            throw new ShiftConflictException("Cannot change to morning shift on " + assignDate +
                    " due to previous night shift on " + previousDate);
        }

        // Check for next morning shift conflict
        LocalDate nextDate = assignDate.plusDays(1);
        ShiftType morningShiftType = shiftTypeRepo.findByShiftName("Morning")
            .orElseThrow(() -> new ResourceNotFoundException("Essential Shift Type 'Morning' not found in repository. Please check seed data."));
        Optional<ShiftAssignment> nextMorningShift = shiftAssignmentRepo.findByUserIdAndShiftTypeAndAssignDate(
                employeeId, morningShiftType, nextDate); 

        if (newShiftType.getShiftName().equalsIgnoreCase("Night") && nextMorningShift.isPresent()) {
            throw new ShiftConflictException("Cannot change to night shift on " + assignDate +
                    " as the employee has a morning shift on " + nextDate);
        }

        // Check for approved leave conflict
        String assignDateStr = assignDate.toString();
        if (Boolean.TRUE.equals(leaveManagementClient.isLeaveApproved(employeeId, assignDateStr))) {
            throw new ShiftConflictException("Cannot edit shift on " + assignDate +
                    " as the employee has approved leave.");
        }

        // 4. Update the shift type and save
        existingAssignment.setShiftType(newShiftType);
        shiftAssignmentRepo.save(existingAssignment);

        log.info("Shift assignment with ID {} updated successfully to shift type {}.",
                 assignmentId, newShiftType.getShiftName()); // managerId removed from log
        return "Shift assignment updated successfully for employee ID " + employeeId + " on " + assignDate + ".";
    }


    @Transactional
    public String deleteShiftAssignment(Long assignmentId) { 
        shiftAssignmentRepo.findById(assignmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Shift assignment not found with ID: " + assignmentId));

        shiftAssignmentRepo.deleteById(assignmentId);

        log.info("Shift assignment with ID {} deleted successfully.", assignmentId);
        return "Shift assignment with ID " + assignmentId + " deleted successfully.";
    }
    
}