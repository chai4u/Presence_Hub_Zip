package com.cts.enums;

public enum SwapStatus {
    PENDING,
    APPROVED,
    REJECTED
}
