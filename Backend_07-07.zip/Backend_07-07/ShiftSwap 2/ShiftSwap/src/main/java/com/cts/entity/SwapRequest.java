package com.cts.entity;

import java.time.LocalDate;

import com.cts.enums.SwapStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = "id", callSuper = false)
public class SwapRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "swap_request_id")
    private Long id;

    @Column(name = "requester_employee_id", nullable = false)
    private Long requesterEmployeeId;

    @Column(name = "target_employee_id", nullable = false)
    private Long targetEmployeeId;

    @ManyToOne
    @JoinColumn(name = "requester_shift_id", nullable = false)
    private ShiftType requesterShift;

    @ManyToOne
    @JoinColumn(name = "target_shift_id", nullable = false)
    private ShiftType targetShift;

    @Column(name = "manager_id")
    private Long managerId;

    private LocalDate swapDate;

    private String reason;

    @Enumerated(EnumType.STRING)
    private SwapStatus status = SwapStatus.PENDING;
}
