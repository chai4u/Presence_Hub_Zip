package com.cts.exception;

public class InvalidSwapRequestException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
    public InvalidSwapRequestException(String message) {
        super(message);
    }
}
