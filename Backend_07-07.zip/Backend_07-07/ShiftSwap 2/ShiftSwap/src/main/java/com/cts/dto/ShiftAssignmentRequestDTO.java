package com.cts.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data

public class ShiftAssignmentRequestDTO {

    @NotNull(message = "Employee ID cannot be null")
    private Long employeeId;

    @NotNull(message = "Shift Type Name cannot be null")
    private String shiftName;

    @NotNull(message = "Assign Date cannot be null")
    @FutureOrPresent(message = "Assign Date must be today or in the future")
    private LocalDate assignDate;
}