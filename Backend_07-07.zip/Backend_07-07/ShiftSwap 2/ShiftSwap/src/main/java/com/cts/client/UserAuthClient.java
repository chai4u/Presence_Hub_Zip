package com.cts.client;
 
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
 
import com.cts.dto.UserDataDto;
 
@FeignClient(name = "EmpALMS-1")
public interface UserAuthClient {
 
    @GetMapping("/api/v1/auth/user/{id}")
    UserDataDto getUserById(@PathVariable("id") Long id);
    
    @GetMapping("/api/v1/auth/user/manager/{managerId}")
    List<UserDataDto> getUsersByManagerId(@PathVariable("managerId") Long managerId);
}
