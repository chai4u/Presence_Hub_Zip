package com.cts.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping; // Import for @DeleteMapping
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.ShiftAssignmentRequestDTO;
import com.cts.dto.SwapRequestDTO;
import com.cts.entity.ShiftAssignment;
import com.cts.entity.SwapRequest;
import com.cts.service.ShiftandSwapService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/shift")
@RequiredArgsConstructor
@Slf4j
//@CrossOrigin(origins = "http://localhost:3000") // Uncomment if needed for CORS
public class ShiftUnifiedController {

    private final ShiftandSwapService shiftandSwapService;

    @PostMapping("manager/shift/assign")
    public ResponseEntity<String> assignShift(@Valid @RequestBody ShiftAssignmentRequestDTO dto) {
        log.info("Received request to assign shift: {}", dto);
        String response = shiftandSwapService.assignShiftToEmployee(dto);
        log.info("Shift assignment successful: {}", response);
        return ResponseEntity.ok(response);
    }

    @PostMapping("employee/swap/request")
    public ResponseEntity<String> request(@Valid @RequestBody SwapRequestDTO dto) {
        log.info("Received request to swap shift: {}", dto);
        String response = shiftandSwapService.requestSwap(dto);
        log.info("Swap request successful: {}", response);
        return ResponseEntity.ok(response);
    }

    @PutMapping("employee/swap/approve/{id}")
    public ResponseEntity<String> approve(@PathVariable Long id) {
        log.info("Received request to approve swap with ID: {}", id);
        String response = shiftandSwapService.approveSwap(id);
        log.info("Swap approval successful: {}", response);
        return ResponseEntity.ok(response);
    }

    @PutMapping("employee/swap/reject/{id}")
    public ResponseEntity<String> reject(@PathVariable Long id) {
        log.info("Received request to reject swap with ID: {}", id);
        String response = shiftandSwapService.rejectSwap(id);
        log.info("Swap rejection successful: {}", response);
        return ResponseEntity.ok(response);
    }

    @GetMapping("manager/swap/list/{managerId}") 
    public ResponseEntity<List<SwapRequest>> list(@PathVariable Long managerId) {
        log.info("Received request to list swap requests for manager ID: {}", managerId);
        List<SwapRequest> swaps = shiftandSwapService.listSwapsByManagerId(managerId); 
        log.debug("Swap requests retrieved for manager ID {}: {}", managerId, swaps);
        return ResponseEntity.ok(swaps);
    }
    
    @GetMapping("manager/assignments/{managerId}")
    public ResponseEntity<List<ShiftAssignment>> getManagerEmployeeAssignments(@PathVariable Long managerId) {
        log.info("Received request to get shift assignments for employees under manager ID: {}", managerId);
        List<ShiftAssignment> assignments = shiftandSwapService.getShiftAssignmentsByManagerId(managerId);
        log.debug("Shift assignments retrieved for manager ID {}: {}", managerId, assignments);
        return ResponseEntity.ok(assignments);
    }

    @GetMapping("employee/assignments/{userId}")
    public ResponseEntity<List<ShiftAssignment>> getAssignments(@PathVariable Long userId) {
        log.info("Received request to get assignments for user ID: {}", userId);
        List<ShiftAssignment> assignments = shiftandSwapService.getShiftAssignmentsByUserId(userId);
        log.debug("Assignments retrieved for user ID {}: {}", userId, assignments);
        return ResponseEntity.ok(assignments);
    }
    
    @GetMapping("employee/swap/requests/requester/{requesterId}")
    public ResponseEntity<List<SwapRequest>> getRequestsByRequester(@PathVariable Long requesterId) {
        log.info("Received request to list swap requests for requester ID: {}", requesterId);
        List<SwapRequest> requests = shiftandSwapService.getSwapRequestsByRequester(requesterId);
        log.debug("Swap requests retrieved for requester ID {}: {}", requesterId, requests);
        return ResponseEntity.ok(requests);
    }

    @GetMapping("employee/swap/requests/target/{targetId}")
    public ResponseEntity<List<SwapRequest>> getRequestsByTarget(@PathVariable Long targetId) {
        log.info("Received request to list swap requests for target ID: {}", targetId);
        List<SwapRequest> requests = shiftandSwapService.getSwapRequestsByTarget(targetId);
        log.debug("Swap requests retrieved for target ID {}: {}", targetId, requests);
        return ResponseEntity.ok(requests);
    }

    @PutMapping("manager/assignment/edit/{assignmentId}")
    public ResponseEntity<String> editShiftAssignment(@PathVariable Long assignmentId, @Valid @RequestBody ShiftAssignmentRequestDTO dto) {
        log.info("Received request to edit shift assignment ID {}: {}", assignmentId, dto);
        String response = shiftandSwapService.editShiftAssignment(assignmentId, dto); 
        log.info("Shift assignment edit successful: {}", response);
        return ResponseEntity.ok(response);
    }


    @DeleteMapping("manager/assignment/delete/{assignmentId}") 
    public ResponseEntity<String> deleteShiftAssignment(@PathVariable Long assignmentId) {
        log.info("Received request to delete shift assignment ID {}.", assignmentId);
        String response = shiftandSwapService.deleteShiftAssignment(assignmentId); 
        log.info("Shift assignment delete successful: {}", response);
        return ResponseEntity.ok(response);
    }
}