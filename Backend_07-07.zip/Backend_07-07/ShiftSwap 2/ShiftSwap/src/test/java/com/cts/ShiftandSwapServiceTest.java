package com.cts;

import com.cts.client.LeaveManagementClient;
import com.cts.client.UserAuthClient;
import com.cts.dto.ShiftAssignmentRequestDTO;
import com.cts.dto.SwapRequestDTO;
import com.cts.dto.UserDataDto;
import com.cts.entity.ShiftAssignment;
import com.cts.entity.ShiftType;
import com.cts.entity.SwapRequest;
import com.cts.enums.SwapStatus;
import com.cts.exception.ResourceNotFoundException;
import com.cts.exception.ShiftConflictException;
import com.cts.repository.ShiftAssignmentRepository;
import com.cts.repository.ShiftTypeRepository;
import com.cts.repository.SwapRequestRepository;
import com.cts.service.ShiftandSwapService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ShiftandSwapServiceTest {

    @Mock private ShiftTypeRepository shiftTypeRepo;
    @Mock private SwapRequestRepository swapRequestRepo;
    @Mock private ShiftAssignmentRepository shiftAssignmentRepo;
    @Mock private LeaveManagementClient leaveManagementClient;
    @Mock private UserAuthClient userAuthClient;

    @InjectMocks
    private ShiftandSwapService shiftandSwapService;

    private ShiftAssignmentRequestDTO shiftDto;
    private SwapRequestDTO swapDto;
    private UserDataDto requester;
    private UserDataDto target;
    private UserDataDto manager;
    private ShiftType morningShift;
    private ShiftType eveningShift;

    @BeforeEach
    void setUp() {
        requester = new UserDataDto(1, "Requester", "requester@example.com", "Manager");
        target = new UserDataDto(2, "Target", "target@example.com", "Manager");
        manager = new UserDataDto(3, "Manager", "manager@example.com", null);

        morningShift = new ShiftType(100L, "Morning", null, null);
        eveningShift = new ShiftType(200L, "Evening", null, null);

        shiftDto = new ShiftAssignmentRequestDTO();
        shiftDto.setEmployeeId(1L);
        shiftDto.setAssignDate(LocalDate.now());
        shiftDto.setShiftName("Morning");

        swapDto = new SwapRequestDTO();
        swapDto.setRequesterEmployeeId(1L);
        swapDto.setTargetEmployeeId(2L);
        swapDto.setRequesterShiftId(100L);
        swapDto.setTargetShiftId(200L);
        swapDto.setSwapDate(LocalDate.now());
        swapDto.setReason("Personal");
        swapDto.setManagerId(3L);
    }

    @Test
    void assignShiftSuccessfully() {
        when(userAuthClient.getUserById(1L)).thenReturn(requester);
        when(shiftTypeRepo.findByShiftName("Morning")).thenReturn(Optional.of(morningShift));
        when(shiftAssignmentRepo.findByUserIdAndAssignDate(1L, LocalDate.now())).thenReturn(Optional.empty());
        when(leaveManagementClient.isLeaveApproved(1L, LocalDate.now().toString())).thenReturn(false);

        String response = shiftandSwapService.assignShiftToEmployee(shiftDto);

        assertTrue(response.contains("Shift assigned successfully"));
        verify(shiftAssignmentRepo).save(any(ShiftAssignment.class));
    }

    @Test
    void assignShiftThrowsWhenEmployeeNotFound() {
        when(userAuthClient.getUserById(1L)).thenReturn(null);
        assertThrows(ResourceNotFoundException.class, () ->
                shiftandSwapService.assignShiftToEmployee(shiftDto));
    }

    @Test
    void assignShiftThrowsWhenShiftTypeNotFound() {
        when(userAuthClient.getUserById(1L)).thenReturn(requester);
        when(shiftTypeRepo.findByShiftName("Morning")).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () ->
                shiftandSwapService.assignShiftToEmployee(shiftDto));
    }

    @Test
    void requestSwapSuccessfully() {
        when(userAuthClient.getUserById(1L)).thenReturn(requester);
        when(userAuthClient.getUserById(2L)).thenReturn(target);
        when(userAuthClient.getUserById(3L)).thenReturn(manager);
        when(shiftTypeRepo.findById(100L)).thenReturn(Optional.of(morningShift));
        when(shiftTypeRepo.findById(200L)).thenReturn(Optional.of(eveningShift));
        when(shiftAssignmentRepo.findByUserIdAndShiftTypeAndAssignDate(1L, morningShift, LocalDate.now()))
                .thenReturn(Optional.of(new ShiftAssignment()));
        when(shiftAssignmentRepo.findByUserIdAndShiftTypeAndAssignDate(2L, eveningShift, LocalDate.now()))
                .thenReturn(Optional.of(new ShiftAssignment()));

        String response = shiftandSwapService.requestSwap(swapDto);

        assertTrue(response.contains("Swap request submitted successfully"));
        verify(swapRequestRepo).save(any(SwapRequest.class));
    }

    @Test
    void requestSwapThrowsWhenRequesterNotFound() {
        when(userAuthClient.getUserById(1L)).thenReturn(null);
        assertThrows(ResourceNotFoundException.class, () ->
                shiftandSwapService.requestSwap(swapDto));
    }

    @Test
    void requestSwapThrowsWhenTargetNotFound() {
        when(userAuthClient.getUserById(1L)).thenReturn(requester);
        when(userAuthClient.getUserById(2L)).thenReturn(null);
        assertThrows(ResourceNotFoundException.class, () ->
                shiftandSwapService.requestSwap(swapDto));
    }

    @Test
    void approveSwapSuccessfully() {
        SwapRequest request = new SwapRequest();
        request.setRequesterEmployeeId(1L);
        request.setTargetEmployeeId(2L);
        request.setSwapDate(LocalDate.now());

        when(swapRequestRepo.findById(1L)).thenReturn(Optional.of(request));
        when(leaveManagementClient.isLeaveApproved(1L, LocalDate.now().toString())).thenReturn(false);
        when(leaveManagementClient.isLeaveApproved(2L, LocalDate.now().toString())).thenReturn(false);

        String response = shiftandSwapService.approveSwap(1L);

        assertTrue(response.contains("Swap approved"));
        verify(swapRequestRepo).save(request);
    }

    @Test
    void rejectSwapSuccessfully() {
        SwapRequest request = new SwapRequest();
        when(swapRequestRepo.findById(1L)).thenReturn(Optional.of(request));

        String response = shiftandSwapService.rejectSwap(1L);

        assertTrue(response.contains("Swap rejected"));
        verify(swapRequestRepo).save(request);
    }
}