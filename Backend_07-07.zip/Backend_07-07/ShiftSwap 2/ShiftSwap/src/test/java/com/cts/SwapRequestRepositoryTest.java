package com.cts;

import com.cts.entity.ShiftType;
import com.cts.entity.SwapRequest;
import com.cts.enums.SwapStatus;
import com.cts.repository.SwapRequestRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SwapRequestRepositoryTest {

    @Mock
    private SwapRequestRepository swapRequestRepository;

    private ShiftType requesterShift;
    private ShiftType targetShift;
    private SwapRequest swapRequest;

    @BeforeEach
    void setUp() {
        requesterShift = new ShiftType();
        requesterShift.setShiftId(1L);
        requesterShift.setShiftName("Morning");

        targetShift = new ShiftType();
        targetShift.setShiftId(2L);
        targetShift.setShiftName("Evening");

        swapRequest = new SwapRequest();
        swapRequest.setId(1L);
        swapRequest.setRequesterEmployeeId(101L);
        swapRequest.setTargetEmployeeId(102L);
        swapRequest.setRequesterShift(requesterShift);
        swapRequest.setTargetShift(targetShift);
        swapRequest.setStatus(SwapStatus.PENDING);
        swapRequest.setManagerId(201L);
    }

    @Test
    void testExistsByRequesterShiftAndTargetShiftAndStatus() {
        when(swapRequestRepository.existsByRequesterShiftAndTargetShiftAndStatus(
                requesterShift, targetShift, SwapStatus.PENDING)).thenReturn(true);

        boolean exists = swapRequestRepository.existsByRequesterShiftAndTargetShiftAndStatus(
                requesterShift, targetShift, SwapStatus.PENDING);

        assertTrue(exists);
        verify(swapRequestRepository).existsByRequesterShiftAndTargetShiftAndStatus(
                requesterShift, targetShift, SwapStatus.PENDING);
    }

    @Test
    void testFindByManagerId() {
        when(swapRequestRepository.findByManagerId(201L))
                .thenReturn(Arrays.asList(swapRequest));

        List<SwapRequest> result = swapRequestRepository.findByManagerId(201L);

        assertEquals(1, result.size());
        assertEquals(201L, result.get(0).getManagerId());
        verify(swapRequestRepository).findByManagerId(201L);
    }

    @Test
    void testFindByRequesterEmployeeId() {
        when(swapRequestRepository.findByRequesterEmployeeId(101L))
                .thenReturn(Arrays.asList(swapRequest));

        List<SwapRequest> result = swapRequestRepository.findByRequesterEmployeeId(101L);

        assertEquals(1, result.size());
        assertEquals(101L, result.get(0).getRequesterEmployeeId());
        verify(swapRequestRepository).findByRequesterEmployeeId(101L);
    }

    @Test
    void testFindByTargetEmployeeId() {
        when(swapRequestRepository.findByTargetEmployeeId(102L))
                .thenReturn(Arrays.asList(swapRequest));

        List<SwapRequest> result = swapRequestRepository.findByTargetEmployeeId(102L);

        assertEquals(1, result.size());
        assertEquals(102L, result.get(0).getTargetEmployeeId());
        verify(swapRequestRepository).findByTargetEmployeeId(102L);
    }
}