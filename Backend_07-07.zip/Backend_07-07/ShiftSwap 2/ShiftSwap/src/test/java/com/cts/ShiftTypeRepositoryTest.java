package com.cts;

import com.cts.entity.ShiftType;
import com.cts.repository.ShiftTypeRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ShiftTypeRepositoryTest {

    @Mock
    private ShiftTypeRepository shiftTypeRepository;

    private ShiftType shiftType;

    @BeforeEach
    void setUp() {
        shiftType = new ShiftType();
        shiftType.setShiftId(1L);
        shiftType.setShiftName("Morning");
        shiftType.setStartTime(java.time.LocalTime.of(6, 0));
        shiftType.setEndTime(java.time.LocalTime.of(14, 0));
    }

    @Test
    void testFindByShiftName() {
        when(shiftTypeRepository.findByShiftName("Morning")).thenReturn(Optional.of(shiftType));

        Optional<ShiftType> result = shiftTypeRepository.findByShiftName("Morning");

        assertTrue(result.isPresent());
        assertEquals("Morning", result.get().getShiftName());
        assertEquals(java.time.LocalTime.of(6, 0), result.get().getStartTime());
        assertEquals(java.time.LocalTime.of(14, 0), result.get().getEndTime());
        verify(shiftTypeRepository).findByShiftName("Morning");
    }

    @Test
    void testFindByShiftNameNotFound() {
        when(shiftTypeRepository.findByShiftName("InvalidShift")).thenReturn(Optional.empty());

        Optional<ShiftType> result = shiftTypeRepository.findByShiftName("InvalidShift");

        assertFalse(result.isPresent());
        verify(shiftTypeRepository).findByShiftName("InvalidShift");
    }
}