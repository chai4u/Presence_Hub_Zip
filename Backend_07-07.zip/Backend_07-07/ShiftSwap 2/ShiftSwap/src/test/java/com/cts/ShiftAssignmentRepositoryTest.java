package com.cts;

import com.cts.entity.ShiftAssignment;
import com.cts.entity.ShiftType;
import com.cts.repository.ShiftAssignmentRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ShiftAssignmentRepositoryTest {

    @Mock
    private ShiftAssignmentRepository shiftAssignmentRepository;

    private ShiftType shiftType;
    private ShiftAssignment assignment;
    private LocalDate assignDate;

    @BeforeEach
    void setup() {
        shiftType = new ShiftType();
        shiftType.setShiftId(101L);
        shiftType.setShiftName("Night");

        assignDate = LocalDate.of(2025, 6, 20);

        assignment = new ShiftAssignment();
        assignment.setAssignmentId(1L);
        assignment.setUserId(1L); // Using userId directly instead of UserProfile
        assignment.setShiftType(shiftType);
        assignment.setAssignDate(assignDate);
    }

    @Test
    void testFindByUserIdAndShiftTypeAndAssignDate() {
        when(shiftAssignmentRepository.findByUserIdAndShiftTypeAndAssignDate(1L, shiftType, assignDate))
                .thenReturn(Optional.of(assignment));

        Optional<ShiftAssignment> result = shiftAssignmentRepository
                .findByUserIdAndShiftTypeAndAssignDate(1L, shiftType, assignDate);

        assertTrue(result.isPresent());
        assertEquals(assignDate, result.get().getAssignDate());
        verify(shiftAssignmentRepository).findByUserIdAndShiftTypeAndAssignDate(1L, shiftType, assignDate);
    }

    @Test
    void testFindByUserId() {
        when(shiftAssignmentRepository.findByUserId(1L))
                .thenReturn(Arrays.asList(assignment));

        List<ShiftAssignment> result = shiftAssignmentRepository.findByUserId(1L);

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getUserId());
        verify(shiftAssignmentRepository).findByUserId(1L);
    }

    @Test
    void testFindByUserIdAndAssignDate() {
        when(shiftAssignmentRepository.findByUserIdAndAssignDate(1L, assignDate))
                .thenReturn(Optional.of(assignment));

        Optional<ShiftAssignment> result = shiftAssignmentRepository.findByUserIdAndAssignDate(1L, assignDate);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getUserId());
        verify(shiftAssignmentRepository).findByUserIdAndAssignDate(1L, assignDate);
    }

    @Test
    void testFindByUserIdIn() {
        List<Long> userIds = Arrays.asList(1L, 2L);
        when(shiftAssignmentRepository.findByUserIdIn(userIds))
                .thenReturn(Arrays.asList(assignment));

        List<ShiftAssignment> result = shiftAssignmentRepository.findByUserIdIn(userIds);

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getUserId());
        verify(shiftAssignmentRepository).findByUserIdIn(userIds);
    }
}