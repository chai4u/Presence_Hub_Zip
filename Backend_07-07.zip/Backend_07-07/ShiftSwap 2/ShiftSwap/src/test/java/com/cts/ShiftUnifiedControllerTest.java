package com.cts;

import com.cts.controller.ShiftUnifiedController;
import com.cts.dto.ShiftAssignmentRequestDTO;
import com.cts.dto.SwapRequestDTO;
import com.cts.entity.ShiftAssignment;
import com.cts.entity.SwapRequest;
import com.cts.service.ShiftandSwapService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.time.LocalDate;
import java.util.Collections;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
public class ShiftUnifiedControllerTest {

    @Mock
    private ShiftandSwapService shiftandSwapService;

    @InjectMocks
    private ShiftUnifiedController shiftUnifiedController;

    private MockMvc mockMvc;

    private ShiftAssignmentRequestDTO shiftAssignmentDto;
    private SwapRequestDTO swapRequestDto;

    @BeforeEach
    public void setup() {
        shiftAssignmentDto = new ShiftAssignmentRequestDTO();
        shiftAssignmentDto.setEmployeeId(1L);
        shiftAssignmentDto.setShiftName("Morning");
        shiftAssignmentDto.setAssignDate(LocalDate.now());

        swapRequestDto = new SwapRequestDTO();
        swapRequestDto.setRequesterEmployeeId(1L);
        swapRequestDto.setTargetEmployeeId(2L);
        swapRequestDto.setRequesterShiftId(3L);
        swapRequestDto.setTargetShiftId(4L);
        swapRequestDto.setSwapDate(LocalDate.now());
        swapRequestDto.setReason("Personal");
        swapRequestDto.setManagerId(5L);

        mockMvc = MockMvcBuilders.standaloneSetup(shiftUnifiedController).build();
    }

    @Test
    public void testAssignShift() throws Exception {
        when(shiftandSwapService.assignShiftToEmployee(any())).thenReturn("Shift assigned successfully.");

        mockMvc.perform(post("/api/v1/shift/manager/shift/assign")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(shiftAssignmentDto)))
                .andExpect(status().isOk());

        verify(shiftandSwapService, times(1)).assignShiftToEmployee(any());
    }

    @Test
    public void testRequestSwap() throws Exception {
        when(shiftandSwapService.requestSwap(any())).thenReturn("Swap request submitted successfully with ID: 1");

        mockMvc.perform(post("/api/v1/shift/employee/swap/request")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(swapRequestDto)))
                .andExpect(status().isOk());

        verify(shiftandSwapService, times(1)).requestSwap(any());
    }

    @Test
    public void testApproveSwap() throws Exception {
        when(shiftandSwapService.approveSwap(1L)).thenReturn("Swap approved successfully.");

        mockMvc.perform(put("/api/v1/shift/employee/swap/approve/1"))
                .andExpect(status().isOk());

        verify(shiftandSwapService).approveSwap(1L);
    }

    @Test
    public void testRejectSwap() throws Exception {
        when(shiftandSwapService.rejectSwap(1L)).thenReturn("Swap rejected successfully.");

        mockMvc.perform(put("/api/v1/shift/employee/swap/reject/1"))
                .andExpect(status().isOk());

        verify(shiftandSwapService).rejectSwap(1L);
    }

    @Test
    public void testListSwapsByManagerId() throws Exception {
        when(shiftandSwapService.listSwapsByManagerId(1L)).thenReturn(Collections.singletonList(new SwapRequest()));

        mockMvc.perform(get("/api/v1/shift/manager/swap/list/1"))
                .andExpect(status().isOk());

        verify(shiftandSwapService).listSwapsByManagerId(1L);
    }

    @Test
    public void testGetManagerEmployeeAssignments() throws Exception {
        when(shiftandSwapService.getShiftAssignmentsByManagerId(1L)).thenReturn(Collections.singletonList(new ShiftAssignment()));

        mockMvc.perform(get("/api/v1/shift/manager/assignments/1"))
                .andExpect(status().isOk());

        verify(shiftandSwapService).getShiftAssignmentsByManagerId(1L);
    }

    @Test
    public void testGetAssignmentsByUserId() throws Exception {
        when(shiftandSwapService.getShiftAssignmentsByUserId(1L)).thenReturn(Collections.singletonList(new ShiftAssignment()));

        mockMvc.perform(get("/api/v1/shift/employee/assignments/1"))
                .andExpect(status().isOk());

        verify(shiftandSwapService).getShiftAssignmentsByUserId(1L);
    }

    @Test
    public void testGetRequestsByRequester() throws Exception {
        when(shiftandSwapService.getSwapRequestsByRequester(1L)).thenReturn(Collections.singletonList(new SwapRequest()));

        mockMvc.perform(get("/api/v1/shift/employee/swap/requests/requester/1"))
                .andExpect(status().isOk());

        verify(shiftandSwapService).getSwapRequestsByRequester(1L);
    }

    @Test
    public void testGetRequestsByTarget() throws Exception {
        when(shiftandSwapService.getSwapRequestsByTarget(2L)).thenReturn(Collections.singletonList(new SwapRequest()));

        mockMvc.perform(get("/api/v1/shift/employee/swap/requests/target/2"))
                .andExpect(status().isOk());

        verify(shiftandSwapService).getSwapRequestsByTarget(2L);
    }

    private static String asJsonString(final Object obj) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            return mapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}