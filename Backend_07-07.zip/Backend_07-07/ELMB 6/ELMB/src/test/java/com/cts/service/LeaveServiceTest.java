package com.cts.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cts.UserAuthClient;
import com.cts.dto.LeaveRequestDTO;
import com.cts.entity.LeaveBalance;
import com.cts.entity.LeaveRequest;
import com.cts.entity.LeaveType;
import com.cts.enums.LeaveStatus;
import com.cts.repository.LeaveBalanceRepository;
import com.cts.repository.LeaveRequestRepository;
import com.cts.repository.LeaveTypeRepository;

class LeaveServiceTest {

    @Mock private LeaveTypeRepository typeRepo;
    @Mock private LeaveRequestRepository requestRepo;
    @Mock private LeaveBalanceRepository balanceRepo;
    @Mock private UserAuthClient userAuthClient;

    @InjectMocks private LeaveService leaveService;

    private LeaveRequestDTO dto;
    private LeaveType leaveType;
    private LeaveBalance leaveBalance;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        dto = new LeaveRequestDTO(1L, 2L, "1",
                LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), "Vacation");
        leaveType = new LeaveType(1L, "Sick Leave");
        leaveBalance = new LeaveBalance(10L, 1L, leaveType, 5);
    }

    @Test
    void requestLeave_ShouldSucceed() {
        when(typeRepo.findById(1L)).thenReturn(Optional.of(leaveType));
        when(balanceRepo.findByUserIdAndLeaveTypeId(1L, 1L)).thenReturn(leaveBalance);
        when(requestRepo.save(any())).thenAnswer(inv -> {
            LeaveRequest req = inv.getArgument(0);
            req.setLeaveId(100L);
            return req;
        });

        String response = leaveService.requestLeave(dto);
        assertTrue(response.contains("Leave request submitted successfully"));
    }

    @Test
    void requestLeave_ShouldFail_WhenLeaveTypeNotFound() {
        when(typeRepo.findById(1L)).thenReturn(Optional.empty());

        Exception ex = assertThrows(IllegalArgumentException.class,
                () -> leaveService.requestLeave(dto));
        assertEquals("Leave type with ID 1 not found.", ex.getMessage());
    }

    @Test
    void requestLeave_ShouldFail_WhenInsufficientBalance() {
        leaveBalance.setBalance(1);
        when(typeRepo.findById(1L)).thenReturn(Optional.of(leaveType));
        when(balanceRepo.findByUserIdAndLeaveTypeId(1L, 1L)).thenReturn(leaveBalance);

        String result = leaveService.requestLeave(dto);
        assertTrue(result.contains("Insufficient leave balance"));
    }

    @Test
    void approve_ShouldApproveLeaveRequest() {
        LeaveRequest req = new LeaveRequest(100L, 1L, 2L, leaveType,
                LocalDate.now().plusDays(1), LocalDate.now().plusDays(2), "Holiday", LeaveStatus.PENDING);

        when(requestRepo.findById(100L)).thenReturn(Optional.of(req));
        when(balanceRepo.findByUserIdAndLeaveTypeId(1L, 1L)).thenReturn(new LeaveBalance(10L, 1L, leaveType, 5));

        String result = leaveService.approve(100L);
        assertEquals("Leave approved", result);
        assertEquals(LeaveStatus.APPROVED, req.getStatus());
    }

    @Test
    void reject_ShouldRejectLeaveRequest() {
        LeaveRequest req = new LeaveRequest(101L, 1L, 2L, leaveType,
                LocalDate.now(), LocalDate.now().plusDays(1), "Trip", LeaveStatus.PENDING);

        when(requestRepo.findById(101L)).thenReturn(Optional.of(req));

        String result = leaveService.reject(101L);
        assertEquals("Leave rejected", result);
        assertEquals(LeaveStatus.REJECTED, req.getStatus());
    }

    @Test
    void getLeaveBalanceByUserId_ShouldReturnList() {
        when(balanceRepo.findByUserId(1L)).thenReturn(List.of(leaveBalance));
        List<LeaveBalance> result = leaveService.getLeaveBalanceByUserId(1L);
        assertEquals(1, result.size());
    }

    @Test
    void isUserOnLeaveOnDate_ShouldReturnTrueWhenActive() {
        LeaveRequest approvedLeave = new LeaveRequest();
        approvedLeave.setStatus(LeaveStatus.APPROVED);
        when(requestRepo.findActiveApprovedLeavesOnDate(1L, LocalDate.now()))
                .thenReturn(List.of(approvedLeave));

        assertTrue(leaveService.isUserOnLeaveOnDate(1L, LocalDate.now()));
    }
}