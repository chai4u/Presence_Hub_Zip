package com.cts.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cts.entity.LeaveBalance;
import com.cts.entity.LeaveRequest;
import com.cts.service.LeaveService;

@ExtendWith(MockitoExtension.class)
class LeaveControllerTest {

   @Mock
   private LeaveService leaveService;

   @InjectMocks
   private LeaveController leaveController;

   private MockMvc mockMvc;

   private LeaveRequest request;
   private LeaveBalance balance;

   @BeforeEach
   void setUp() {
       mockMvc = MockMvcBuilders.standaloneSetup(leaveController).build();
       request = new LeaveRequest();
       balance = new LeaveBalance();
   }

   @Test
   void shouldApproveLeaveRequest() throws Exception {
       when(leaveService.approve(1L)).thenReturn("Leave approved");

       mockMvc.perform(put("/api/v1/leave/manager/approve/1"))
               .andExpect(MockMvcResultMatchers.status().isOk());

       verify(leaveService, times(1)).approve(1L);
   }

   @Test
   void shouldRejectLeaveRequest() throws Exception {
       when(leaveService.reject(1L)).thenReturn("Leave rejected");

       mockMvc.perform(put("/api/v1/leave/manager/reject/1"))
               .andExpect(MockMvcResultMatchers.status().isOk());

       verify(leaveService, times(1)).reject(1L);
   }

   @Test
   void shouldGetAllRequestsByManager() throws Exception {
       when(leaveService.getAllRequestsByManager(10L)).thenReturn(List.of(request));

       mockMvc.perform(get("/api/v1/leave/manager/getAllRequests/10"))
               .andExpect(MockMvcResultMatchers.status().isOk());
   }

   @Test
   void shouldGetRequestsByUserId() throws Exception {
       when(leaveService.getLeaveRequestsByUserId(5L)).thenReturn(List.of(request));

       mockMvc.perform(get("/api/v1/leave/leave/5"))
               .andExpect(MockMvcResultMatchers.status().isOk());
   }

   @Test
   void shouldReturnLeaveBalanceForUser() throws Exception {
       when(leaveService.getLeaveBalanceByUserId(3L)).thenReturn(List.of(balance));

       mockMvc.perform(get("/api/v1/leave/employee/balance/3"))
               .andExpect(MockMvcResultMatchers.status().isOk());
   }

   @Test
   void shouldReturnIfUserIsOnLeave() throws Exception {
       Long userId = 7L;
       String date = "2025-06-24"; // Example date
       when(leaveService.isUserOnLeaveOnDate(userId, LocalDate.parse(date))).thenReturn(true);

       mockMvc.perform(get("/api/v1/leave/leave/status/" + userId + "/" + date))
               .andExpect(MockMvcResultMatchers.status().isOk());

       verify(leaveService, times(1)).isUserOnLeaveOnDate(userId, LocalDate.parse(date));
   }
}