package com.cts.repository;

import com.cts.entity.LeaveBalance;
import com.cts.entity.LeaveType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

class LeaveBalanceRepositoryTest {

    @Mock
    private LeaveBalanceRepository leaveBalanceRepository;

    @Mock
    private LeaveTypeRepository leaveTypeRepository;

    @InjectMocks
    private LeaveBalanceRepositoryTest leaveBalanceRepositoryTest;

    private LeaveType leaveType;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        leaveType = new LeaveType(1L, "Annual Leave");

        LeaveBalance balance1 = new LeaveBalance(1L, 1L, leaveType, 10);
        LeaveBalance balance2 = new LeaveBalance(2L, 2L, leaveType, 5);
        LeaveBalance balance3 = new LeaveBalance(3L, 2L, leaveType, 8);

        when(leaveBalanceRepository.findByUserIdAndLeaveTypeId(1L, leaveType.getId())).thenReturn(balance1);
        when(leaveBalanceRepository.findByUserId(2L)).thenReturn(List.of(balance2, balance3));
        when(leaveBalanceRepository.findByUserId(999L)).thenReturn(List.of());
    }

    @Test
     void testFindByUserIdAndLeaveTypeId() {
        LeaveBalance found = leaveBalanceRepository.findByUserIdAndLeaveTypeId(1L, leaveType.getId());
        assertThat(found).isNotNull();
        assertThat(found.getBalance()).isEqualTo(10);
    }

    @Test
    void testFindByUserId() {
        List<LeaveBalance> balances = leaveBalanceRepository.findByUserId(2L);
        assertThat(balances).hasSize(2);
        assertThat(balances.get(0).getBalance()).isEqualTo(5);
        assertThat(balances.get(1).getBalance()).isEqualTo(8);
    }

    @Test
     void testFindByUserId_NoResults() {
        List<LeaveBalance> balances = leaveBalanceRepository.findByUserId(999L);
        assertThat(balances).isEmpty();
    }
}