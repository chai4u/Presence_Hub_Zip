package com.cts.repository;

import com.cts.entity.LeaveRequest;
import com.cts.entity.LeaveType;
import com.cts.enums.LeaveStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

 class LeaveRequestRepositoryTest {

    @Mock
    private LeaveRequestRepository leaveRequestRepository;

    @Mock
    private LeaveTypeRepository leaveTypeRepository;

    @InjectMocks
    private LeaveRequestRepositoryTest leaveRequestRepositoryTest;

    private LeaveType leaveType;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        leaveType = new LeaveType(1L, "Casual Leave");

        LeaveRequest request1 = new LeaveRequest(1L, 1L, 100L, leaveType,
                LocalDate.of(2025, 6, 20), LocalDate.of(2025, 6, 22), "Vacation", LeaveStatus.APPROVED);

        LeaveRequest request2 = new LeaveRequest(2L, 2L, 200L, leaveType,
                LocalDate.of(2025, 6, 21), LocalDate.of(2025, 6, 23), "Sick Leave", LeaveStatus.APPROVED);

        LeaveRequest request3 = new LeaveRequest(3L, 3L, 300L, leaveType,
                LocalDate.of(2025, 6, 24), LocalDate.of(2025, 6, 26), "Conference", LeaveStatus.APPROVED);

        when(leaveRequestRepository.findByUserId(1L)).thenReturn(List.of(request1));
        when(leaveRequestRepository.findByManagerId(200L)).thenReturn(List.of(request2));
        when(leaveRequestRepository.findActiveApprovedLeavesOnDate(3L, LocalDate.of(2025, 6, 25)))
                .thenReturn(List.of(request3));
        when(leaveRequestRepository.findActiveApprovedLeavesOnDate(3L, LocalDate.of(2025, 6, 27)))
                .thenReturn(List.of());
    }

    @Test
     void testFindByUserId() {
        List<LeaveRequest> results = leaveRequestRepository.findByUserId(1L);
        assertThat(results).isNotEmpty();
        assertThat(results.get(0).getUserId()).isEqualTo(1L);
        assertThat(results.get(0).getStatus()).isEqualTo(LeaveStatus.APPROVED);
        assertThat(results.get(0).getLeaveType().getName()).isEqualTo("Casual Leave");
    }

    @Test
     void testFindByManagerId() {
        List<LeaveRequest> results = leaveRequestRepository.findByManagerId(200L);
        assertThat(results).isNotEmpty();
        assertThat(results.get(0).getManagerId()).isEqualTo(200L);
        assertThat(results.get(0).getStatus()).isEqualTo(LeaveStatus.APPROVED);
        assertThat(results.get(0).getLeaveType().getName()).isEqualTo("Casual Leave");
    }

    @Test
     void testFindActiveApprovedLeavesOnDate() {
        LocalDate checkDate = LocalDate.of(2025, 6, 25);
        List<LeaveRequest> results = leaveRequestRepository.findActiveApprovedLeavesOnDate(3L, checkDate);

        assertThat(results).isNotEmpty();
        assertThat(results.get(0).getUserId()).isEqualTo(3L);
        assertThat(results.get(0).getStatus()).isEqualTo(LeaveStatus.APPROVED);
        assertThat(results.get(0).getLeaveType().getName()).isEqualTo("Casual Leave");
    }

    @Test
     void testFindNoActiveApprovedLeavesOnDate() {
        LocalDate checkDate = LocalDate.of(2025, 6, 27); // Date outside the range
        List<LeaveRequest> results = leaveRequestRepository.findActiveApprovedLeavesOnDate(3L, checkDate);

        assertThat(results).isEmpty();
    }
}