package com.cts.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.entity.LeaveType;

public interface LeaveTypeRepository extends JpaRepository<LeaveType, Long> {
	
}
