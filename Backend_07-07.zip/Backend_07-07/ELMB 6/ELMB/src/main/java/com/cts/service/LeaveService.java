package com.cts.service;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.cts.UserAuthClient;
import com.cts.dto.LeaveRequestDTO;
import com.cts.entity.LeaveBalance;
import com.cts.entity.LeaveRequest;
import com.cts.entity.LeaveType;
import com.cts.enums.LeaveStatus;
import com.cts.repository.LeaveBalanceRepository;
import com.cts.repository.LeaveRequestRepository;
import com.cts.repository.LeaveTypeRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LeaveService {

    private final LeaveTypeRepository typeRepo;
    private final LeaveRequestRepository requestRepo;
    private final LeaveBalanceRepository balanceRepo;
    private final UserAuthClient userAuthClient;

    public String requestLeave(LeaveRequestDTO dto) {
      

        if (dto.getStartDate().isAfter(dto.getEndDate())) {
            return "Start date must be earlier than or equal to end date";
        }

        userAuthClient.getUserById(dto.getUserId());
        userAuthClient.getUserById(dto.getManagerId());

        
        Long parsedLeaveTypeId;
        try {
            parsedLeaveTypeId = Long.parseLong(dto.getLeaveTypeId());
        } catch (NumberFormatException e) {
            return "Invalid Leave Type ID format. Must be a number.";
        }

        LeaveType leaveType = typeRepo.findById(parsedLeaveTypeId)
                .orElseThrow(() -> new IllegalArgumentException("Leave type with ID " + dto.getLeaveTypeId() + " not found."));
       

        
        LeaveBalance leaveBalance = balanceRepo.findByUserIdAndLeaveTypeId(dto.getUserId(), leaveType.getId());

        if (leaveBalance == null) {
            leaveBalance = new LeaveBalance(null, dto.getUserId(), leaveType, 10);
            balanceRepo.save(leaveBalance);
           
        }
       

        int requestedDays = (int) (dto.getEndDate().toEpochDay() - dto.getStartDate().toEpochDay() + 1);

        if (leaveBalance.getBalance() < requestedDays) {
           
            return "Insufficient leave balance. Available: " + leaveBalance.getBalance() + " days.";
        }

        LeaveRequest request = new LeaveRequest();
        request.setUserId(dto.getUserId());
        request.setManagerId(dto.getManagerId());
        request.setLeaveType(leaveType);
        request.setStartDate(dto.getStartDate());
        request.setEndDate(dto.getEndDate());
        request.setReason(dto.getReason());
        request.setStatus(LeaveStatus.PENDING);

        requestRepo.save(request);
        
        return "Leave request submitted successfully. Request ID: " + request.getLeaveId();
    }


    public String approve(Long requestId) {
        LeaveRequest req = requestRepo.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Leave request with ID " + requestId + " not found"));

        if (req.getStatus() != LeaveStatus.PENDING) {
            return "Already processed";
        }

        LeaveBalance balance = balanceRepo.findByUserIdAndLeaveTypeId(req.getUserId(), req.getLeaveType().getId());
        int days = req.getEndDate().compareTo(req.getStartDate()) + 1;

        if (balance.getBalance() < days) {
            return "Insufficient balance";
        }

        balance.setBalance(balance.getBalance() - days);
        req.setStatus(LeaveStatus.APPROVED);

        balanceRepo.save(balance);
        requestRepo.save(req);
        return "Leave approved";
    }

    public String reject(Long requestId) {
        LeaveRequest req = requestRepo.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Leave request with ID " + requestId + " not found"));

        if (req.getStatus() != LeaveStatus.PENDING) {
            return "Already processed";
        }

        req.setStatus(LeaveStatus.REJECTED);
        requestRepo.save(req);
        return "Leave rejected";
    }

    public List<LeaveRequest> listAll() {
        return requestRepo.findAll();
    }

    public List<LeaveBalance> getLeaveBalanceByUserId(Long userId) {
        // Step 1: Verify if the user exists
        try {
            userAuthClient.getUserById(userId);
        } catch (Exception ex) {
            throw new IllegalArgumentException("User with UserId " + userId + " is not registered.");
        }
 
        // Step 2: Fetch existing leave balances for the user
        List<LeaveBalance> balances = balanceRepo.findByUserId(userId).stream()
                .filter(balance -> balance.getLeaveType() != null)
                .collect(Collectors.toList());
 
        // Step 3: Fetch all leave types
        List<LeaveType> leaveTypes = typeRepo.findAll();
 
        // Step 4: Ensure a leave balance exists for each leave type
        Map<Long, LeaveBalance> balanceMap = balances.stream()
                .collect(Collectors.toMap(b -> b.getLeaveType().getId(), b -> b));
 
        for (LeaveType leaveType : leaveTypes) {
            if (!balanceMap.containsKey(leaveType.getId())) {
                LeaveBalance defaultBalance = new LeaveBalance();
                defaultBalance.setUserId(userId);
                defaultBalance.setLeaveType(leaveType);
                defaultBalance.setBalance(10); // Default balance, can be dynamic
                balanceRepo.save(defaultBalance);
                balances.add(defaultBalance);
            }
        }
 
        return balances;
    }

    public List<LeaveRequest> getAllRequestsByManager(Long managerId) {
        return requestRepo.findByManagerId(managerId);
    }

    public List<LeaveRequest> getLeaveRequestsByUserId(Long userId) {
        return requestRepo.findByUserId(userId);
    }

    public Boolean isUserOnLeaveOnDate(Long userId, LocalDate date) {
        List<LeaveRequest> activeLeaves = requestRepo.findActiveApprovedLeavesOnDate(userId, date);
        return !activeLeaves.isEmpty();
    }

}
