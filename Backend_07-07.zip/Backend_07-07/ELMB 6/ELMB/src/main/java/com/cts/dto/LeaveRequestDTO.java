package com.cts.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LeaveRequestDTO {

    @NotNull(message = "User ID is required")
    public Long userId;

    @NotNull(message = "Manager ID is required")
    public Long managerId;

    @NotBlank(message = "Leave Type ID is required")
    @Pattern(regexp = "^[1-5]$", message = "Leave Type ID must be one of the following: 1, 2, 3, 4, 5")
    public String leaveTypeId;

    @NotNull(message = "Start date is required")
    @FutureOrPresent(message = "Start date must be today or in the future")
    public LocalDate startDate;

    @NotNull(message = "End date is required")
    @FutureOrPresent(message = "End date must be today or in the future")
    public LocalDate endDate;

    @NotBlank(message = "Reason is required")
    public String reason;
}