package com.cts.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.entity.LeaveRequest;

public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {

    List<LeaveRequest> findByManagerId(Long managerId);

    List<LeaveRequest> findByUserId(Long userId);

    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.userId = :userId AND lr.status = com.cts.enums.LeaveStatus.APPROVED AND :date BETWEEN lr.startDate AND lr.endDate")
    List<LeaveRequest> findActiveApprovedLeavesOnDate(@Param("userId") Long userId, @Param("date") LocalDate date);
}