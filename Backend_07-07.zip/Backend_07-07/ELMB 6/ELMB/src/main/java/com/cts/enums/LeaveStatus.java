package com.cts.enums;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
