package com.cts.seeddata;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cts.entity.LeaveType;
import com.cts.repository.*;
 
@Configuration
class SeedData {
 
    @Bean
    public CommandLineRunner loadData(
        LeaveTypeRepository typeRepo
    ) {
        return args -> {
        	if (typeRepo.count() == 0) {
 
                
                LeaveType sick = new LeaveType();
                sick.setName("Sick");
                LeaveType vacation = new LeaveType();
                vacation.setName("Vacation");
                typeRepo.saveAll(List.of(sick, vacation));
 

            }
        };
    }
}
 