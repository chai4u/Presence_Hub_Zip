package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.entity.LeaveBalance;

public interface LeaveBalanceRepository extends JpaRepository<LeaveBalance, Long> {

    LeaveBalance findByUserIdAndLeaveTypeId(Long userId, Long leaveTypeId);

    List<LeaveBalance> findByUserId(Long userId);

    @Query("SELECT lb FROM LeaveBalance lb WHERE lb.userId = :userId AND lb.balance >= :minBalance")
    List<LeaveBalance> findByUserIdAndMinBalance(@Param("userId") Long userId, @Param("minBalance") Integer minBalance);

    @Query("SELECT lb FROM LeaveBalance lb WHERE lb.leaveType.name = :leaveTypeName")
    List<LeaveBalance> findByLeaveTypeName(@Param("leaveTypeName") String leaveTypeName);

    @Query("SELECT lb FROM LeaveBalance lb WHERE lb.userId = :userId AND lb.leaveType.name = :leaveTypeName")
    LeaveBalance findByUserIdAndLeaveTypeName(@Param("userId") Long userId, @Param("leaveTypeName") String leaveTypeName);

    @Query("SELECT lb FROM LeaveBalance lb WHERE lb.balance = 0")
    List<LeaveBalance> findAllWithZeroBalance();
}