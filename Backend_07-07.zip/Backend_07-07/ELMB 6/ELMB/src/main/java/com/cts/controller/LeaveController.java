package com.cts.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.LeaveRequestDTO;
import com.cts.entity.LeaveBalance;
import com.cts.entity.LeaveRequest;
import com.cts.service.LeaveService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/leave")
@Slf4j
@RequiredArgsConstructor
//@CrossOrigin(origins = "http://localhost:3000")
public class LeaveController {

    private final LeaveService leaveService;

    @PostMapping("/employee/leave-request")
    public ResponseEntity<String> request(@Valid @RequestBody LeaveRequestDTO dto) {

        log.info("Received leave request: {}", dto);
        String response = leaveService.requestLeave(dto);
        log.info("Leave request response: {}", response);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/manager/approve/{leaveId}")
    public String approve(@PathVariable Long leaveId) {

        log.info("Approving leave request with ID: {}", leaveId);
        String response = leaveService.approve(leaveId);
        log.info("Approve response: {}", response);
        return response;
    }

    @PutMapping("/manager/reject/{leaveId}")
    public String reject(@PathVariable Long leaveId) {

        log.info("Rejecting leave request with ID: {}", leaveId);
        String response = leaveService.reject(leaveId);
        log.info("Reject response: {}", response);
        return response;
    }
    
    @GetMapping("/manager/getAllRequests/{managerId}")
    public ResponseEntity<List<LeaveRequest>> getAllRequestsByManager(@PathVariable Long managerId) {

        log.info("Fetching all leave requests for manager ID: {}", managerId);
        List<LeaveRequest> leaveRequests = leaveService.getAllRequestsByManager(managerId);
        log.info("Fetched {} leave requests for manager ID: {}", leaveRequests.size(), managerId);
        return ResponseEntity.ok(leaveRequests);
    }
    
    @GetMapping("/employee/leave/{userId}")
    public ResponseEntity<List<LeaveRequest>> getLeaveRequestsByUserId(@PathVariable Long userId) {

        log.info("Fetching leave requests for user ID: {}", userId);
        List<LeaveRequest> leaveRequests = leaveService.getLeaveRequestsByUserId(userId);
        log.info("Fetched {} leave requests for user ID: {}", leaveRequests.size(), userId);
        return ResponseEntity.ok(leaveRequests);
    }

    @GetMapping("/employee/balance/{userId}")
    public ResponseEntity<Object> getLeaveBalance(@PathVariable Long userId) {
        log.info("Fetching leave balance for user ID: {}", userId);
        try {
            List<LeaveBalance> balances = leaveService.getLeaveBalanceByUserId(userId);
            log.info("Fetched leave balances for user ID: {}", userId);
            return ResponseEntity.ok(balances);
        } catch (IllegalArgumentException ex) {
            log.warn("Error fetching leave balance for user ID {}: {}", userId, ex.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", ex.getMessage()));
        }
    }
    
    @GetMapping("/leave/status/{userId}/{date}")
    public Boolean isUserOnLeave(
            @PathVariable Long userId,
            @PathVariable("date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return leaveService.isUserOnLeaveOnDate(userId, date);
    }



}