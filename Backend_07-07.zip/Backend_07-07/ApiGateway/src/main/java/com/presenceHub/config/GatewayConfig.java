package com.presenceHub.config;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
@Configuration
public class GatewayConfig {
	@Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
            .route("leave-management", r -> r.path("/api/v1/leave/**")
//                .filters(f -> f
//                    .addResponseHeader("Access-Control-Allow-Origin", "*")
//                    .addResponseHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
//                    .addResponseHeader("Access-Control-Allow-Headers", "*"))
                .uri("lb://leave-management"))
            .route("auth-service", r -> r.path("/api/v1/auth/**")
//            		.filters(f -> f
//                            .addResponseHeader("Access-Control-Allow-Origin", "*")
//                            .addResponseHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
//                            .addResponseHeader("Access-Control-Allow-Headers", "*"))	
                .uri("lb://EmpALMS-1"))  
            .route("employee-attendance", r -> r.path("/api/v1/attendance/**")
                .uri("lb://Employee-Attendance"))   
            .route("report-service", r -> r.path("/api/v1/reports/**")
                .uri("lb://report-service"))
            .route("shift-management", r -> r.path("/api/v1/shift/**")
                .uri("lb://Shift-management"))
            .build();
    }
 
}