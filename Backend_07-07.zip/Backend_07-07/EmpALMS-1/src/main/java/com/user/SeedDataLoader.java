package com.user;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.user.entity.Role;
import com.user.entity.UserProfile;
import com.user.entity.UserRoleMap;
import com.user.repository.RoleRepository;
import com.user.repository.UserProfileRepository;
import com.user.repository.UserRoleMapRepository;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class SeedDataLoader implements CommandLineRunner {
 
    private final UserProfileRepository userRepo;
    private final RoleRepository roleRepo;
    private final UserRoleMapRepository roleMapRepo;
    private final PasswordEncoder passwordEncoder;
 
    @Override
    public void run(String... args) throws Exception {
        // Create roles if they don't exist
        Role adminRole = roleRepo.findById(1).orElse(new Role(1, "admin"));
        Role managerRole = roleRepo.findById(2).orElse(new Role(2, "manager"));
        Role employeeRole = roleRepo.findById(3).orElse(new Role(3, "employee"));

        if(roleRepo.count() == 0) {
            roleRepo.save(adminRole);
            roleRepo.save(managerRole);
            roleRepo.save(employeeRole);
        }

        // Create admin user if it doesn't exist
        UserProfile adminUser = userRepo.findByEmail("admin@example.com");
        if(adminUser == null) {
            adminUser = new UserProfile();
            adminUser.setFullName("Admin User");
            adminUser.setEmail("admin@example.com");
            adminUser.setPassword(passwordEncoder.encode("Admin@123"));
            adminUser.setPhone("1234567890");
            adminUser.setEmployeeCode("ADMIN001");
            adminUser.setManager(null); // Admin has no manager
            userRepo.save(adminUser);

            // Map admin role
            roleMapRepo.save(new UserRoleMap(adminUser, adminRole));
            // Map manager role to admin
            roleMapRepo.save(new UserRoleMap(adminUser, managerRole));
        }
    }
}