package com.user.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.user.dto.UserDataDto;
import com.user.repository.UserProfileRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserProfileRepository userRepo;

    public List<UserDataDto> getAllUsers() {
        return userRepo.findAll().stream().map(user -> {
            String managerName = user.getManager() != null ? user.getManager().getFullName() : "No Manager";
            return new UserDataDto(user.getId(), user.getFullName(), user.getEmail(), managerName);
        }).toList(); 
    }

    public UserDataDto getUserById(Integer id) {
        return userRepo.findById(id).map(user -> {
            String managerName = user.getManager() != null ? user.getManager().getFullName() : "No Manager";
            return new UserDataDto(user.getId(),user.getFullName(), user.getEmail(), managerName);
        }).orElse(null);
    }

    public List<UserDataDto> getEmployeesByManager(int managerId) {
        return userRepo.findByManagerId(managerId).stream()
            .map(user -> new UserDataDto( 
                user.getId(),
                user.getFullName(),
                user.getEmail(),
                user.getManager() != null ? user.getManager().getFullName() : null
                
            ))
            .toList();
    }
}