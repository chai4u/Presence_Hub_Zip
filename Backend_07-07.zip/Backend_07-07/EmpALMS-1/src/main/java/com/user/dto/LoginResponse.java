package com.user.dto;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LoginResponse {
	private String fullName;
	private String email;
	private String token;
	private Integer id;
	private Integer managerId;
	private String role;
	private String managerName;
}