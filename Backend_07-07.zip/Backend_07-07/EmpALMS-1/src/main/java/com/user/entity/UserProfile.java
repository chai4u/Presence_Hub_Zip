package com.user.entity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import com.user.repository.UserRoleMapRepository;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "user_profile")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class UserProfile {
    

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	
    private int id;
 
    private String fullName;
    private String email;
    
    private String phone;
    private String employeeCode;
    private String password;
    //private String role; //admin,employee,manager
    
    
    
 
    @ManyToOne
    @JoinColumn(name = "manager_id")
    private UserProfile manager;
 
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdDate;
 
    
    private LocalDateTime updatedDate;
    
 
    @PrePersist
    protected void onCreate() {
        this.createdDate = LocalDateTime.now();
    }
 
    @PreUpdate
    protected void onUpdate() {
        this.updatedDate = LocalDateTime.now();
    }
    
 
    public UserProfile(String fullName, String email,String password, String phone, String employeeCode, UserProfile manager) {//,String role
		
		this.fullName = fullName;
		this.email = email;
		this.password = password;
		//this.role = role;
		this.phone = phone;
		this.employeeCode = employeeCode;
		this.manager = manager;
	}

	

	
}
