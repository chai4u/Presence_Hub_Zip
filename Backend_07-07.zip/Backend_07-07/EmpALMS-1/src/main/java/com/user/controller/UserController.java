package com.user.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.dto.LoginRequest;
import com.user.dto.LoginResponse;
import com.user.dto.UserDataDto;
import com.user.dto.UserProfileDto;
import com.user.service.AuthService;
import com.user.service.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
//@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
 
     
    private final UserService userService;
    
    private final AuthService authService;
 

    @PostMapping("register/user")
    public ResponseEntity<String> registerUser(@Valid @RequestBody UserProfileDto userProfileDto){
    	return ResponseEntity.ok(authService.register(userProfileDto));
    }
    
    @PostMapping("login/user")
    public LoginResponse loginUser(@Valid @RequestBody LoginRequest loginRequest) {
    	return  authService.login(loginRequest.getEmail(), loginRequest.getPassword());
    	
    }
    
    @GetMapping("/admin/test")
    public String test() {
    	return "hello this should be accessed by admin only";
    }
    
    @GetMapping("/manager/test")
    public String test1() {
    	return "hello this should be accessed by manager only";
    }
    @GetMapping("/employee/test")
    public String test2() {
    	return "hello this should be accessed by employee only";
    }
    
    @GetMapping("/user/all")
    public ResponseEntity<List<UserDataDto>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<UserDataDto> getUserById(@PathVariable Integer id) {
        UserDataDto user = userService.getUserById(id);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @GetMapping("/user/manager/{managerId}")
    public ResponseEntity<List<UserDataDto>> getEmployeesByManager(@PathVariable int managerId) {
        return ResponseEntity.ok(userService.getEmployeesByManager(managerId));
    }
}


