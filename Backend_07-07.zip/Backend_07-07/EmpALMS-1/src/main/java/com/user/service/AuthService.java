package com.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.user.dto.LoginResponse;
import com.user.dto.UserProfileDto;
import com.user.entity.Role;
import com.user.entity.UserProfile;
import com.user.entity.UserRoleMap;
import com.user.exception.InvalidUserCredentialsException;
import com.user.exception.UserAlreadyExistsException;
import com.user.repository.UserProfileRepository;
import com.user.repository.UserRoleMapRepository;
import com.user.security.JwtUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@RequiredArgsConstructor
public class AuthService {
	
	private final UserProfileRepository userProfileRepository;

	
	private  final PasswordEncoder passwordEncoder;
	
	private final UserRoleMapRepository userRoleMapRepository;

	
	private  final JwtUtil jwtUtil;

	public String register(UserProfileDto userProfileDto) {
		log.info("Registering user with email: {}", userProfileDto.getEmail());

		Role role = null;
		Role role1 = null;
		UserProfile userm = null;
		
		UserProfile userEmail = userProfileRepository.findByEmail(userProfileDto.getEmail());
		if(userEmail != null) {
   		 log.info("agent is already registered");
   		 throw new UserAlreadyExistsException("You have already registered");
   	}
		
		String s= "employee";
		if (userProfileDto.getRole().equals(s)) {
			Optional<UserProfile> userms = userProfileRepository.findById(userProfileDto.getManagerId());
			if (userms.isPresent()) {
				userm = userms.get();
				log.info("Found manager with ID: {}", userm.getId());
			} else {
				log.warn("Manager ID {} not found!", userProfileDto.getManagerId());
			}
			role = new Role(3, s);
		} else {
			Optional<UserProfile> userms = userProfileRepository.findById(1);
			if (userms.isPresent()) {
				userm = userms.get();
				log.info("Assigning default manager with ID: {}", userm.getId());
			} else {
				log.warn("Default manager with ID 1 not found!");
			}
			role = new Role(3, s);
			role1 = new Role(2, "manager");
		}

		UserProfile user = new UserProfile(userProfileDto.getFullName(), userProfileDto.getEmail(),
				passwordEncoder.encode(userProfileDto.getPassword()), 
				userProfileDto.getPhone(), userProfileDto.getEmployeeCode(), userm);

		userProfileRepository.save(user);
		log.info("User saved successfully with ID: {}", user.getId());

		UserRoleMap rmap = new UserRoleMap(user, role);
		userRoleMapRepository.save(rmap);
		log.info("Role assigned: {}", role.getName());

		if (role1 != null) {
			UserRoleMap rmap1 = new UserRoleMap(user, role1);
			userRoleMapRepository.save(rmap1);
			log.info("Secondary role assigned: {}", role1.getName());
		}

		return "User Registered Successfully";
	}

	// Inside the login method, modify the role determination logic:

	public LoginResponse login(String email, String password) {
	    UserProfile user = userProfileRepository.findByEmail(email);
	    
	    if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
	        throw new InvalidUserCredentialsException("Invalid User Credentials! Wrong username or password");
	    }

	    List<UserRoleMap> userRoleMap = userRoleMapRepository.findByUserId(user.getId());
	    String role = "employee"; // default role

	    // Check for admin role first
	    if (userRoleMap.stream().anyMatch(rm -> "admin".equals(rm.getRole().getName()))) {
	        role = "admin";
	    } else if (userRoleMap.stream().anyMatch(rm -> "manager".equals(rm.getRole().getName()))) {
	        role = "manager";
	    }

	    String token = jwtUtil.generateToken(user.getEmail(), role);
	    Integer managerId = user.getManager() != null ? user.getManager().getId() : null;
	    String managerName = user.getManager() != null ? user.getManager().getFullName() : null;

	    return new LoginResponse(
	        user.getFullName(),
	        email,
	        token,
	        user.getId(),
	        managerId,
	        role,
	        managerName
	    );
	}
}
