package com.user.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserProfileDto {
	
	@NotBlank(message = "Name is required")
    @Size(min = 2, max = 25, message = "Name must be between 2 and 25 characters")
	private String fullName;
	
	@NotBlank(message = "Email is required")
    @Size(min = 2, max = 25, message = "Email must be between 2 and 25 characters")
	@Email(message="Enter correct e-mail address")
    private String email;
	
	@NotBlank(message = "Phone number is required")
    @Size(min = 10, max = 10, message = "Phone number must 10 characters")
    private String phone;
	
	@NotBlank(message = "Employee Code is required")
    @Size(min = 4, max = 6, message = "Employee code must be given")
    private String employeeCode;
	
	@NotBlank(message = "Password is required")
    @Size(min = 8, max = 25, message = "Password must be between 8 and 25 characters")
	@Pattern(regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]+$", message = "Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character")
    private String password;
	
	@NotNull(message="managerId cannot be null")
	@Min(value=1)
    private int managerId;
	
	@NotBlank(message = "Role is required")
    @Size(min = 1, max = 10, message = "Role must be between 1 and 10 characters")
    private String role; //admin,employee,manager
 

}
