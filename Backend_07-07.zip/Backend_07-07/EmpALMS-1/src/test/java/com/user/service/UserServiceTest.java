package com.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.user.dto.UserDataDto;
import com.user.entity.UserProfile;
import com.user.repository.UserProfileRepository;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserProfileRepository userRepo;

    @InjectMocks
    private UserService userService;

    private UserProfile manager;
    private UserProfile employee;

    @BeforeEach
    void setup() {
        manager = new UserProfile();
        manager.setId(1);
        manager.setFullName("Manager Name");
        manager.setEmail("manager@example.com");

        employee = new UserProfile();
        employee.setId(2);
        employee.setFullName("Employee Name");
        employee.setEmail("employee@example.com");
        employee.setManager(manager);
    }

    @Test
    void testGetAllUsers() {
        when(userRepo.findAll()).thenReturn(Arrays.asList(manager, employee));

        List<UserDataDto> users = userService.getAllUsers();

        assertEquals(2, users.size());
        assertEquals("Manager Name", users.get(0).getName());
        assertEquals("No Manager", users.get(0).getManager());
        assertEquals("Employee Name", users.get(1).getName());
        assertEquals("Manager Name", users.get(1).getManager());
    }

    @Test
    void testGetUserById_Found() {
        when(userRepo.findById(2)).thenReturn(Optional.of(employee));

        UserDataDto user = userService.getUserById(2);

        assertEquals("Employee Name", user.getName());
        assertEquals("Employee Name", user.getName());
        assertEquals("Manager Name", user.getManager());
    }

    @Test
    void testGetUserById_NotFound() {
        when(userRepo.findById(3)).thenReturn(Optional.empty());

        UserDataDto user = userService.getUserById(3);

        assertNull(user);
    }

    @Test
    void testGetEmployeesByManager() {
        when(userRepo.findByManagerId(1)).thenReturn(Arrays.asList(employee));

        List<UserDataDto> employees = userService.getEmployeesByManager(1);

        assertEquals(1, employees.size());
        assertEquals("Employee Name", employees.get(0).getName());
        assertEquals("Manager Name", employees.get(0).getManager());
    }
}