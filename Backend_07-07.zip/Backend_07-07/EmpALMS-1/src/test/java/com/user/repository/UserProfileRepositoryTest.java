package com.user.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import com.user.entity.UserProfile;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserProfileRepositoryTest {

    @Mock
    private UserProfileRepository userProfileRepository;

    private UserProfile manager;
    private UserProfile employee;

    @BeforeEach
    void setUp() {
        // Create mock manager
        manager = new UserProfile();
        manager.setId(1);
        manager.setFullName("Manager Name");
        manager.setEmail("manager@example.com");
        manager.setPassword("password123");

        // Create mock employee
        employee = new UserProfile();
        employee.setId(2);
        employee.setFullName("Employee Name");
        employee.setEmail("employee@example.com");
        employee.setPassword("password123");
        employee.setManager(manager);

        // Mock repository behavior
        Mockito.when(userProfileRepository.findByManagerId(1)).thenReturn(Arrays.asList(employee));
        Mockito.when(userProfileRepository.findByManagerId(999)).thenReturn(List.of());
        Mockito.when(userProfileRepository.findByEmail("employee@example.com")).thenReturn(employee);
        Mockito.when(userProfileRepository.findByEmail("unknown@example.com")).thenReturn(null);
        Mockito.when(userProfileRepository.findByEmail(null)).thenThrow(new IllegalArgumentException("Email cannot be null"));
    }

    @Test
    void testFindByManagerId_Found() {
        List<UserProfile> employees = userProfileRepository.findByManagerId(1);

        assertNotNull(employees);
        assertEquals(1, employees.size());
        assertEquals("Employee Name", employees.get(0).getFullName());
        assertEquals("manager@example.com", employees.get(0).getManager().getEmail());
    }

    @Test
    void testFindByManagerId_NotFound() {
        List<UserProfile> employees = userProfileRepository.findByManagerId(999);

        assertNotNull(employees);
        assertEquals(0, employees.size());
    }

    @Test
    void testFindByEmail_Found() {
        UserProfile foundUser = userProfileRepository.findByEmail("employee@example.com");

        assertNotNull(foundUser);
        assertEquals("Employee Name", foundUser.getFullName());
        assertEquals("manager@example.com", foundUser.getManager().getEmail());
    }

    @Test
    void testFindByEmail_NotFound() {
        UserProfile foundUser = userProfileRepository.findByEmail("unknown@example.com");

        assertEquals(null, foundUser);
    }

    @Test
    void testFindByEmail_NullEmail() {
        assertThrows(IllegalArgumentException.class, () -> userProfileRepository.findByEmail(null));
    }
}