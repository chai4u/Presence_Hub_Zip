package com.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpAlms1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
