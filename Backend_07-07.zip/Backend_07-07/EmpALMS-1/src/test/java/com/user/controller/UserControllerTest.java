package com.user.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString; // Added for clarity
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.Collections; // Added for emptyList
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.user.dto.LoginRequest;
import com.user.dto.LoginResponse;
import com.user.dto.UserDataDto;
import com.user.dto.UserProfileDto;
import com.user.service.AuthService;
import com.user.service.UserService;
// Import your specific exception
import com.user.exception.InvalidUserCredentialsException;


@ExtendWith(MockitoExtension.class)
class UserControllerTest {

   @Mock
   private UserService userService;

   @Mock
   private AuthService authService;

   @InjectMocks
   private UserController userController;

   private MockMvc mockMvc;

   private UserProfileDto userProfileDto;
   private LoginRequest loginRequest;
   private LoginResponse loginResponse;

   // Helper for JSON serialization
   private ObjectMapper objectMapper = new ObjectMapper();

   @BeforeEach
   void setup() {
       mockMvc = MockMvcBuilders.standaloneSetup(userController).build();

       userProfileDto = new UserProfileDto();
       userProfileDto.setFullName("John Doe");
       userProfileDto.setEmail("john.doe@example.com");
       userProfileDto.setPhone("1234567890");
       userProfileDto.setEmployeeCode("EMP123");
       userProfileDto.setPassword("Password@123"); // Ensure it matches your @Pattern if applicable
       userProfileDto.setManagerId(1);
       userProfileDto.setRole("employee");

       loginRequest = new LoginRequest();
       loginRequest.setEmail("john.doe@example.com");
       loginRequest.setPassword("password123");

       loginResponse = new LoginResponse(
           "John Doe",             // fullName
           "john.doe@example.com", // email
           "mockToken",            // token
           2,                      // id
           1,                      // managerId
           "employee",             // role
           "Manager Name"          // managerName
       );
   }

   @Test
   void testRegisterUser() throws Exception {
       when(authService.register(any(UserProfileDto.class))).thenReturn("User registered successfully");

       mockMvc.perform(post("/api/v1/auth/register/user")
               .contentType(MediaType.APPLICATION_JSON)
               .content(asJsonString(userProfileDto)))
               .andExpect(status().isOk())
               .andExpect(content().string("User registered successfully"));

       verify(authService, times(1)).register(any(UserProfileDto.class));
   }

   @Test
   void testLoginUser() throws Exception {
       when(authService.login(anyString(), anyString())).thenReturn(loginResponse);

       mockMvc.perform(post("/api/v1/auth/login/user")
               .contentType(MediaType.APPLICATION_JSON)
               .content(asJsonString(loginRequest)))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.token").value("mockToken"))
               .andExpect(jsonPath("$.role").value("employee"))
               .andExpect(jsonPath("$.fullName").value("John Doe"));

       verify(authService, times(1)).login(anyString(), anyString());
   }

   @Test
   void testGetAllUsers() throws Exception {
       UserDataDto user1 = new UserDataDto(1, "User1", "user1@example.com", "Manager1");
       UserDataDto user2 = new UserDataDto(2, "User2", "user2@example.com", "Manager2");
       List<UserDataDto> users = Arrays.asList(user1, user2);
       when(userService.getAllUsers()).thenReturn(users);

       mockMvc.perform(get("/api/v1/auth/user/all")
               .contentType(MediaType.APPLICATION_JSON))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$[0].id").value(1))
               .andExpect(jsonPath("$[0].name").value("User1"))
               .andExpect(jsonPath("$[1].id").value(2));

       verify(userService, times(1)).getAllUsers();
   }

   @Test
   void testGetUserById() throws Exception {
       UserDataDto user = new UserDataDto(1, "Test User", "test@example.com", "Test Manager");
       when(userService.getUserById(1)).thenReturn(user);

       mockMvc.perform(get("/api/v1/auth/user/1")
               .contentType(MediaType.APPLICATION_JSON))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.id").value(1))
               .andExpect(jsonPath("$.name").value("Test User"));

       verify(userService, times(1)).getUserById(1);
   }

   @Test
   void testGetEmployeesByManager() throws Exception {
       UserDataDto emp1 = new UserDataDto(10, "EmpA", "empA@example.com", "ManagerX");
       UserDataDto emp2 = new UserDataDto(11, "EmpB", "empB@example.com", "ManagerX");
       List<UserDataDto> employees = Arrays.asList(emp1, emp2);
       when(userService.getEmployeesByManager(1)).thenReturn(employees);

       mockMvc.perform(get("/api/v1/auth/user/manager/1")
               .contentType(MediaType.APPLICATION_JSON))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$[0].id").value(10))
               .andExpect(jsonPath("$[1].name").value("EmpB"));

       verify(userService, times(1)).getEmployeesByManager(1);
   }

   @Test
   void testRegisterUserWithInvalidData() throws Exception {
       UserProfileDto invalidUser = new UserProfileDto();
       invalidUser.setFullName(""); // Blank name
       invalidUser.setEmail("invalid-email"); // Invalid email
       invalidUser.setPhone("123"); // Invalid phone length
       invalidUser.setEmployeeCode("123"); // Invalid employee code length
       invalidUser.setPassword("short"); // Invalid password length/pattern
       invalidUser.setManagerId(0); // Invalid managerId
       invalidUser.setRole(""); // Blank role
       
       mockMvc.perform(post("/api/v1/auth/register/user")
               .contentType(MediaType.APPLICATION_JSON)
               .content(asJsonString(invalidUser)))
               .andExpect(status().isBadRequest());
   }

//   @Test
//   void testLoginUserWithInvalidCredentials() throws Exception {
//       // Mock to throw your specific InvalidUserCredentialsException
//       when(authService.login(anyString(), anyString())).thenThrow(new InvalidUserCredentialsException("Invalid credentials"));
//
//       mockMvc.perform(post("/api/v1/auth/login/user")
//               .contentType(MediaType.APPLICATION_JSON)
//               .content(asJsonString(loginRequest)))
//               .andExpect(status().isUnauthorized()); // Expects 401 Unauthorized due to GlobalExceptionHandler
//   }

   @Test
   void testGetUserByIdNotFound() throws Exception {
       // Mock userService.getUserById to return null, as your controller handles null for 404
       when(userService.getUserById(999)).thenReturn(null);

       mockMvc.perform(get("/api/v1/auth/user/999")
               .contentType(MediaType.APPLICATION_JSON))
               .andExpect(status().isNotFound()); // Expects 404 Not Found
   }

   @Test
   void testGetEmployeesByManagerWithNoEmployees() throws Exception {
       when(userService.getEmployeesByManager(1)).thenReturn(Collections.emptyList());

       mockMvc.perform(get("/api/v1/auth/user/manager/1")
               .contentType(MediaType.APPLICATION_JSON))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$").isEmpty());

       verify(userService, times(1)).getEmployeesByManager(1);
   }

   // Helper method to convert objects to JSON string
   public String asJsonString(final Object obj) {
       try {
           return objectMapper.writeValueAsString(obj);
       } catch (Exception e) {
           throw new RuntimeException(e);
       }
   }
}