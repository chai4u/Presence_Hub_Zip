package com.user.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import com.user.entity.Role;
import com.user.entity.UserProfile;
import com.user.entity.UserRoleMap;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserRoleMapRepositoryTest {

    @Mock
    private UserRoleMapRepository userRoleMapRepository;

    private UserProfile user;
    private UserRoleMap roleMap1;
    private UserRoleMap roleMap2;

    @BeforeEach
    void setUp() {
        // Create mock user
        user = new UserProfile();
        user.setId(1);
        user.setFullName("John Doe");
        user.setEmail("john.doe@example.com");

        // Create mock roles
        Role role1 = new Role(1, "employee");
        Role role2 = new Role(2, "manager");

        // Create mock UserRoleMap entries
        roleMap1 = new UserRoleMap(user, role1);
        roleMap2 = new UserRoleMap(user, role2);

        // Mock repository behavior
        Mockito.when(userRoleMapRepository.findByUserId(1)).thenReturn(Arrays.asList(roleMap1, roleMap2));
        Mockito.when(userRoleMapRepository.findByUserId(999)).thenReturn(List.of());
    }

    @Test
    void testFindByUserId_Found() {
        List<UserRoleMap> roles = userRoleMapRepository.findByUserId(1);

        assertNotNull(roles);
        assertEquals(2, roles.size());
        assertEquals("employee", roles.get(0).getRole().getName());
        assertEquals("manager", roles.get(1).getRole().getName());
    }

    @Test
    void testFindByUserId_NotFound() {
        List<UserRoleMap> roles = userRoleMapRepository.findByUserId(999);

        assertNotNull(roles);
        assertTrue(roles.isEmpty());
    }
}
