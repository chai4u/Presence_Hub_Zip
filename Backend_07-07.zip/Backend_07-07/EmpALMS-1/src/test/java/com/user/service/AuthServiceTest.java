package com.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyInt;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.user.dto.LoginResponse;
import com.user.dto.UserProfileDto;
import com.user.entity.Role;
import com.user.entity.UserProfile;
import com.user.entity.UserRoleMap;
import com.user.exception.InvalidUserCredentialsException;
import com.user.exception.UserAlreadyExistsException;
import com.user.repository.UserProfileRepository;
import com.user.repository.UserRoleMapRepository;
import com.user.security.JwtUtil;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserProfileRepository userProfileRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private UserRoleMapRepository userRoleMapRepository;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private AuthService authService;

    private UserProfileDto userProfileDto;
    private UserProfile userProfile;

    @BeforeEach
    void setup() {
        userProfileDto = new UserProfileDto();
        userProfileDto.setFullName("John Doe");
        userProfileDto.setEmail("john.doe@example.com");
        userProfileDto.setPassword("password123");
        userProfileDto.setPhone("1234567890");
        userProfileDto.setEmployeeCode("EMP123");
        userProfileDto.setManagerId(1);
        userProfileDto.setRole("employee");

        userProfile = new UserProfile("John Doe", "john.doe@example.com", "encodedPassword", "1234567890", "EMP123", null);
    }

    @Test
    void testRegisterUser_Success() {
        when(userProfileRepository.findByEmail(anyString())).thenReturn(null);
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userProfileRepository.findById(anyInt())).thenReturn(Optional.of(new UserProfile()));
        when(userProfileRepository.save(any(UserProfile.class))).thenReturn(userProfile);

        String result = authService.register(userProfileDto);

        assertEquals("User Registered Successfully", result);
    }

    @Test
    void testRegisterUser_UserAlreadyExists() {
        when(userProfileRepository.findByEmail(anyString())).thenReturn(userProfile);

        assertThrows(UserAlreadyExistsException.class, () -> authService.register(userProfileDto));
    }

    @Test
    void testLogin_Success() {
        // Mock manager profile
        UserProfile managerProfile = new UserProfile();
        managerProfile.setId(1); // Set manager ID

        // Mock user profile with manager
        userProfile.setManager(managerProfile);

        when(userProfileRepository.findByEmail(anyString())).thenReturn(userProfile);
        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(true);
        when(jwtUtil.generateToken(anyString(), anyString())).thenReturn("mockToken");
        when(userRoleMapRepository.findByUserId(anyInt()))
            .thenReturn(List.of(new UserRoleMap(userProfile, new Role(3, "employee"))));

        LoginResponse response = authService.login("john.doe@example.com", "password123");

        assertEquals("John Doe", response.getFullName());
        assertEquals("john.doe@example.com", response.getEmail());
        assertEquals("mockToken", response.getToken());
        assertEquals(1, response.getManagerId()); // Ensure manager ID is correct
    }
    @Test
    void testLogin_InvalidCredentials() {
        when(userProfileRepository.findByEmail(anyString())).thenReturn(userProfile);
        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(false);

        assertThrows(InvalidUserCredentialsException.class, () -> authService.login("john.doe@example.com", "wrongPassword"));
    }

    @Test
    void testLogin_UserNotFound() {
        when(userProfileRepository.findByEmail(anyString())).thenReturn(null);

        assertThrows(InvalidUserCredentialsException.class, () -> authService.login("john.doe@example.com", "password123"));
    }
}