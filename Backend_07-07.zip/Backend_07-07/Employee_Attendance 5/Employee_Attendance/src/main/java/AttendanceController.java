

import java.time.LocalDate;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.AttendanceDto;
import com.example.model.Attendance;
import com.example.service.AttendanceService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/attendance")
@RequiredArgsConstructor
public class AttendanceController {

    private final AttendanceService attendanceService;

    @PostMapping("employee/clock-in/{employeeId}")
    public Attendance clockIn(@PathVariable Long employeeId) {
        return attendanceService.clockIn(employeeId);
    }

    @PostMapping("employee/clock-out/{employeeId}")
    public Attendance clockOut(@PathVariable Long employeeId) {
        return attendanceService.clockOut(employeeId);
    }
    @GetMapping("employee/history/{employeeId}/{startDate}/{endDate}")
    public List<AttendanceDto> getAttendanceHistory(@PathVariable Long employeeId,@PathVariable LocalDate startDate, @PathVariable LocalDate endDate) {
        return attendanceService.getAttendanceByEmployeeId(employeeId,startDate,endDate);
    }

//    @GetMapping("/manager/history/{mangerId}")
//    public List<Attendance> getAllAttendanceRecords(@PathVariable Long mangerId) {
//        return attendanceService.getAllAttendanceRecords();
//    }
}
