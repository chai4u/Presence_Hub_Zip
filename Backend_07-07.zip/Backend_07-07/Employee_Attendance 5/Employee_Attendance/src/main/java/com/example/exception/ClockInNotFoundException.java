package com.example.exception;

public class ClockInNotFoundException extends RuntimeException {
    public ClockInNotFoundException(String message) {
        super(message);
    }
}

