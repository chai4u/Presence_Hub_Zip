package com.example.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.AttendanceDto;
import com.example.model.Attendance;
import com.example.service.AttendanceService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/attendance")
@RequiredArgsConstructor
//@CrossOrigin(origins = "http://localhost:3000",allowCredentials = "true")
public class AttendanceController {

    private final AttendanceService attendanceService;

    @PostMapping("employee/clock-in/{employeeId}")
    public Attendance clockIn(@PathVariable Long employeeId) {
        return attendanceService.clockIn(employeeId);
    }

    @PostMapping("employee/clock-out/{employeeId}")
    public Attendance clockOut(@PathVariable Long employeeId) {
        return attendanceService.clockOut(employeeId);
    }
    @GetMapping("employee/history/{employeeId}/{startDate}/{endDate}")
    public List<AttendanceDto> getAttendanceHistory(@PathVariable Long employeeId,@PathVariable LocalDate startDate, @PathVariable LocalDate endDate) {
        return attendanceService.getAttendanceByEmployeeId(employeeId,startDate,endDate);
    }

    @GetMapping("manager/history/{managerId}/{startDate}/{endDate}")
    public ResponseEntity<List<AttendanceDto>> getManagerAttendanceReport(
            @PathVariable int managerId,
            @PathVariable("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @PathVariable("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        List<AttendanceDto> report = attendanceService.getAttendanceReportByManager(managerId, startDate, endDate);
        return ResponseEntity.ok(report);
    }
    @GetMapping("employee/today/{employeeId}")
    public ResponseEntity<Attendance> getTodayAttendance(@PathVariable Long employeeId) {
        Attendance attendance = attendanceService.getTodayAttendance(employeeId);
        return ResponseEntity.ok(attendance);
    }

}