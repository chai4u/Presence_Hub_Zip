package com.example.repository;


import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.dto.AttendanceDto;
import com.example.model.Attendance;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findByEmployeeId(Long employeeId);
    boolean existsByDate(LocalDate date);
    
    @Query("SELECT new com.example.dto.AttendanceDto(" +
            "a.employeeId, a.date, a.clockIn, a.clockOut, a.isPresent) " +
            "FROM Attendance a " +
            "WHERE a.employeeId = :employeeId AND a.date BETWEEN :startDate AND :endDate")
     List<AttendanceDto> findAttendanceDtosByEmployeeIdAndDateBetween(Long employeeId, LocalDate startDate, LocalDate endDate);

    
    List<Attendance> findByEmployeeIdInAndDateBetween(List<Long> employeeIds, LocalDate startDate, LocalDate endDate);

}

