package com.example.exception;
public class AttendanceAlreadyInitializedException extends RuntimeException {
	public AttendanceAlreadyInitializedException(String message) {
        super(message);
    }
}
