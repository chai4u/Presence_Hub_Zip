package com.example.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.example.FiegnClient;
import com.example.dto.AttendanceDto;
import com.example.dto.UserDataDto;
import com.example.exception.AttendanceAlreadyInitializedException;
import com.example.exception.AttendanceAlreadyMarkedException;
import com.example.exception.ClockInNotFoundException;
import com.example.model.Attendance;
import com.example.repository.AttendanceRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class AttendanceService {
    private final AttendanceRepository attendanceRepository;
    private final FiegnClient userFeignClient;

    @Scheduled(cron = "0 49 14 * * ?")
    public void initializeDailyAttendance() {
        LocalDate today = LocalDate.now();

        if (attendanceRepository.existsByDate(today)) {
            log.warn("Attendance already initialized for today.");
            throw new AttendanceAlreadyInitializedException("Attendance already initialized for today.");
        }
        List<UserDataDto> allEmployees = userFeignClient.getAllUsers();

        for (UserDataDto employee : allEmployees) {
            Attendance attendance = new Attendance();
            attendance.setEmployeeId(Long.valueOf(employee.getId())); // Changed from employee.getEmployeeCode()
            attendance.setDate(today);
            attendance.setClockIn(null);
            attendance.setClockOut(null);
            attendance.setIsPresent(false);
            attendanceRepository.save(attendance);
        }
    }


    public Attendance clockIn(Long employeeId) {
        log.info("Marking attendance for employee ID: {}", employeeId);
        LocalDate today = LocalDate.now();

        Attendance attendance = attendanceRepository.findByEmployeeId(employeeId).stream()
            .filter(a -> a.getDate() != null && a.getDate().equals(today))
            .findFirst()
            .orElseThrow(() -> {
                log.warn("No initialized attendance found for today.");
                return new AttendanceAlreadyInitializedException("Attendance initialized for today.");
            });

        if (attendance.getClockIn() != null) {
            log.warn("Clock-in already recorded for employee ID: {}", employeeId);
            throw new AttendanceAlreadyMarkedException("You have already clocked in.");
        }

        
        attendance.setClockIn(LocalDateTime.now());
        attendance.setIsPresent(true);
        return attendanceRepository.save(attendance);
    }

    public Attendance clockOut(Long employeeId) {
        LocalDate today = LocalDate.now();

        Attendance attendance = attendanceRepository.findByEmployeeId(employeeId).stream()
            .filter(a -> a.getDate().equals(today))
            .findFirst()
            .orElseThrow(() -> {
                log.error("No attendance record found for today for employee ID {}", employeeId);
                return new AttendanceAlreadyInitializedException("Attendance not initialized for today.");
            });

        if (attendance.getClockIn() == null) {
            log.error("Clock-out attempt failed: No clock-in found for employee ID {}", employeeId);
            throw new ClockInNotFoundException("You must clock in before clocking out.");
        }

        if (attendance.getClockOut() != null) {
            log.warn("Clock-out already recorded for employee ID: {}", employeeId);
            throw new AttendanceAlreadyMarkedException("You have already clocked out.");
        }

        attendance.setClockOut(LocalDateTime.now());
        return attendanceRepository.save(attendance);
    }


    public List<AttendanceDto> getAttendanceByEmployeeId(Long employeeId,LocalDate startDate, LocalDate endDate) {
        log.info("Fetching attendance records for employee ID: {}", employeeId);
        return attendanceRepository.findAttendanceDtosByEmployeeIdAndDateBetween(employeeId, startDate, endDate);
    }
    
    public List<AttendanceDto> getAttendanceReportByManager(int managerId, LocalDate startDate, LocalDate endDate) {
        List<UserDataDto> employees = userFeignClient.getEmployeesByManager(managerId);
        List<Long> employeeIds = employees.stream()
                                          .map(emp -> Long.valueOf(emp.getId()))
                                          .collect(Collectors.toList());

        List<Attendance> records = attendanceRepository.findByEmployeeIdInAndDateBetween(employeeIds, startDate, endDate);

        return records.stream()
                      .map(attendance -> new AttendanceDto(
                          attendance.getEmployeeId(),
                          attendance.getDate(),
                          attendance.getClockIn(),
                          attendance.getClockOut(),
                          attendance.getIsPresent()
                      ))
                      .collect(Collectors.toList());
    }
    public Attendance getTodayAttendance(Long employeeId) {
        LocalDate today = LocalDate.now();
        return attendanceRepository.findByEmployeeId(employeeId).stream()
            .filter(a -> a.getDate() != null && a.getDate().equals(today))
            .findFirst()
            .orElseThrow(() -> new ClockInNotFoundException("No attendance record found for today."));
    }


    
}