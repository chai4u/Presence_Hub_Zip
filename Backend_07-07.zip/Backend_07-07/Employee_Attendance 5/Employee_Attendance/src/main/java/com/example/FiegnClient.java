package com.example;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.dto.UserDataDto;

@FeignClient(name = "EMPALMS-1")
public interface FiegnClient {

    @GetMapping("api/v1/auth/user/all")
    List<UserDataDto> getAllUsers();

    @GetMapping("api/v1/auth/user/manager/{managerId}")
    List<UserDataDto> getEmployeesByManager(@PathVariable("managerId") int managerId);
}


