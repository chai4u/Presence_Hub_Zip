package com.example.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
 
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceDto {
 
	
    private Long employeeId;
    
    private LocalDate date;
    private LocalDateTime clockIn;
 
    private LocalDateTime clockOut;
    
    private Boolean isPresent = false;
    
    
}