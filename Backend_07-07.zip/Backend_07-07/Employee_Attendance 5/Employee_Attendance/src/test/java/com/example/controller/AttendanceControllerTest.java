package com.example.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.dto.AttendanceDto;
import com.example.model.Attendance;
import com.example.service.AttendanceService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
public class AttendanceControllerTest {

    @Mock
    private AttendanceService attendanceService;

    @InjectMocks
    private AttendanceController attendanceController;

    private MockMvc mockMvc;
    private Attendance attendance;
    private AttendanceDto attendanceDto;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(attendanceController).build();
        attendance = new Attendance(); // Populate with sample data if needed
        attendanceDto = new AttendanceDto(); // Populate with sample data if needed
    }

    @Test
    public void testClockIn() throws Exception {
        when(attendanceService.clockIn(1L)).thenReturn(attendance);

        mockMvc.perform(post("/api/v1/attendance/employee/clock-in/1"))
                .andExpect(status().isOk());

        verify(attendanceService, times(1)).clockIn(1L);
    }

    @Test
    public void testClockOut() throws Exception {
        when(attendanceService.clockOut(1L)).thenReturn(attendance);

        mockMvc.perform(post("/api/v1/attendance/employee/clock-out/1"))
                .andExpect(status().isOk());

        verify(attendanceService, times(1)).clockOut(1L);
    }

    @Test
    public void testGetAttendanceHistory() throws Exception {
        LocalDate startDate = LocalDate.of(2025, 6, 1);
        LocalDate endDate = LocalDate.of(2025, 6, 25);
        when(attendanceService.getAttendanceByEmployeeId(1L, startDate, endDate))
                .thenReturn(List.of(attendanceDto));

        mockMvc.perform(get("/api/v1/attendance/employee/history/1/2025-06-01/2025-06-25"))
                .andExpect(status().isOk());

        verify(attendanceService, times(1)).getAttendanceByEmployeeId(1L, startDate, endDate);
    }

    @Test
    public void testGetManagerAttendanceReport() throws Exception {
        LocalDate startDate = LocalDate.of(2025, 6, 1);
        LocalDate endDate = LocalDate.of(2025, 6, 25);
        when(attendanceService.getAttendanceReportByManager(101, startDate, endDate))
                .thenReturn(Collections.singletonList(attendanceDto));

        mockMvc.perform(get("/api/v1/attendance/manager/history/101/2025-06-01/2025-06-25"))
                .andExpect(status().isOk());

        verify(attendanceService, times(1)).getAttendanceReportByManager(101, startDate, endDate);
    }

    // Utility method to convert objects to JSON
    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
