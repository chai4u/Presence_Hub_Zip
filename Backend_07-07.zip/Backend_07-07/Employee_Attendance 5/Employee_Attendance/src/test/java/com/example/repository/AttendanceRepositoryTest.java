package com.example.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import com.example.dto.AttendanceDto;
import com.example.model.Attendance;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class AttendanceRepositoryTest {

    @Mock
    private AttendanceRepository repository;

    private Attendance attendance1;
    private Attendance attendance2;

    @BeforeEach
    void setUp() {
        attendance1 = new Attendance();
        attendance1.setEmployeeId(1L);
        attendance1.setDate(LocalDate.of(2025, 6, 25));
        attendance1.setClockIn(LocalDateTime.of(2025, 6, 25, 9, 0));
        attendance1.setClockOut(LocalDateTime.of(2025, 6, 25, 17, 0));
        attendance1.setIsPresent(true);

        attendance2 = new Attendance();
        attendance2.setEmployeeId(1L);
        attendance2.setDate(LocalDate.of(2025, 6, 24));
        attendance2.setClockIn(LocalDateTime.of(2025, 6, 24, 9, 0));
        attendance2.setClockOut(LocalDateTime.of(2025, 6, 24, 17, 0));
        attendance2.setIsPresent(true);

        // Mock behavior
        Mockito.when(repository.findByEmployeeId(1L)).thenReturn(Arrays.asList(attendance1, attendance2));
        Mockito.when(repository.existsByDate(LocalDate.of(2025, 6, 25))).thenReturn(true);
        Mockito.when(repository.findAttendanceDtosByEmployeeIdAndDateBetween(1L, LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 30)))
               .thenReturn(List.of(new AttendanceDto(1L, attendance1.getDate(), attendance1.getClockIn(), attendance1.getClockOut(), true)));
        Mockito.when(repository.findByEmployeeIdInAndDateBetween(List.of(1L), LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 30)))
               .thenReturn(List.of(attendance1, attendance2));
    }

    @Test
    void testFindByEmployeeId() {
        List<Attendance> result = repository.findByEmployeeId(1L);
        assertEquals(2, result.size());
    }

    @Test
    void testExistsByDate() {
        boolean exists = repository.existsByDate(LocalDate.of(2025, 6, 25));
        assertTrue(exists);
    }

    @Test
    void testFindAttendanceDtosByEmployeeIdAndDateBetween() {
        List<AttendanceDto> result = repository.findAttendanceDtosByEmployeeIdAndDateBetween(
                1L, LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 30));
        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getEmployeeId());
    }

    @Test
    void testFindByEmployeeIdInAndDateBetween() {
        List<Attendance> result = repository.findByEmployeeIdInAndDateBetween(
                List.of(1L), LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 30));
        assertEquals(2, result.size());
    }
}
