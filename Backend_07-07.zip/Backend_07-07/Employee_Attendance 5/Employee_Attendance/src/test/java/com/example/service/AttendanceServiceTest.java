package com.example.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.FiegnClient;
import com.example.dto.AttendanceDto;
import com.example.dto.UserDataDto;
import com.example.exception.AttendanceAlreadyInitializedException;
import com.example.exception.AttendanceAlreadyMarkedException;
import com.example.exception.ClockInNotFoundException;
import com.example.model.Attendance;
import com.example.repository.AttendanceRepository;

public class AttendanceServiceTest {

    @Mock
    private AttendanceRepository attendanceRepository;

    @Mock
    private FiegnClient userFeignClient;

    @InjectMocks
    private AttendanceService attendanceService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testInitializeDailyAttendance_Success() {
        LocalDate today = LocalDate.now();
        when(attendanceRepository.existsByDate(today)).thenReturn(false);

        UserDataDto user = new UserDataDto();
        user.setId(1);

        when(userFeignClient.getAllUsers()).thenReturn(List.of(user));

        attendanceService.initializeDailyAttendance();

        verify(attendanceRepository, times(1)).save(any(Attendance.class));
    }

    @Test
    public void testInitializeDailyAttendance_AlreadyInitialized() {
        when(attendanceRepository.existsByDate(LocalDate.now())).thenReturn(true);

        assertThrows(AttendanceAlreadyInitializedException.class, () -> {
            attendanceService.initializeDailyAttendance();
        });
    }

    @Test
    public void testClockIn_Success() {
        Long employeeId = 1L;
        LocalDate today = LocalDate.now();

        Attendance attendance = new Attendance();
        attendance.setDate(today);

        when(attendanceRepository.findByEmployeeId(employeeId)).thenReturn(List.of(attendance));
        when(attendanceRepository.save(any())).thenReturn(attendance);

        Attendance result = attendanceService.clockIn(employeeId);

        assertNotNull(result);
        assertTrue(result.getIsPresent());
        verify(attendanceRepository).save(attendance);
    }

    @Test
    public void testClockIn_AlreadyClockedIn() {
        Long employeeId = 1L;
        Attendance attendance = new Attendance();
        attendance.setDate(LocalDate.now());
        attendance.setClockIn(LocalDateTime.now());

        when(attendanceRepository.findByEmployeeId(employeeId)).thenReturn(List.of(attendance));

        assertThrows(AttendanceAlreadyMarkedException.class, () -> {
            attendanceService.clockIn(employeeId);
        });
    }

    @Test
    public void testClockOut_Success() {
        Long employeeId = 1L;
        Attendance attendance = new Attendance();
        attendance.setDate(LocalDate.now());
        attendance.setClockIn(LocalDateTime.now());

        when(attendanceRepository.findByEmployeeId(employeeId)).thenReturn(List.of(attendance));
        when(attendanceRepository.save(any())).thenReturn(attendance);

        Attendance result = attendanceService.clockOut(employeeId);

        assertNotNull(result.getClockOut());
        verify(attendanceRepository).save(attendance);
    }

    @Test
    public void testClockOut_WithoutClockIn() {
        Long employeeId = 1L;
        Attendance attendance = new Attendance();
        attendance.setDate(LocalDate.now());

        when(attendanceRepository.findByEmployeeId(employeeId)).thenReturn(List.of(attendance));

        assertThrows(ClockInNotFoundException.class, () -> {
            attendanceService.clockOut(employeeId);
        });
    }

    @Test
    public void testGetAttendanceByEmployeeId() {
        Long employeeId = 1L;
        LocalDate start = LocalDate.of(2025, 6, 1);
        LocalDate end = LocalDate.of(2025, 6, 25);

        AttendanceDto dto = new AttendanceDto();
        when(attendanceRepository.findAttendanceDtosByEmployeeIdAndDateBetween(employeeId, start, end))
                .thenReturn(List.of(dto));

        List<AttendanceDto> result = attendanceService.getAttendanceByEmployeeId(employeeId, start, end);

        assertEquals(1, result.size());
    }

    @Test
    public void testGetAttendanceReportByManager() {
        int managerId = 101;
        LocalDate start = LocalDate.of(2025, 6, 1);
        LocalDate end = LocalDate.of(2025, 6, 25);

        UserDataDto user = new UserDataDto();
        user.setId(1);

        Attendance attendance = new Attendance();
        attendance.setEmployeeId(1L);
        attendance.setDate(start);
        attendance.setClockIn(LocalDateTime.now());
        attendance.setClockOut(LocalDateTime.now());
        attendance.setIsPresent(true);

        when(userFeignClient.getEmployeesByManager(managerId)).thenReturn(List.of(user));
        when(attendanceRepository.findByEmployeeIdInAndDateBetween(List.of(1L), start, end))
                .thenReturn(List.of(attendance));

        List<AttendanceDto> result = attendanceService.getAttendanceReportByManager(managerId, start, end);

        assertEquals(1, result.size());
    }
}
