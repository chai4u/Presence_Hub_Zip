package com.example.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.clients.EmployeeAttendanceClient;
import com.example.clients.UserAuthClient;
import com.example.dto.AttendanceDto;
import com.example.dto.ReportRequestDto;
import com.example.dto.UserDataDto;
import com.example.exception.ExternalServiceException;
import com.example.exception.ResourceNotFoundException;
import com.example.model.AttendanceReport;
import com.example.repository.AttendanceReportRepository;
import com.example.service.impl.AttendanceReportServiceImpl;

@ExtendWith(MockitoExtension.class)
 class ReportsServiceTest {

    @Mock
    private AttendanceReportRepository reportRepository;

    @Mock
    private EmployeeAttendanceClient attendanceClient;

    @Mock
    private UserAuthClient userAuthClient;

    @InjectMocks
    private AttendanceReportServiceImpl reportService;

    private ReportRequestDto requestDto;
    private AttendanceReport report;
    private AttendanceDto attendanceDto;
    private UserDataDto userData;

    @BeforeEach
      void setup() {
        requestDto = new ReportRequestDto();
        requestDto.setEmployeeId(1L);
        requestDto.setStartDate(LocalDate.of(2025, 6, 1));
        requestDto.setEndDate(LocalDate.of(2025, 6, 15));

        attendanceDto = new AttendanceDto();
        attendanceDto.setIsPresent(true);

        report = new AttendanceReport();
        report.setReportId(100L);
        report.setEmployeeId(1L);
        report.setStartDate(requestDto.getStartDate());
        report.setEndDate(requestDto.getEndDate());
        report.setTotalAttendance(10);
        report.setAbsenteeism(2);

        userData = new UserDataDto();
        userData.setId(1);
        userData.setName("John Doe");
    }

    @Test
     void testGenerateEmployeeReport_Success() {
        when(attendanceClient.getAttendanceHistory(eq(1L), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(List.of(attendanceDto, attendanceDto));
        when(reportRepository.save(any())).thenReturn(report);
        when(userAuthClient.getUserById(1L)).thenReturn(userData);

        AttendanceReport result = reportService.generateEmployeeReport(requestDto);

        assertThat(result).isNotNull();
        assertThat(result.getEmployeeName()).isEqualTo("John Doe");
    }

    @Test
     void testGenerateEmployeeReport_ExternalServiceFails() {
        when(attendanceClient.getAttendanceHistory(eq(1L), any(LocalDate.class), any(LocalDate.class)))
                .thenThrow(new RuntimeException("Service down"));

        assertThatThrownBy(() -> reportService.generateEmployeeReport(requestDto))
                .isInstanceOf(ExternalServiceException.class)
                .hasMessageContaining("Failed to retrieve attendance data");
    }

    @Test
     void testGetEmployeeReports_Success() {
        when(reportRepository.findByEmployeeId(1L)).thenReturn(List.of(report));
        when(userAuthClient.getUserById(1L)).thenReturn(userData);

        List<AttendanceReport> reports = reportService.getEmployeeReports(1L);

        assertThat(reports).isNotEmpty();
        assertThat(reports.get(0).getEmployeeName()).isEqualTo("John Doe");
    }

    @Test
     void testGetEmployeeReports_NotFound() {
        when(reportRepository.findByEmployeeId(1L)).thenReturn(List.of());

        assertThatThrownBy(() -> reportService.getEmployeeReports(1L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
     void testFilterEmployeeReportsByDate_Success() {
        when(reportRepository.findByEmployeeIdAndStartDateGreaterThanEqualAndEndDateLessThanEqual(
                eq(1L), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(List.of(report));
        when(userAuthClient.getUserById(1L)).thenReturn(userData);

        List<AttendanceReport> filteredReports = reportService.filterEmployeeReportsByDate(requestDto);

        assertThat(filteredReports).hasSize(1);
        assertThat(filteredReports.get(0).getEmployeeName()).isEqualTo("John Doe");
    }

    @Test
     void testFilterEmployeeReportsByDate_NotFound() {
        when(reportRepository.findByEmployeeIdAndStartDateGreaterThanEqualAndEndDateLessThanEqual(
                eq(1L), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(List.of());

        assertThatThrownBy(() -> reportService.filterEmployeeReportsByDate(requestDto))
                .isInstanceOf(ResourceNotFoundException.class);
    }
}
