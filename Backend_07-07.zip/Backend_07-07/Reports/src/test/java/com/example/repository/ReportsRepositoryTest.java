package com.example.repository;

import com.example.model.AttendanceReport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ReportsRepositoryTest {

    @Mock
    private AttendanceReportRepository repository;

    private AttendanceReport report1;
    private AttendanceReport report2;

    @BeforeEach
    void setUp() {
        report1 = new AttendanceReport();
        report1.setReportId(1L);
        report1.setEmployeeId(101L);
        report1.setStartDate(LocalDate.of(2025, 6, 1));
        report1.setEndDate(LocalDate.of(2025, 6, 15));
        report1.setTotalAttendance(10);
        report1.setAbsenteeism(2);

        report2 = new AttendanceReport();
        report2.setReportId(2L);
        report2.setEmployeeId(101L);
        report2.setStartDate(LocalDate.of(2025, 6, 16));
        report2.setEndDate(LocalDate.of(2025, 6, 30));
        report2.setTotalAttendance(8);
        report2.setAbsenteeism(4);

        // Mock behavior
        Mockito.when(repository.findByEmployeeId(101L)).thenReturn(Arrays.asList(report1, report2));
        Mockito.when(repository.findByEmployeeId(202L)).thenReturn(List.of());

        Mockito.when(repository.findByEmployeeIdAndStartDateGreaterThanEqualAndEndDateLessThanEqual(
                101L, LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 30)))
                .thenReturn(Arrays.asList(report1, report2));

        Mockito.when(repository.findByEmployeeIdAndStartDateAndEndDate(
                101L, LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 15)))
                .thenReturn(Optional.of(report1));

        Mockito.when(repository.findByEmployeeIdIn(List.of(101L, 202L)))
                .thenReturn(Arrays.asList(report1, report2));

        Mockito.when(repository.findByEmployeeId(999L)).thenThrow(new RuntimeException("DB error"));
    }

    @Test
    void testFindByEmployeeId() {
        List<AttendanceReport> reports = repository.findByEmployeeId(101L);
        assertThat(reports).hasSize(2);
        assertThat(reports.get(0).getEmployeeId()).isEqualTo(101L);
    }

    @Test
    void testFindByEmployeeId_NoResults() {
        List<AttendanceReport> reports = repository.findByEmployeeId(202L);
        assertThat(reports).isEmpty();
    }

    @Test
    void testFindByEmployeeIdAndDateRange() {
        List<AttendanceReport> reports = repository.findByEmployeeIdAndStartDateGreaterThanEqualAndEndDateLessThanEqual(
                101L, LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 30));
        assertThat(reports).hasSize(2);
    }

    @Test
    void testFindByEmployeeIdAndExactDates() {
        Optional<AttendanceReport> report = repository.findByEmployeeIdAndStartDateAndEndDate(
                101L, LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 15));
        assertThat(report).isPresent();
        assertThat(report.get().getReportId()).isEqualTo(1L);
    }

    @Test
    void testFindByEmployeeIdIn() {
        List<AttendanceReport> reports = repository.findByEmployeeIdIn(List.of(101L, 202L));
        assertThat(reports).hasSize(2);
    }

    @Test
    void testFindByEmployeeId_DBError() {
        assertThatThrownBy(() -> repository.findByEmployeeId(999L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("DB error");
    }
}
