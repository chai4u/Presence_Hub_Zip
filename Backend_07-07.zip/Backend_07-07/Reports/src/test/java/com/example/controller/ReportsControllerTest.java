package com.example.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.dto.ReportRequestDto;
import com.example.model.AttendanceReport;
import com.example.service.AttendanceReportService;
import com.example.service.PdfGeneratorService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

class ReportsControllerTest {

    private MockMvc mockMvc;

    @Mock
    private AttendanceReportService attendanceReportService;
    
    @Mock
    private PdfGeneratorService pdfGeneratorService;

    @InjectMocks
    private EmployeeReportController employeeReportController;

    private AttendanceReport report;
    private ReportRequestDto requestDto;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(employeeReportController).build();

        report = new AttendanceReport();
        report.setReportId(1L);
        report.setEmployeeId(101L);
        report.setEmployeeName("John Doe");
        report.setStartDate(LocalDate.of(2025, 6, 1));
        report.setEndDate(LocalDate.of(2025, 6, 15));
        report.setTotalAttendance(10);
        report.setAbsenteeism(2);

        requestDto = new ReportRequestDto();
        requestDto.setEmployeeId(101L);
        requestDto.setStartDate(LocalDate.of(2025, 6, 1));
        requestDto.setEndDate(LocalDate.of(2025, 6, 15));
    }

    @Test
    void testGetEmployeeReports() throws Exception {
        when(attendanceReportService.getEmployeeReports(101L)).thenReturn(List.of(report));

        mockMvc.perform(get("/api/v1/reports/employee/101")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(attendanceReportService, times(1)).getEmployeeReports(101L);
    }

    @Test
    void testGenerateEmployeeReportPdf() throws Exception {
        when(attendanceReportService.getEmployeeReports(101L)).thenReturn(List.of(report));
        when(pdfGeneratorService.generatePdf(any(), any())).thenReturn(new byte[10]);

        mockMvc.perform(get("/api/v1/reports/employee/pdf/101")
                .contentType(MediaType.APPLICATION_PDF))
                .andExpect(status().isOk());

        verify(pdfGeneratorService, times(1)).generatePdf(any(), any());
    }

    @Test
    void testGenerateReportForEmployee() throws Exception {
        when(attendanceReportService.generateEmployeeReport(any())).thenReturn(report);

        mockMvc.perform(post("/api/v1/reports/employee/generate")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(requestDto)))
                .andExpect(status().isOk());

        verify(attendanceReportService, times(1)).generateEmployeeReport(any());
    }

    @Test
    void testFilterReportsByDate() throws Exception {
        when(attendanceReportService.filterEmployeeReportsByDate(any())).thenReturn(List.of(report));

        mockMvc.perform(post("/api/v1/reports/employee/filterByDate")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(requestDto)))
                .andExpect(status().isOk());

        verify(attendanceReportService, times(1)).filterEmployeeReportsByDate(any());
    }

    // Helper method to convert objects to JSON string with LocalDate support
    private static String asJsonString(final Object obj) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            return mapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
