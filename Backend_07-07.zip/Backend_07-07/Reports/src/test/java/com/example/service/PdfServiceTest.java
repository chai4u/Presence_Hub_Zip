package com.example.service;



import com.example.model.AttendanceReport;

import com.example.service.impl.PdfGeneratorServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.*;

 class PdfServiceTest {

    private PdfGeneratorService pdfGeneratorService;
    private AttendanceReport report;

    @BeforeEach
     void setup() {
        pdfGeneratorService = new PdfGeneratorServiceImpl();

        report = new AttendanceReport();
        report.setReportId(1L);
        report.setEmployeeId(101L);
        report.setEmployeeName("Alice Johnson");
        report.setStartDate(LocalDate.of(2025, 6, 1));
        report.setEndDate(LocalDate.of(2025, 6, 15));
        report.setTotalAttendance(10);
        report.setAbsenteeism(2);
    }

    @Test
    void testGeneratePdf_WithValidData() {
        byte[] pdfBytes = pdfGeneratorService.generatePdf(List.of(report), "Test Report");

        assertThat(pdfBytes)
            .isNotNull()
            .isNotEmpty()
            .hasSizeGreaterThan(0);
    }


    @Test
     void testGeneratePdf_WithEmptyReportList() {
        byte[] pdfBytes = pdfGeneratorService.generatePdf(Collections.emptyList(), "Empty Report");
        assertThat(pdfBytes)
        .isNotNull()
        .isNotEmpty()
        .hasSizeGreaterThan(0);
    }

    @Test
     void testGeneratePdf_WithNullReportList() {
        byte[] pdfBytes = pdfGeneratorService.generatePdf(null, "Null Report");
        assertThat(pdfBytes)
        .isNotNull()
        .isNotEmpty()
        .hasSizeGreaterThan(0);
    }

    // Optional: You can simulate a failure by mocking PdfWriter or using a spy, but iText rarely fails unless misconfigured.
}
