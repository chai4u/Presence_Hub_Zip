package com.example.repository;

import com.example.model.AttendanceReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceReportRepository extends JpaRepository<AttendanceReport, Long> {

    // Find reports for a specific employee within a date range
    List<AttendanceReport> findByEmployeeIdAndStartDateGreaterThanEqualAndEndDateLessThanEqual(
            Long employeeId, LocalDate startDate, LocalDate endDate);

    // Find reports for a specific employee
    List<AttendanceReport> findByEmployeeId(Long employeeId);

    // Optional: Find report by employeeId and specific report date (if needed for unique daily reports)
    Optional<AttendanceReport> findByEmployeeIdAndStartDateAndEndDate(Long employeeId, LocalDate startDate, LocalDate endDate);

    // For simplicity, fetching all reports for manager's subordinates would likely be done
    // by fetching employee IDs first, then querying this repository.
    // However, if you need a direct query:
     List<AttendanceReport> findByEmployeeIdIn(List<Long> employeeIds);
}
