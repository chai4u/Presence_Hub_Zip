package com.example.service.impl;

import java.io.ByteArrayOutputStream;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.exception.ReportGenerationException; // Using the existing ReportGenerationException
import com.example.model.AttendanceReport;
import com.example.service.PdfGeneratorService; // Implementing this interface
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import lombok.extern.slf4j.Slf4j;

@Service // Mark as Spring service
@Slf4j // For logging
public class PdfGeneratorServiceImpl implements PdfGeneratorService {

    @Override
    public byte[] generatePdf(List<AttendanceReport> reports, String title) {
        log.info("Attempting to generate PDF report with title: {}", title);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Document document = new Document(); // iText 5 Document instance

        try {
            PdfWriter.getInstance(document, outputStream);
            document.open(); // Open the document for writing

            // Define Fonts for iText 5
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, BaseColor.BLACK);
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.WHITE);
            Font dataFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
            Font dateFont = new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY);

            // Add title
            Paragraph titlePara = new Paragraph(title, titleFont);
            titlePara.setAlignment(Element.ALIGN_CENTER);
            document.add(titlePara);

            // Add generation date
            Paragraph datePara = new Paragraph("Generated on: " + LocalDate.now(), dateFont);
            datePara.setAlignment(Element.ALIGN_RIGHT);
            document.add(datePara);
            document.add(Chunk.NEWLINE); // Add some space

            // Create a table with 7 columns (relative widths)
            PdfPTable table = new PdfPTable(new float[]{1f, 1.5f, 2f, 2f, 2f, 1.5f, 1.5f});
            table.setWidthPercentage(100); // Make table take full width
            table.setSpacingBefore(10f); // Add space before the table

            // Add table headers
            addHeaderCell(table, "Report ID", headerFont);
            addHeaderCell(table, "Employee ID", headerFont);
            addHeaderCell(table, "Employee Name", headerFont);
            addHeaderCell(table, "Start Date", headerFont);
            addHeaderCell(table, "End Date", headerFont);
            addHeaderCell(table, "Total Present", headerFont);
            addHeaderCell(table, "Absenteeism", headerFont);

            // Add data rows
            if (reports == null || reports.isEmpty()) {
                // If no reports, add a single row indicating no data
                PdfPCell noDataCell = new PdfPCell(new Phrase("No reports available.", dataFont));
                noDataCell.setColspan(7); // Span across all 7 columns
                noDataCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                noDataCell.setPadding(10);
                table.addCell(noDataCell);
            } else {
                for (AttendanceReport report : reports) {
                    addCell(table, String.valueOf(report.getReportId()), dataFont);
                    addCell(table, String.valueOf(report.getEmployeeId()), dataFont);
                    addCell(table, report.getEmployeeName() != null ? report.getEmployeeName() : "N/A", dataFont);
                    addCell(table, report.getStartDate() != null ? report.getStartDate().toString() : "N/A", dataFont);
                    addCell(table, report.getEndDate() != null ? report.getEndDate().toString() : "N/A", dataFont);
                    addCell(table, String.valueOf(report.getTotalAttendance()), dataFont);
                    addCell(table, String.valueOf(report.getAbsenteeism()), dataFont);
                }
            }

            document.add(table);

        } catch (com.itextpdf.text.DocumentException e) { // iText 5 throws DocumentException
            log.error("Error generating PDF report using iText 5: {}", e.getMessage(), e);
            throw new ReportGenerationException("Failed to generate PDF report.", e);
        } finally {
            if (document.isOpen()) {
                document.close(); // Ensure document is closed to flush content
            }
        }
 
        log.info("PDF report generated successfully into ByteArrayOutputStream using iText 5.");
        return outputStream.toByteArray();
    }

    // Helper method to add a header cell with specific styling for iText 5
    private void addHeaderCell(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBackgroundColor(BaseColor.DARK_GRAY); // Example background color
        cell.setPadding(5);
        table.addCell(cell);
    }

    // Helper method to add a data cell for iText 5
    private void addCell(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(3);
        table.addCell(cell);
    }
}