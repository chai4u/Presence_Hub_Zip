package com.example.service;

import java.time.LocalDate;
import java.util.List;


import com.example.dto.ReportRequestDto;
import com.example.model.AttendanceReport;

public interface AttendanceReportService {
    AttendanceReport generateEmployeeReport(ReportRequestDto request);
    List<AttendanceReport> getEmployeeReports(Long employeeId);
    List<AttendanceReport> filterEmployeeReportsByDate(ReportRequestDto request);
    List<AttendanceReport> getManagerEmployeeReports(int managerId, LocalDate startDate, LocalDate endDate);

}