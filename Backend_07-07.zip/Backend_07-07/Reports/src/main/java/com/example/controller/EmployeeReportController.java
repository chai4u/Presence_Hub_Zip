package com.example.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.ReportRequestDto;
import com.example.model.AttendanceReport;
import com.example.service.AttendanceReportService;
import com.example.service.PdfGeneratorService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
//@CrossOrigin(origins = "http://localhost:3000")
public class EmployeeReportController {

    private final AttendanceReportService attendanceReportService;
    private final PdfGeneratorService pdfGeneratorService;
    
    
    @PostMapping("employee/generate")
    public ResponseEntity<AttendanceReport> generateReportForEmployee(@Valid @RequestBody ReportRequestDto request) {
        log.info("Received request to generate report for employee ID: {} from {} to {}",
                 request.getEmployeeId(), request.getStartDate(), request.getEndDate());
        AttendanceReport report = attendanceReportService.generateEmployeeReport(request);
        return ResponseEntity.ok(report);
    }

    @PostMapping("employee/filterByDate")
    public ResponseEntity<List<AttendanceReport>> filterReportsByDate(@Valid @RequestBody ReportRequestDto request) {
        log.info("Received request to filter reports for employee ID: {} by date range: {} to {}",
                 request.getEmployeeId(), request.getStartDate(), request.getEndDate());
        List<AttendanceReport> reports = attendanceReportService.filterEmployeeReportsByDate(request);
        return ResponseEntity.ok(reports);
    }
    
    @GetMapping("employee/{employeeId}")
    public ResponseEntity<List<AttendanceReport>> getEmployeeReports(@PathVariable Long employeeId) {
        log.info("Received request to fetch reports for employee ID: {}", employeeId);
        List<AttendanceReport> reports = attendanceReportService.getEmployeeReports(employeeId);
        return ResponseEntity.ok(reports);
    }

    @GetMapping(value = "employee/pdf/{employeeId}", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> generateEmployeeReportPdf(@PathVariable Long employeeId) {
        log.info("Received request to generate PDF report for employee ID: {}", employeeId);
        // Fetch reports using the service, which will include employeeName
        List<AttendanceReport> reports = attendanceReportService.getEmployeeReports(employeeId);

        // Generate PDF. The PdfGeneratorServiceImpl will use the employeeName from the DTOs.
        byte[] pdfBytes = pdfGeneratorService.generatePdf(reports, "Employee Attendance Report for ID: " + employeeId);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        String filename = "employee_attendance_report_" + employeeId + ".pdf";
        headers.setContentDispositionFormData("attachment", filename);
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

        return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
    }

    @PostMapping("manager/generate/{managerId}")
    public ResponseEntity<List<AttendanceReport>> generateManagerReport(
            @PathVariable int managerId,
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        log.info("Generating report for manager ID: {} from {} to {}", managerId, startDate, endDate);

        List<AttendanceReport> reports = attendanceReportService.getManagerEmployeeReports(
                managerId, startDate, endDate);

        return ResponseEntity.ok(reports);
    }

    
	@GetMapping(value = "manager/pdf/{managerId}", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> generateManagerReportPdf(
            @PathVariable int managerId,
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        log.info("Received request to generate PDF report for manager ID: {} from {} to {}", managerId, startDate, endDate);

        List<AttendanceReport> reports = attendanceReportService.getManagerEmployeeReports(managerId, startDate, endDate);
        byte[] pdfBytes = pdfGeneratorService.generatePdf(reports, "Attendance Report for Manager ID: " + managerId);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", "manager_attendance_report_" + managerId + ".pdf");
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

        return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
    }

    

}