package com.example.service;

import java.util.List;

import com.example.model.AttendanceReport;

public interface PdfGeneratorService {
    byte[] generatePdf(List<AttendanceReport> reports, String title);
}