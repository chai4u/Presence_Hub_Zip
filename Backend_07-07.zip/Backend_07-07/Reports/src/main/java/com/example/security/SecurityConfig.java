package com.example.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;


import lombok.RequiredArgsConstructor;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {
	    
	    private final JwtFilter jwtFilter;

	    @Bean
	    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
	    	http.csrf(csrf -> csrf.disable())
	    	    .authorizeHttpRequests(auth -> auth 
//	    	    		.requestMatchers(
//	    	                    new AntPathRequestMatcher("/api/v1/register/user"),
//	    	                    new AntPathRequestMatcher("/api/v1/login/user"),
//	    	                    new AntPathRequestMatcher("/swagger-ui.html"),       // The main Swagger UI page
//	    	                    new AntPathRequestMatcher("/swagger-ui/**"),        // All Swagger UI resources (CSS, JS, etc.)
//	    	                    new AntPathRequestMatcher("/v3/api-docs/**"),       // The OpenAPI spec in JSON/YAML
//	    	                    new AntPathRequestMatcher("/swagger-resources/**"), // Older Swagger paths (good to include)
//	    	                    new AntPathRequestMatcher("/swagger-resources"),    // Older Swagger paths
//	    	                    new AntPathRequestMatcher("/webjars/**")            // WebJars resources often used by Swagger
//	    	                ).permitAll()
	    	    		
	    	    .requestMatchers("/swagger-ui.html","/swagger-ui/**","/v3/api-docs/**","/swagger-resources/**","/swagger-resources","/webjars/**").permitAll()
	            .requestMatchers("/api/v1/reports/admin/**").hasRole("admin")
	            .requestMatchers("/api/v1/reports/employee/**").hasAnyRole("employee","manager","admin")
	            .requestMatchers("/api/v1/reports/manager/**").hasAnyRole("manager","admin")
	            
	            
	            .anyRequest().authenticated())
	            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

	        return http.build();
	    }
	    
	    @Bean
	    public PasswordEncoder passwordEncoder() {
	        return new BCryptPasswordEncoder();
	    }

}
