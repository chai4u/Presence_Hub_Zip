package com.example.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.clients.EmployeeAttendanceClient;
import com.example.clients.UserAuthClient;
import com.example.dto.AttendanceDto;          // Using this DTO for raw attendance data
import com.example.dto.ReportRequestDto;
import com.example.dto.UserDataDto;            // Using this DTO for user data
import com.example.exception.ExternalServiceException;
import com.example.exception.ResourceNotFoundException;
import com.example.model.AttendanceReport;
import com.example.repository.AttendanceReportRepository;
import com.example.service.AttendanceReportService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class AttendanceReportServiceImpl implements AttendanceReportService {

    private final AttendanceReportRepository attendanceReportRepository;
    private final UserAuthClient userAuthClient;
    private final EmployeeAttendanceClient employeeAttendanceClient;

    // Helper to convert AttendanceReport Entity to AttendanceReportDto (with employee name)
    private AttendanceReport convertToDto(AttendanceReport report) {
        AttendanceReport dto = new AttendanceReport();
        dto.setReportId(report.getReportId());
        dto.setEmployeeId(report.getEmployeeId());
        dto.setStartDate(report.getStartDate());
        dto.setEndDate(report.getEndDate());
        dto.setTotalAttendance(report.getTotalAttendance());
        dto.setAbsenteeism(report.getAbsenteeism());

        try {
            // Using report.getEmployeeId() directly as it's likely already a Long or can be cast safely.
            // If report.getEmployeeId() returns an Integer, ensure it's cast to Long.
            // Assuming report.getEmployeeId() returns Long as per the second example's usage with getUserById(dto.getEmployeeId())
            Long employeeId = report.getEmployeeId(); // Assuming getEmployeeId() returns Long
            log.info("Attempting to fetch employee details for ID: {}", employeeId);
 
            UserDataDto user = userAuthClient.getUserById(employeeId);
 
            if (user != null && user.getName() != null && !user.getName().isBlank()) {
                dto.setEmployeeName(user.getName());
                log.info("Successfully fetched employee name: {} for ID: {}", user.getName(), employeeId);
            } else {
                dto.setEmployeeName("Unknown Employee");
                log.warn("User data or name was null/blank for ID {}. Setting to 'Unknown Employee'. User object: {}", employeeId, user);
            }
 
        } catch (Exception e) {
            log.warn("Could not fetch employee name for ID {}: {}", report.getEmployeeId(), e.getMessage()); // Use getMessage() for cleaner logs
            dto.setEmployeeName("Error Fetching Name");
        }
  
        return dto;
    }

    @Override
    @Transactional
    public AttendanceReport generateEmployeeReport(ReportRequestDto request) {
        log.info("Generating report for employee ID: {} from {} to {}",
                 request.getEmployeeId(), request.getStartDate(), request.getEndDate());

        List<AttendanceDto> dailyRecords;
        try {
            // Correctly using employeeAttendanceClient to fetch AttendanceDto
            dailyRecords = employeeAttendanceClient.getAttendanceHistory(
                    request.getEmployeeId(), request.getStartDate(), request.getEndDate());
            if (dailyRecords == null) {
                 dailyRecords = new ArrayList<>();
            }
        } catch (Exception e) {
            log.error("Failed to fetch daily attendance records for employee {}: {}",
                      request.getEmployeeId(), e.getMessage(), e);
            throw new ExternalServiceException("Failed to retrieve attendance data from Employee Attendance service.");
        }

        int totalDays = dailyRecords.size();
        int presentDays = 0;
        for (AttendanceDto attendance : dailyRecords) {
            if (Boolean.TRUE.equals(attendance.getIsPresent())) {
                presentDays++;
            }
        }
        int absentDays = totalDays - presentDays;

        AttendanceReport report = new AttendanceReport();
        report.setEmployeeId(request.getEmployeeId());
        report.setStartDate(request.getStartDate());
        report.setEndDate(request.getEndDate());
        report.setTotalAttendance(presentDays);
        report.setAbsenteeism(absentDays);

        AttendanceReport savedReport = attendanceReportRepository.save(report);
        log.info("Generated and saved report with ID: {} for employee: {}", savedReport.getReportId(), savedReport.getEmployeeId());

        return convertToDto(savedReport);
    }
 
    @Override
    public List<AttendanceReport> getEmployeeReports(Long employeeId) {
        log.info("Fetching all reports for employee ID: {}", employeeId);
        List<AttendanceReport> reports = attendanceReportRepository.findByEmployeeId(employeeId);
        if (reports.isEmpty()) {
            log.warn("No reports found for employee ID: {}", employeeId);
            throw new ResourceNotFoundException("No attendance reports found for employee ID: " + employeeId);
        }

        return reports.stream().map(this::convertToDto).toList();

    }

    @Override
    public List<AttendanceReport> filterEmployeeReportsByDate(ReportRequestDto request) {
        log.info("Filtering reports for employee ID: {} by date range: {} to {}",
                 request.getEmployeeId(), request.getStartDate(), request.getEndDate());
        List<AttendanceReport> reports = attendanceReportRepository
                .findByEmployeeIdAndStartDateGreaterThanEqualAndEndDateLessThanEqual(
                        request.getEmployeeId(), request.getStartDate(), request.getEndDate());
        if (reports.isEmpty()) {
            log.warn("No reports found for employee ID: {} in date range {} to {}",
                     request.getEmployeeId(), request.getStartDate(), request.getEndDate());
            throw new ResourceNotFoundException("No attendance reports found for employee ID " + request.getEmployeeId() + " in the specified date range.");
        }

         return reports.stream().map(this::convertToDto).toList();

    }
    
   
    
    @Override
    public List<AttendanceReport> getManagerEmployeeReports(int managerId, LocalDate startDate, LocalDate endDate) {
        log.info("Fetching attendance records for manager ID: {} from {} to {}", managerId, startDate, endDate);

        List<AttendanceDto> attendanceDtos;
        try {
            // Call the Feign client to get attendance data
            attendanceDtos = employeeAttendanceClient.getManagerAttendanceReport(managerId, startDate, endDate).getBody();
            if (attendanceDtos == null) {
                attendanceDtos = new ArrayList<>();
            }
        } catch (Exception e) {
            log.error("Failed to fetch attendance records for manager ID {}: {}", managerId, e.getMessage(), e);
            throw new ExternalServiceException("Failed to retrieve attendance data from Employee Attendance service.");
        }

        // Group and aggregate attendance data per employee
        Map<Long, List<AttendanceDto>> groupedByEmployee = attendanceDtos.stream()
            .collect(Collectors.groupingBy(AttendanceDto::getEmployeeId));

        List<AttendanceReport> reports = new ArrayList<>();

        for (Map.Entry<Long, List<AttendanceDto>> entry : groupedByEmployee.entrySet()) {
            Long employeeId = entry.getKey();
            List<AttendanceDto> records = entry.getValue();

            int totalDays = records.size();
            int presentDays = (int) records.stream().filter(AttendanceDto::getIsPresent).count();
            int absentDays = totalDays - presentDays;

            AttendanceReport report = new AttendanceReport();
            report.setEmployeeId(employeeId);
            report.setStartDate(startDate);
            report.setEndDate(endDate);
            report.setTotalAttendance(presentDays);
            report.setAbsenteeism(absentDays);

            // Enrich with employee name using your existing method
            reports.add(convertToDto(report));
        }

        return reports;
    }


}