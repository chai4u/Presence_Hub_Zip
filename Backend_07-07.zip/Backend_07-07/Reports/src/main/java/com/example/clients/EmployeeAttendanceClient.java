package com.example.clients;

import java.time.LocalDate;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dto.AttendanceDto;

@FeignClient(name = "Employee-Attendance")
public interface EmployeeAttendanceClient {

    
    @GetMapping("/api/v1/attendance/employee/history/{employeeId}/{startDate}/{endDate}")
    public List<AttendanceDto> getAttendanceHistory(@PathVariable Long employeeId,@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate, @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate);
        
    @GetMapping("/api/v1/attendance/manager/history/{managerId}/{startDate}/{endDate}")
    public ResponseEntity<List<AttendanceDto>> getManagerAttendanceReport(
    	 @PathVariable("managerId") int managerId,@PathVariable("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
         @PathVariable("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate);
     
}